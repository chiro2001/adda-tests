# pyadq

The pyadq package is a python wrapper for the ADQAPI. The following digitizers
are supported:

- ADQ32
- ADQ33

Requirements:
- Python 3.6 or later
- Numpy and ctypes
- ADQAPI

## Installation
The pyadq package can be installed with
```
$ pip install --user .
```

## Examples
See `example/adq3_series.py`
