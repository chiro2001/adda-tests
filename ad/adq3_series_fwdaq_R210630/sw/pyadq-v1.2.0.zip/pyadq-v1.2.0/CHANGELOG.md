# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),

## [1.2.0] - 2021-06-23

### Added

- Added `pyadq.ADQ` wrappers for `ParametersString` and `ParametersFilename`
  functions. See ADQ3 Series User Guide.

- Added `pyadq.ADQ` wrappers for `ReadUserRegister` and `WriteUserRegister`.

### Changed

- Increment API version support to 4.0. This includes ADQ3 Series release 2.

## [1.1.0] - 2021-05-03

### Changed

- Increment API version support from 1.0 to 3.0

### Fixed

- Fix an issue where the serial number was read for unsupported devices,
  which caused python decode exceptions.

### Added

- Added support for ADQ7 and ADQ14, see `example/adq7_adq8_adq14.py`

- Added argtypes to `ADQControlUnit_EnableErrorTrace`. It can now be called as
    ADQControlUnit_EnableErrorTrace(.., "path-to-log")
  instead of
    ADQControlUnit_EnableErrorTrace(.., "path-to-log".encode("ascii"))

## [1.0.0] - 2021-02-12

### Added

- Initial release of `pyadq`
