# Copyright 2021 Teledyne Signal Processing Devices Sweden AB

"""ADQ."""

import ctypes as ct
import numpy as np  # type: ignore
from typing import Callable, Union, Optional, List, Tuple

from .structs import (
    PID_ADQ7,
    PID_ADQ14,
    PID_ADQ8,
    PID_ADQ3,
    ADQ_DATA_READOUT_STATUS_FLAGS_OK,
    ADQ_MAX_NOF_CHANNELS,
    ADQ_EOK,
    ADQ_EAGAIN,
    _ADQRecord,
    _ADQGen4Record,
    _ADQDataReadoutStatus,
    _ADQRecordHeader,
    ADQGen4RecordHeader,
    ADQRecordHeader,
    ADQDaisyChainDeviceInformation,
    _ADQDaisyChainDeviceInformation,
    _ADQDaisyChainTriggerInformation,
    ADQDaisyChainTriggerInformation,
    _native_base,
    _set_api_function_types,
    _ParameterStructs,
    _enum_to_parameter_struct,
    _StatusStructs,
    _enum_to_status_struct,
)

from .error import Error, Timeout, ApiError, WaitForRecordBufferStatus


class MultiRecordData(_native_base):
    """Data object returned by pyadq.ADQ.GetData

    Member variables:
        `data`: An N x M numpy array where the first dimension is
                the channel, and the second the record index.
        `header`: A list of `ADQRecordHeader` objects. All channels share the same header.
    """

    def __init__(self):  # noqa: D107
        self.header: List[ADQRecordHeader] = []
        self.data: np.ndarray = np.array([])

    def _to_dict(self) -> dict:
        data = [[x.tolist() for x in y] for y in self.data]
        header = [x._to_dict() for x in self.header]

        ret = {"name": "MultiRecordData", "data": {"data": data, "header": header}}
        return ret

    @classmethod
    def _from_dict(cls, dict_obj: dict) -> "MultiRecordData":
        name: str = dict_obj["name"]
        if cls.__name__ != name:
            raise Error("Attempting to deserialize {} to {}".format(name, cls.__name__))

        c = cls()
        data = dict_obj["data"]

        c.header = [ADQRecordHeader._from_dict(x) for x in data["header"]]
        c.data = np.array(data["data"])

        return c

    def __repr__(self):
        sn = ""
        if len(self.header) > 0:
            sn = "SPD-{}".format(self.header[0].SerialNumber)
        return "<MultiRecordData {}: {}>".format(sn, self.data.shape)


class RecordBuffer(_native_base):
    """Record buffer returned by `WaitForRecordBuffer`."""

    def __init__(self):  # noqa: D107
        self.header: Optional[ADQGen4RecordHeader, ADQRecordHeader] = None
        self.data: np.array = np.array([], dtype=int)

    def _to_dict(self) -> dict:
        if self.data is None:
            data = None
        else:
            data = self.data.tolist()

        if self.header is None:
            header = None
        else:
            header = self.header._to_dict()

        ret = {"name": "RecordBuffer", "data": {"data": data, "header": header}}
        return ret

    @classmethod
    def _from_dict(cls, dict_obj: dict) -> "RecordBuffer":
        name: str = dict_obj["name"]
        if cls.__name__ != name:
            raise Error("Attempting to deserialize {} to {}".format(name, cls.__name__))

        c = cls()
        data = dict_obj["data"]
        if data["header"] is not None:
            tmp = data["header"]
            assert isinstance(tmp, dict), f"Type: {type(tmp)}"

            candidates = {x.__name__: x for x in [ADQRecordHeader, ADQGen4RecordHeader]}
            c.header = candidates[tmp["name"]]._from_dict(tmp)

        c.data = np.array(data["data"])
        return c

    def __repr__(self):
        return "<RecordBuffer {} samples>".format(len(self.data))


class _ADQFuncPtr:
    def __init__(
        self,
        ADQAPI: ct.CDLL,
        adq_cu: ct.c_void_p,
        adq_num: int,
        name: str,
        restype=None,
    ):
        if not name.startswith("ADQ_"):
            raise AttributeError(name)

        if restype is not None:
            self._restype_ = restype
        self._adq_cu = adq_cu
        self._adq_num = adq_num
        self._func = ADQAPI.__getattr__(name)
        self.__name__ = name

    def __call__(self, *args, **kwargs) -> Callable:
        return self._func(self._adq_cu, self._adq_num, *args, **kwargs)

    def __setattr__(self, name, lhs) -> None:
        if name == "restype":
            self._func.__setattr__(name, lhs)
        elif name == "argtypes":
            # Prepend adq_cu and adq_num types
            self._func.__setattr__(name, [ct.c_void_p, ct.c_int] + lhs)
        self.__dict__[name] = lhs

    def __getattr__(self, name):
        return self.__dict__[name]


class ADQ:
    """Python wrapper for the ADQ object.

    This object wrapps all ADQ_ functions. For the documentation
    see the ADQ3 series user guide. Most functions are passed directly to ctypes.

    """

    def __init__(
        self, ADQAPI: ct.CDLL, adq_cu: ct.c_void_p, adq_num: int
    ):  # noqa: D107
        self._serial_number: Optional[str] = None
        self._ADQAPI = ADQAPI
        self._adq_cu = adq_cu
        self._adq_num: int = adq_num

        # Update the return types and argument types from auto-generated code
        _set_api_function_types(self)

        if self.ADQ_GetProductID() == PID_ADQ8:
            if not self.ADQ_SetTransferBuffers(8, 4608 * 14):
                # FIXME: Should this be here?
                raise ApiError("SetTransferBuffers failed")

    @property
    def serial_number(self) -> str:
        if self._serial_number is None:
            self._serial_number = self.ADQ_GetBoardSerialNumber()
        return self._serial_number

    def __getattr__(self, name: str) -> Callable:  # noqa: D105
        if not name.startswith("ADQ_"):
            raise AttributeError(name)

        func = _ADQFuncPtr(self._ADQAPI, self._adq_cu, self._adq_num, name)
        setattr(self, name, func)
        return func

    def __repr__(self):  # noqa: D105
        try:
            return "<ADQ S/N: {}>".format(self.serial_number)
        except AttributeError:
            return "<ADQ S/N: UNKNOWN>"

    def __enter__(self):  # noqa: D105
        return self

    def __exit__(self, exc_type, exc_value, traceback):  # noqa: D105
        self._close()

    def __del__(self):  # noqa: D105
        self._close()

    def _close(self):
        if self._ADQAPI is not None and self._adq_num >= 0:
            # FIXME: Can we delete the ADQ here? What happens to the adq_num of
            # other devices
            # self._ADQAPI.ADQControlUnit_DeleteADQ(self._adq_cu, self._adq_num)
            # # TODO: Needed?
            # self._adq_num = -1
            pass

    def print_info(self) -> None:
        """Print revisions."""
        # Get revision info from ADQ

        # NOTE: Actually a c_int array, but works like a tuple here
        revision: Tuple[int, int, int, int, int, int] = self.ADQ_GetRevision()

        api_revision = str(self._ADQAPI.ADQAPI_GetRevision())
        print(f"ADQ S/N: {self.serial_number}")
        print(f"FPGA Revision: r{revision[0]}")
        print(f"API Revision: r{api_revision}")

    def SetParameters(self, parameters: _ParameterStructs) -> None:
        """Set parameters.

        Args:
            `parameters`: A parameter object, e.g. pyadq.ADQParameters

        Returns:
            None

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """
        tmp = parameters._to_ct()
        result = self.ADQ_SetParameters(ct.byref(tmp))
        if result != ct.sizeof(tmp):
            raise ApiError(
                f"ADQ_SetParameters failed. Expected {ct.sizeof(tmp)} "
                f", got {result}. See log file.",
                error_code=result,
            )

        return None

    def GetStatus(self, status_id: int) -> _StatusStructs:
        """Read parameters from the device.

        Get the parameters for `status_id`. Example

            `status = GetStatus(ADQ_STATUS_ID_OVERFLOW)`

        Args:
            `status_id`: The parameter struct ID. Prefixed with ADQ_PARAMETER_ID_

        Returns:
            A parameter struct object

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
            `pyadq.Error`: `status_id` is invalid

        """
        tmp = _enum_to_status_struct(status_id)._to_ct()

        result = self.ADQ_GetStatus(status_id, ct.byref(tmp))
        if result != ct.sizeof(tmp):
            raise ApiError(
                f"ADQ_GetStatus failed. Expected {ct.sizeof(tmp)} "
                f", got {result}. See log file.",
                error_code=result,
            )

        return tmp._to_native()

    def GetParameters(self, parameter_id: int) -> _ParameterStructs:
        """Read parameters from the device.

        Get the parameters for `parameter_id`. Example

            `transfer_parameters = GetParameters(ADQ_PARAMETER_ID_DATA_TRANSFER)`

        Args:
            `parameter_id`: The parameter struct ID. Prefixed with ADQ_PARAMETER_ID_

        Returns:
            A parameter struct object

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
            `pyadq.Error`: `parameter_id` is invalid

        """
        tmp = _enum_to_parameter_struct(parameter_id)._to_ct()

        result = self.ADQ_GetParameters(parameter_id, ct.byref(tmp))
        if result != ct.sizeof(tmp):
            raise ApiError(
                f"ADQ_GetParameters failed. Expected {ct.sizeof(tmp)} "
                f", got {result}. See log file.",
                error_code=result,
            )

        return tmp._to_native()

    def ValidateParameters(self, parameters: _ParameterStructs) -> None:
        """Validate parameters.

        Validate the parameter object values. See ADQAPI
        reference guide.

        Args:
            `parameters`: A parameter object, e.g. ADQDataTransferParameters

        Returns:
            None

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """
        tmp = parameters._to_ct()

        result = self.ADQ_ValidateParameters(ct.byref(tmp))
        if result != ct.sizeof(tmp):
            raise ApiError(
                f"ADQ_ValidateParameters failed. Expected {ct.sizeof(tmp)} "
                f", got {result}. See log file.",
                error_code=result,
            )

        return None

    def InitializeParameters(self, parameter_id: int):
        """Initialize parameters.

        Initializes the parameter object with the default values. See ADQAPI
        reference guide.

        Args:
            `parameter_id`: The parameter struct ID. Prefixed with ADQ_PARAMETER_ID

        Returns:
            A parameter struct object corresponding to the c structure.

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
            `pyadq.Error`: `parameter_id` is invalid

        """

        tmp = _enum_to_parameter_struct(parameter_id)._to_ct()

        result = self.ADQ_InitializeParameters(parameter_id, ct.byref(tmp))
        if result != ct.sizeof(tmp):
            raise ApiError(
                f"ADQ_InitializeParameters failed. Expected {ct.sizeof(tmp)} "
                f", got {result}. See log file.",
                error_code=result,
            )

        return tmp._to_native()

    def SetParametersString(self, parameters: str) -> None:
        """Set parameters from a string.

        Args:
            `parameters`: A string object containing a JSON formatted parameter set

        Returns:
            None

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """

        buffer = ct.create_string_buffer(parameters.encode("ascii"))

        result = self.ADQ_SetParametersString(buffer, ct.sizeof(buffer))
        if result != (ct.sizeof(buffer) - 1):
            raise ApiError(
                f"ADQ_SetParametersString failed. Expected {ct.sizeof(buffer) - 1} "
                f", got {result}. See log file.",
                error_code=result,
            )

        return None

    def GetParametersString(
        self, parameter_id: int, length: int = 500000, format: int = 1
    ) -> str:
        """Read parameters from the device as a string.

        Get the parameters for `parameter_id`. Example

            `transfer_parameters = GetParametersString(ADQ_PARAMETER_ID_DATA_TRANSFER)`

        Args:
            `parameter_id`: The parameter struct ID. Prefixed with ADQ_PARAMETER_ID_
            `length`: The maximum length of the string. Defaults to 500000.
            `format`: Enable formatted output, with newlines and indentation.
                      Defaults to 1.

        Returns:
            A string object containing a JSON-formatted representation of the
            parameters

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
            `pyadq.Error`: `parameter_id` is invalid

        """
        _enum_to_parameter_struct(parameter_id)

        buffer = ct.create_string_buffer(length)

        result = self.ADQ_GetParametersString(parameter_id, buffer, length, format)
        if result < 0:
            raise ApiError(
                f"ADQ_GetParametersString failed. Got {result}. See log file.",
                error_code=result,
            )

        return buffer.value.decode()

    def ValidateParametersString(self, parameters: str) -> None:
        """Validate parameters from a string.

        Validate the parameter object values. See ADQAPI
        reference guide.

        Args:
            `parameters`: A string object containing a JSON formatted parameter set

        Returns:
            None

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """

        buffer = ct.create_string_buffer(parameters.encode("ascii"))

        result = self.ADQ_ValidateParametersString(buffer, ct.sizeof(buffer))
        if result != (ct.sizeof(buffer) - 1):
            raise ApiError(
                f"ADQ_ValidateParametersString failed. Expected {ct.sizeof(buffer) - 1} "
                f", got {result}. See log file.",
                error_code=result,
            )

        return None

    def InitializeParametersString(
        self, parameter_id: int, length: int = 500000, format: int = 1
    ) -> str:
        """Initialize parameters as a string.

        Initializes the parameter string with the default values.

        Args:
            `parameter_id`: The parameter struct ID. Prefixed with ADQ_PARAMETER_ID
            `length`: The maximum length of the string. Defaults to 500000.
            `format`: Enable formatted output, with newlines and indentation.
                      Defaults to 1.

        Returns:
            A string object containing a JSON-formatted representation of the
            parameters

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
            `pyadq.Error`: `parameter_id` is invalid

        """

        _enum_to_parameter_struct(parameter_id)

        buffer = ct.create_string_buffer(length)

        result = self.ADQ_InitializeParametersString(
            parameter_id, buffer, length, format
        )
        if result < 0:
            raise ApiError(
                f"ADQ_InitializeParametersString failed."
                f", got {result}. See log file.",
                error_code=result,
            )

        return buffer.value.decode()

    def SetParametersFilename(self, filename: str) -> None:
        """Set parameters from a file containing JSON-formatted text.

        Args:
            `filename`: A string object containing a path to a file
                        containing the JSON-formatted parameter set.

        Returns:
            None

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """

        buffer = ct.create_string_buffer(filename.encode("ascii"))

        result = self.ADQ_SetParametersFilename(buffer)
        if result < 0:
            raise ApiError(
                f"ADQ_SetParametersFilename failed. Got {result}. See log file.",
                error_code=result,
            )

        return None

    def GetParametersFilename(
        self, parameter_id: int, filename: str, format: int = 1
    ) -> None:
        """Read parameters from the device to a file.

        Get the parameters for `parameter_id` and write them as JSON-formatted
        text to a file.

        Args:
            `parameter_id`: The parameter struct ID. Prefixed with ADQ_PARAMETER_ID_
            `filename`: A string object containing a path to a file where
                        the parameter values will be stored.
            `format`: Enable formatted output, with newlines and indentation.
                      Defaults to 1.

        Returns:
            None

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
            `pyadq.Error`: `parameter_id` is invalid

        """
        _enum_to_parameter_struct(parameter_id)

        buffer = ct.create_string_buffer(filename.encode("ascii"))

        result = self.ADQ_GetParametersFilename(parameter_id, buffer, format)
        if result < 0:
            raise ApiError(
                f"ADQ_GetParametersFilename failed. Got {result}. See log file.",
                error_code=result,
            )

        return None

    def ValidateParametersFilename(self, filename: str) -> None:
        """Validate parameters from a JSON-formatted text file.

        Args:
            `filename`: A string object containing a path to a file
                        containing the JSON-formatted parameter set.

        Returns:
            None

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """

        buffer = ct.create_string_buffer(filename.encode("ascii"))

        result = self.ADQ_ValidateParametersFilename(buffer)
        if result < 0:
            raise ApiError(
                f"ADQ_ValidateParametersFilename failed. Got {result}. See log file.",
                error_code=result,
            )

        return None

    def InitializeParametersFilename(
        self, parameter_id: int, filename: str, format: int = 1
    ) -> None:
        """Initialize parameters and write to file.

        Initializes the parameters and writes them as JSON-formatted text
        to a file.

        Args:
            `parameter_id`: The parameter struct ID. Prefixed with ADQ_PARAMETER_ID_
            `filename`: A string object containing a path to a file where
                        the parameter values will be stored.
            `format`: Enable formatted output, with newlines and indentation.
                      Defaults to 1.

        Returns:
            None

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
            `pyadq.Error`: `parameter_id` is invalid

        """

        _enum_to_parameter_struct(parameter_id)

        buffer = ct.create_string_buffer(filename.encode("ascii"))

        result = self.ADQ_InitializeParametersFilename(parameter_id, buffer, format)
        if result < 0:
            raise ApiError(
                f"ADQ_InitializeParametersFilename failed."
                f", got {result}. See log file.",
                error_code=result,
            )

        return None

    def WriteUserRegister(
        self, ul_target: int, regnum: int, mask: int, data: int
    ) -> int:
        """Write data to a register in one of the user logic areas.

        Args:
            `ul_target`: The target user logic area
            `regnum`: The target register address
            `mask`: A negative bit mask, all bits with mask value 0 will be
                    affected by the write
            `data`: The register write data

        Returns:
            The readback data, read after write completion

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """

        retval = ct.c_uint32()
        result = self.ADQ_WriteUserRegister(
            ul_target, regnum, mask, data, ct.byref(retval)
        )

        if result < 0:
            raise ApiError(
                f"ADQ_WriteUserRegister failed. Got {result}. See log file.",
                error_code=result,
            )

        return retval.value

    def ReadUserRegister(self, ul_target: int, regnum: int) -> int:
        """Read data from a register in one of the user logic areas.

        Args:
            `ul_target`: The target user logic area
            `regnum`: The target register address

        Returns:
            The readback data

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """

        retval = ct.c_uint32()
        result = self.ADQ_ReadUserRegister(ul_target, regnum, ct.byref(retval))

        if result < 0:
            raise ApiError(
                f"ADQ_ReadUserRegister failed. Got {result}. See log file.",
                error_code=result,
            )

        return retval.value

    def DaisyChainGetTriggerInformation(
        self,
        source: int,
        edge: int,
        level: int,
        channel: int,
        start_record_number: int,
        nof_records: int,
        record_length: int,
        device_info: List[ADQDaisyChainDeviceInformation],
    ) -> List[ADQDaisyChainTriggerInformation]:
        """Get daisy chain trigger information

        See ADQAPI reference guide for usage.
        """

        nof_devices = len(device_info)
        device_info_array = (_ADQDaisyChainDeviceInformation * nof_devices)()

        for idx in range(nof_devices):
            device_info_array[idx] = device_info[idx]._to_ct()

        trig_info = (_ADQDaisyChainTriggerInformation * nof_records)()
        record_start_array_list = []
        extended_precision_array_list = []

        for i in range(nof_records):
            record_start_array_list.append((ct.c_int64 * nof_devices)())
            extended_precision_array_list.append((ct.c_double * nof_devices)())
            trig_info[i].Timestamp = 0
            trig_info[i].RecordStart = ct.cast(
                ct.pointer(record_start_array_list[-1]), ct.POINTER(ct.c_int64)
            )
            trig_info[i].ExtendedPrecision = ct.cast(
                ct.pointer(extended_precision_array_list[-1]), ct.POINTER(ct.c_double)
            )

        if not self.ADQ_DaisyChainGetTriggerInformation(
            source,
            edge,
            level,
            channel,
            start_record_number,
            nof_records,
            record_length,
            ct.cast(
                ct.byref(device_info_array), ct.POINTER(_ADQDaisyChainDeviceInformation)
            ),
            len(device_info),
            ct.cast(ct.byref(trig_info), ct.POINTER(_ADQDaisyChainTriggerInformation)),
        ):
            raise ApiError("DaisyChainGetTriggerInformation failed. See log file")

        ret = [ADQDaisyChainTriggerInformation(nof_devices) for x in range(nof_records)]
        for ridx in range(nof_records):
            ret[ridx].Timestamp = trig_info[ridx].Timestamp
            for didx in range(nof_devices):
                ret[ridx].RecordStart[didx] = trig_info[ridx].RecordStart[didx]
                ret[ridx].ExtendedPrecision[didx] = trig_info[ridx].ExtendedPrecision[
                    didx
                ]

        return ret

    def WaitForRecordBuffer(self, channel: int, timeout: int) -> RecordBuffer:
        """Wait for a record buffer.

        Args:
            `channel`: Channel to receive data from. Channels are indexed from 1.
            Set to pyadq.ADQ_ANY_CHANNEL to get the first available channel.
            `timeout`: Block until data is received or timeout reached. Set to 0
            for non-blocking

        Returns:
            RecordBuffer: See `RecordBuffer`

        Raises:
            `pyadq.ApiError`: ADQAPI call failed
            `pyadq.Timeout`: No data received within the specified timeout
            `pyadq.WaitForRecordBufferStatus`: Status != ADQ_DATA_READOUT_STATUS_FLAGS_OK
        """
        api_buffer: Union[ct.pointer[_ADQRecord], ct.pointer[_ADQGen4Record]]

        if self.ADQ_GetProductID() in [PID_ADQ8, PID_ADQ7, PID_ADQ14]:
            api_buffer = ct.POINTER(_ADQRecord)()
        elif self.ADQ_GetProductID() == PID_ADQ3:
            api_buffer = ct.POINTER(_ADQGen4Record)()
        else:
            raise Error(
                "Unsupported product with PID {}".format(self.ADQ_GetProductID())
            )

        nof_bytes: int = 0

        while nof_bytes == 0:
            readout_status = _ADQDataReadoutStatus()

            ct_channel = ct.c_int(channel)

            nof_bytes = self.ADQ_WaitForRecordBuffer(
                ct.byref(ct_channel),
                ct.cast(ct.byref(api_buffer), ct.POINTER(ct.c_void_p)),
                timeout,
                ct.byref(readout_status),
            )

            channel = ct_channel.value

            if nof_bytes == ADQ_EAGAIN:
                raise Timeout("Timeout while waiting for record buffer")
            elif nof_bytes == 0:
                if readout_status.flags != ADQ_DATA_READOUT_STATUS_FLAGS_OK:
                    raise WaitForRecordBufferStatus(readout_status._to_native())
            elif nof_bytes < 0:
                raise ApiError(
                    f"ADQ_WaitForRecordBuffer failed. "
                    f"Error code: {nof_bytes}. See log file.",
                    error_code=nof_bytes,
                )

        # Check if the header pointer is NULL. This can happen if
        # adq.transfer.channel[].metadata_enabled is set to zero.
        if api_buffer[0].header:
            header = api_buffer[0].header[0]._to_native()
        else:
            header = ADQGen4RecordHeader()
            header.channel = channel

        # TODO: Handle other data types?
        contents = ct.cast(
            api_buffer[0].data, ct.POINTER(ct.c_int16 * (nof_bytes // 2))
        ).contents
        data = np.copy(np.frombuffer(contents, dtype=np.int16))

        result: int = self.ADQ_ReturnRecordBuffer(channel, api_buffer)
        if result != ADQ_EOK:
            raise ApiError(
                f"ADQ_ReturnRecordBuffer failed. Error code: {result}. See log file.",
                error_code=result,
            )

        retbuf = RecordBuffer()
        retbuf.header = header
        retbuf.data = data
        return retbuf

    def GetData(
        self,
        start_record_number: int,
        nof_records: int,
        channel_mask: int,
        record_length: int,
    ) -> MultiRecordData:
        """Fetch (multirecord) data

        Fetch data using GetDataWHTS. Only supported when using multirecord.

        Args:
            `start_record_number`: The first record to collect. Indexed from 0
            `nof_records`: The number of records to collect
            `channel_mask`: Channels to collect. Bit 0 corresponds to channel
                            A, bit 1 to channel B etc.
            `record_length`: The record length in samples.
        Returns:
            A `MultiRecordData` object which contains the data and headers.
            Only channels selected with `channel_mask` will be available. E.g. if
            `channel_mask` is set to 0b10 then channel B will be available as

                MultiRecordData.data[0]
        Raises:
            `pyadq.ApiError`: ADQAPI call failed
        """

        if self.ADQ_GetProductID() not in [PID_ADQ7, PID_ADQ8]:
            raise Error(
                "Unsupported product with PID {}".format(self.ADQ_GetProductID())
            )

        target_buffers = (
            ct.POINTER(ct.c_int16 * (nof_records * record_length))
            * ADQ_MAX_NOF_CHANNELS
        )()

        for bufp in target_buffers:
            bufp.contents = (ct.c_int16 * (nof_records * record_length))()

        # Allocate target buffers for headers
        header_list = (_ADQRecordHeader * nof_records)()
        target_headers = ct.POINTER(_ADQRecordHeader * nof_records)()
        target_headers.contents = header_list

        if not self.ADQ_GetDataWHTS(
            ct.cast(target_buffers, ct.POINTER(ct.c_void_p)),
            ct.cast(target_headers, ct.c_void_p),
            None,
            nof_records * record_length,
            2,
            start_record_number,
            nof_records,
            channel_mask,
            0,
            record_length,
            0x00,
        ):
            raise ApiError("GetDataWHTS failed. See log file.")

        enabled_channels = []
        for ch in range(ADQ_MAX_NOF_CHANNELS):
            if channel_mask & (1 << ch):
                enabled_channels.append(ch)

        ret = MultiRecordData()
        ret.header = [x._to_native() for x in header_list]

        ret.data = np.ndarray((len(enabled_channels), nof_records, record_length))

        # FIXME: Return all channels?
        for i, ch in enumerate(enabled_channels):
            ret.data[i] = np.copy(
                np.frombuffer(
                    target_buffers[ch].contents,
                    dtype=np.int16,
                    count=record_length * nof_records,
                ).reshape(-1, record_length)
            )
        return ret
