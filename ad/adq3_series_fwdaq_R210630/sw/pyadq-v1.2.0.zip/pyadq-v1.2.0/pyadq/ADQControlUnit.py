# Copyright 2021 Teledyne Signal Processing Devices Sweden AB.

"""ADQControlUnit"""

import ctypes as ct
import os
from typing import List, Union, Callable, Optional

from .structs import (
    _c_utf8_p,
    _ADQInfoListEntry,
    ADQInfoListEntry,
    _ADQGen4RecordHeader,
    ADQAPI_VERSION_MAJOR,
    ADQAPI_VERSION_MINOR,
)
from .ADQ import ADQ
from .error import Error

# TODO: Where should we put these?
SIZEOF_ADQ_GEN4_HEADER: int = ct.sizeof(_ADQGen4RecordHeader)


class _ADQCtrlUnitFuncPtr:
    def __init__(self, ADQAPI, adq_cu, name, restype=None):
        if not name.startswith("ADQControlUnit_"):
            raise AttributeError(name)

        if restype is not None:
            self._restype_ = restype
        self._adq_cu = adq_cu
        self._func = ADQAPI.__getattr__(name)
        self.__name__ = name

    def __call__(self, *args, **kwargs) -> Callable:
        return self._func(self._adq_cu, *args, **kwargs)

    def __setattr__(self, name, lhs) -> None:
        if name == "restype":
            self._func.__setattr__(name, lhs)
        elif name == "argtypes":
            self._func.__setattr__(name, lhs)
        self.__dict__[name] = lhs

    def __getattr__(self, name):
        return self.__dict__[name]


class ADQControlUnit:
    """Thin python wrapper for the ADQControlUnit.

    This object wraps all `ADQControlUnit_` functions. For their documentation
    see the ADQAPI reference guide. It also wraps the adq_cu pointer. Compare

    Plain ctypes:
        ADQAPI = ct.cdll.LoadLibrary("libadq.so")
        adq_cu = ADQAPI.CreateADQControlUnit()
        ADQAPI.EnableErrorTrace(adq_cu, 1000)
        ADQAPI.FindDevices(adq_cu)

    becomes
        acu = ADQControlUnit()
        acu.EnableErrorTrace(1000)
        adq_list = acu.FindDevices()


    Args:
        `libadq_path` (optional):
            Path to libadq.so/ADQAPI.dll
        `check_version` (optional):
            Set to false to disable ADQAPI version compatibility check

    Returns:
        `ADQControlUnit` object

    Raises:
        `pyadq.ADQControlUnit.Error`: ADQAPI version not supported

    """

    def __init__(
        self,
        libadq_path: Union[str, None] = None,
        check_version: bool = True,
    ):
        """Init."""
        self._ADQAPI: Optional[ct.CDLL] = None
        self._adq_cu: Optional[ct.c_void_p] = None
        self._attrs: List[str] = []
        if libadq_path is None:
            if os.name == "nt":
                self._ADQAPI = ct.cdll.LoadLibrary("ADQAPI.dll")
            else:
                self._ADQAPI = ct.cdll.LoadLibrary("libadq.so")
        else:
            self._ADQAPI = ct.cdll.LoadLibrary(libadq_path)

        self._api_revision = str(self._ADQAPI.ADQAPI_GetRevision())

        self._api_path = self._ADQAPI._name

        if (
            check_version
            and self._ADQAPI.ADQAPI_ValidateVersion(
                ADQAPI_VERSION_MAJOR, ADQAPI_VERSION_MINOR
            )
            != 0
        ):
            raise Error("ADQAPI version not supported.")

        self._create_control_unit()

    def _create_control_unit(self) -> None:
        if self._adq_cu is None:
            if self._ADQAPI is None:
                raise Error("ADQAPI not loaded")

            self._open_devices: List[int] = []
            self._adq_info_list: List[ADQInfoListEntry] = []
            self._ADQAPI.CreateADQControlUnit.restype = ct.c_void_p
            self._adq_cu = ct.c_void_p(self._ADQAPI.CreateADQControlUnit())
            self.ADQControlUnit_FindDevices.argtypes = [ct.c_void_p]  # type: ignore
            self.ADQControlUnit_EnableErrorTrace.argtypes = [  # type: ignore
                ct.c_void_p,
                ct.c_uint,
                _c_utf8_p,
            ]

    def ListDevices(self) -> List[ADQInfoListEntry]:
        """List devices.

        List the available devices. See `ADQControlUnit_ListDevices` in the
        ADQAPI reference guide.

        Returns:
            A list of `pyadq.ADQInfoListEntry`. Each entry corresponds to one device.

        Raises:
            `pyadq.ADQControlUnit.Error`: `ADQControlUnit_ListDevices` failed
        """
        info_list_array = ct.POINTER(_ADQInfoListEntry)()
        ret_len = ct.c_uint()
        if not self.ADQControlUnit_ListDevices(
            ct.byref(info_list_array), ct.byref(ret_len)
        ):
            raise Error("ADQControlUnit_ListDevices failed")

        for dev in range(ret_len.value):
            self._adq_info_list.append(info_list_array[dev]._to_native())

        return self._adq_info_list

    def FindDevices(self) -> List[ADQ]:
        """Find and setup all available devices.

        Returns:
            A list of `pyadq.ADQ`. Each entry corresponds to one device.
        """
        device_list = self.ListDevices()
        adq_list = []
        for index in range(len(device_list)):
            self.OpenDeviceInterface(index)
            adq_list.append(self.SetupDevice(index))

        return adq_list

    def OpenDeviceInterface(self, entry_index: int) -> None:
        """Open ADQ device interface.

        See ADQAPI reference guide.

        Args:
            `entry_index`: Index of the device to open. Corresponds to the list
            index from `FindDevices`.

        Raises:
            pyadq.ADQControlUnit.Error: ADQControlUnit_OpenDeviceInterface failed

        """
        if not self.ADQControlUnit_OpenDeviceInterface(entry_index):
            raise Error("ADQControlUnit_OpenDeviceInterface failed")

    def _setup_device(self, entry_index: int) -> int:
        """Helper function"""
        if self._adq_cu is None:
            raise Error("No control unit created (internal error)")

        # TODO: Make NOP if already set up?
        if entry_index in self._open_devices:
            raise Error("Device already set up")

        if not self.ADQControlUnit_SetupDevice(entry_index):
            raise Error("ADQControlUnit_SetupDevice failed")

        self._open_devices += [entry_index]

        if self._ADQAPI is None:
            raise Error("ADQAPI not loaded")

        adq_num: int = self.ADQControlUnit_NofADQ()
        return adq_num

    def SetupDevice(self, entry_index: int) -> ADQ:
        """Setup ADQ device.

        See ADQAPI reference guide for more information.

        Args:
            `entry_index`: Index of the device to open. Corresponds to the list
            index from `FindDevices`.

        Returns:
            ADQ: The ADQ object
        """

        adq_num = self._setup_device(entry_index)

        # These asserts should never trigger (checked in _setup_device), but
        # mypy complains otherwise
        assert self._ADQAPI is not None
        assert self._adq_cu is not None

        return ADQ(self._ADQAPI, self._adq_cu, adq_num)

    def __getattr__(self, name: str) -> Callable:  # noqa: D105
        if not name.startswith("ADQControlUnit_"):
            raise AttributeError(name)

        func: Callable = _ADQCtrlUnitFuncPtr(self._ADQAPI, self._adq_cu, name)
        self._attrs.append(name)
        setattr(self, name, func)

        return func

    def DeleteAdqs(self):  # noqa: D405, D414, D416
        """Shutdown and delete the ADQ objects.

        TODO doc
        """
        if self._ADQAPI is not None and self._adq_cu is not None:
            for attr in self._attrs:
                delattr(self, attr)
            self._attrs = []

            self._open_devices = []
            self._ADQAPI.DeleteADQControlUnit(self._adq_cu)
            self._adq_cu = None

        self._create_control_unit()

    def __del__(self):  # noqa: D105
        if self._ADQAPI is not None and self._adq_cu is not None:
            self._ADQAPI.DeleteADQControlUnit(self._adq_cu)

    def __repr__(self):
        """String representation of `ADQControlUnit`."""
        return "<ADQControlUnit API r{}>".format(self._api_revision)
