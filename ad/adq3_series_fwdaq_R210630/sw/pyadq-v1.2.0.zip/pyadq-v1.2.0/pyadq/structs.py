#
# Copyright 2021 Teledyne Signal Processing Devices Sweden AB
#
# Automatically generated from ADQAPI.h
#
import ctypes as ct
from typing import List, Any, Union
from abc import ABC, abstractmethod

from .error import DeserializeError, Error


class _native_base(ABC):
    @abstractmethod
    def _to_dict(self) -> dict:
        raise NotImplementedError()

    @classmethod
    @abstractmethod
    def _from_dict(cls, dict_obj: dict):
        raise NotImplementedError()


class _struct_base(ct.Structure):
    pass


class _ADQDaisyChainTriggerInformation(_struct_base):
    _fields_ = [
        ("Timestamp", ct.c_uint64),
        ("RecordStart", ct.POINTER(ct.c_int64)),
        ("ExtendedPrecision", ct.POINTER(ct.c_double)),
    ]

    def __init__(self):
        super().__init__()


class ADQDaisyChainTriggerInformation(_native_base):
    def __init__(self, nof_devices: int):
        self.Timestamp: int = 0
        self.RecordStart: List[int] = [0] * nof_devices
        self.ExtendedPrecision: List[float] = [0.0] * nof_devices

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDaisyChainTriggerInformation" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDaisyChainTriggerInformation"
                )
            )

        ret = ADQDaisyChainTriggerInformation(len(obj["__raw__"]["RecordStart"]))
        ret.Timestamp = obj["__raw__"]["Timestamp"]
        ret.RecordStart = obj["__raw__"]["RecordStart"]
        ret.ExtendedPrecision = obj["__raw__"]["ExtendedPrecision"]

        return ret

    def _to_dict(self) -> dict:
        ret = {
            "name": self.__class__.__name__,
            "__raw__": {
                "Timestamp": self.Timestamp,
                "RecordStart": self.RecordStart,
                "ExtendedPrecision": self.ExtendedPrecision,
            },
        }
        return ret


class _ATDWFABufferStruct(_struct_base):
    _fields_ = [
        ("Timestamp", ct.c_uint64),
        ("Data", ct.POINTER(ct.c_int32)),
        ("RecordNumber", ct.c_uint32),
        ("Status", ct.c_uint32),
        ("RecordsAccumulated", ct.c_uint32),
        ("Channel", ct.c_uint8),
    ]

    def _to_native(self) -> "ATDWFABufferStruct":
        ret = ATDWFABufferStruct()
        ret.Timestamp = self.Timestamp
        ret.Data = self.Data
        ret.RecordNumber = self.RecordNumber
        ret.Status = self.Status
        ret.RecordsAccumulated = self.RecordsAccumulated
        ret.Channel = self.Channel
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ATDWFABufferStruct(_native_base):
    def __init__(self):
        self.Timestamp: int = 0
        self.Data: ct.POINTER(ct.c_int32) = ct.POINTER(ct.c_int32)()
        self.RecordNumber: int = 0
        self.Status: int = 0
        self.RecordsAccumulated: int = 0
        self.Channel: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "Timestamp",
            "Data",
            "RecordNumber",
            "Status",
            "RecordsAccumulated",
            "Channel",
        ]:
            raise AttributeError(f"No field named '{name}' for ATDWFABufferStruct")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ATDWFABufferStruct")

    def _to_ct(self) -> _ATDWFABufferStruct:
        ret = _ATDWFABufferStruct()
        ret.Timestamp = self.Timestamp
        ret.Data = self.Data
        ret.RecordNumber = self.RecordNumber
        ret.Status = self.Status
        ret.RecordsAccumulated = self.RecordsAccumulated
        ret.Channel = self.Channel
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ATDWFABufferStruct" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ATDWFABufferStruct"
                )
            )

        return ATDWFABufferStruct._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ATDWFABufferStruct()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQInfoListEntry(_struct_base):
    _fields_ = [
        ("HWIFType", ct.c_int),
        ("ProductID", ct.c_int),
        ("VendorID", ct.c_uint),
        ("AddressField1", ct.c_uint),
        ("AddressField2", ct.c_uint),
        ("DevFile", (ct.c_char * 64)),
        ("DeviceInterfaceOpened", ct.c_uint),
        ("DeviceSetupCompleted", ct.c_uint),
    ]

    def _to_native(self) -> "ADQInfoListEntry":
        ret = ADQInfoListEntry()
        ret.HWIFType = self.HWIFType
        ret.ProductID = self.ProductID
        ret.VendorID = self.VendorID
        ret.AddressField1 = self.AddressField1
        ret.AddressField2 = self.AddressField2
        ret.DevFile = self.DevFile.decode("ascii")
        ret.DeviceInterfaceOpened = self.DeviceInterfaceOpened
        ret.DeviceSetupCompleted = self.DeviceSetupCompleted
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQInfoListEntry(_native_base):
    def __init__(self):
        self.HWIFType: int = 0  # enum
        self.ProductID: int = 0  # enum
        self.VendorID: int = 0
        self.AddressField1: int = 0
        self.AddressField2: int = 0
        self.DevFile: str = ""
        self.DeviceInterfaceOpened: int = 0
        self.DeviceSetupCompleted: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "HWIFType",
            "ProductID",
            "VendorID",
            "AddressField1",
            "AddressField2",
            "DevFile",
            "DeviceInterfaceOpened",
            "DeviceSetupCompleted",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQInfoListEntry")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQInfoListEntry):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.HWIFType == other.HWIFType)
            and (self.ProductID == other.ProductID)
            and (self.VendorID == other.VendorID)
            and (self.AddressField1 == other.AddressField1)
            and (self.AddressField2 == other.AddressField2)
            and (self.DevFile == other.DevFile)
            and (self.DeviceInterfaceOpened == other.DeviceInterfaceOpened)
            and (self.DeviceSetupCompleted == other.DeviceSetupCompleted)
        )

    def _to_ct(self) -> _ADQInfoListEntry:
        ret = _ADQInfoListEntry()
        ret.HWIFType = self.HWIFType
        ret.ProductID = self.ProductID
        ret.VendorID = self.VendorID
        ret.AddressField1 = self.AddressField1
        ret.AddressField2 = self.AddressField2
        ret.DevFile = self.DevFile.encode("ascii")
        ret.DeviceInterfaceOpened = self.DeviceInterfaceOpened
        ret.DeviceSetupCompleted = self.DeviceSetupCompleted
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQInfoListEntry" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQInfoListEntry"
                )
            )

        return ADQInfoListEntry._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQInfoListEntry()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQInfoListPreAlloArray(_struct_base):
    _fields_ = [
        ("ADQlistArray", (_ADQInfoListEntry * 128)),
    ]

    def _to_native(self) -> "ADQInfoListPreAlloArray":
        ret = ADQInfoListPreAlloArray()
        ret.ADQlistArray = [a._to_native() for a in self.ADQlistArray]
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQInfoListPreAlloArray(_native_base):
    def __init__(self):
        self.ADQlistArray: List[ADQInfoListEntry] = [ADQInfoListEntry()] * 128

    def __setattr__(self, name, value):
        if name not in [
            "ADQlistArray",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQInfoListPreAlloArray")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQInfoListPreAlloArray")

    def _to_ct(self) -> _ADQInfoListPreAlloArray:
        ret = _ADQInfoListPreAlloArray()
        for a in range(len(self.ADQlistArray)):
            ret.ADQlistArray[a] = self.ADQlistArray[a]._to_ct()
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQInfoListPreAlloArray" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQInfoListPreAlloArray"
                )
            )

        return ADQInfoListPreAlloArray._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQInfoListPreAlloArray()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQRecordHeader(_struct_base):
    _fields_ = [
        ("RecordStatus", ct.c_uint8),
        ("UserID", ct.c_uint8),
        ("Channel", ct.c_uint8),
        ("DataFormat", ct.c_uint8),
        ("SerialNumber", ct.c_uint32),
        ("RecordNumber", ct.c_uint32),
        ("SamplePeriod", ct.c_int32),
        ("Timestamp", ct.c_uint64),
        ("RecordStart", ct.c_int64),
        ("RecordLength", ct.c_uint32),
        ("GeneralPurpose0", ct.c_uint16),
        ("GeneralPurpose1", ct.c_uint16),
    ]

    def _to_native(self) -> "ADQRecordHeader":
        ret = ADQRecordHeader()
        ret.RecordStatus = self.RecordStatus
        ret.UserID = self.UserID
        ret.Channel = self.Channel
        ret.DataFormat = self.DataFormat
        ret.SerialNumber = self.SerialNumber
        ret.RecordNumber = self.RecordNumber
        ret.SamplePeriod = self.SamplePeriod
        ret.Timestamp = self.Timestamp
        ret.RecordStart = self.RecordStart
        ret.RecordLength = self.RecordLength
        ret.GeneralPurpose0 = self.GeneralPurpose0
        ret.GeneralPurpose1 = self.GeneralPurpose1
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQRecordHeader(_native_base):
    def __init__(self):
        self.RecordStatus: int = 0
        self.UserID: int = 0
        self.Channel: int = 0
        self.DataFormat: int = 0
        self.SerialNumber: int = 0
        self.RecordNumber: int = 0
        self.SamplePeriod: int = 0
        self.Timestamp: int = 0
        self.RecordStart: int = 0
        self.RecordLength: int = 0
        self.GeneralPurpose0: int = 0
        self.GeneralPurpose1: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "RecordStatus",
            "UserID",
            "Channel",
            "DataFormat",
            "SerialNumber",
            "RecordNumber",
            "SamplePeriod",
            "Timestamp",
            "RecordStart",
            "RecordLength",
            "GeneralPurpose0",
            "GeneralPurpose1",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQRecordHeader")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQRecordHeader):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.RecordStatus == other.RecordStatus)
            and (self.UserID == other.UserID)
            and (self.Channel == other.Channel)
            and (self.DataFormat == other.DataFormat)
            and (self.SerialNumber == other.SerialNumber)
            and (self.RecordNumber == other.RecordNumber)
            and (self.SamplePeriod == other.SamplePeriod)
            and (self.Timestamp == other.Timestamp)
            and (self.RecordStart == other.RecordStart)
            and (self.RecordLength == other.RecordLength)
            and (self.GeneralPurpose0 == other.GeneralPurpose0)
            and (self.GeneralPurpose1 == other.GeneralPurpose1)
        )

    def _to_ct(self) -> _ADQRecordHeader:
        ret = _ADQRecordHeader()
        ret.RecordStatus = self.RecordStatus
        ret.UserID = self.UserID
        ret.Channel = self.Channel
        ret.DataFormat = self.DataFormat
        ret.SerialNumber = self.SerialNumber
        ret.RecordNumber = self.RecordNumber
        ret.SamplePeriod = self.SamplePeriod
        ret.Timestamp = self.Timestamp
        ret.RecordStart = self.RecordStart
        ret.RecordLength = self.RecordLength
        ret.GeneralPurpose0 = self.GeneralPurpose0
        ret.GeneralPurpose1 = self.GeneralPurpose1
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQRecordHeader" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQRecordHeader"
                )
            )

        return ADQRecordHeader._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQRecordHeader()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQRecord(_struct_base):
    _fields_ = [
        ("header", ct.POINTER(_ADQRecordHeader)),
        ("data", ct.c_void_p),
        ("size", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQRecord":
        ret = ADQRecord()
        ret.header = self.header
        ret.data = self.data
        ret.size = self.size
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQRecord(_native_base):
    def __init__(self):
        self.header: ct.POINTER(_ADQRecordHeader) = ct.POINTER(_ADQRecordHeader)()
        self.data: ct.c_void_p = ct.c_void_p()
        self.size: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "header",
            "data",
            "size",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQRecord")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQRecord")

    def _to_ct(self) -> _ADQRecord:
        ret = _ADQRecord()
        ret.header = self.header
        ret.data = self.data
        ret.size = self.size
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQRecord" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(obj["name"], "ADQRecord")
            )

        return ADQRecord._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQRecord()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDaisyChainDeviceInformation(_struct_base):
    _fields_ = [
        ("SampleRate", ct.c_int64),
        ("Position", ct.c_int64),
        ("PretriggerSamples", ct.c_int64),
        ("TriggerDelaySamples", ct.c_int64),
    ]

    def _to_native(self) -> "ADQDaisyChainDeviceInformation":
        ret = ADQDaisyChainDeviceInformation()
        ret.SampleRate = self.SampleRate
        ret.Position = self.Position
        ret.PretriggerSamples = self.PretriggerSamples
        ret.TriggerDelaySamples = self.TriggerDelaySamples
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDaisyChainDeviceInformation(_native_base):
    def __init__(self):
        self.SampleRate: int = 0
        self.Position: int = 0
        self.PretriggerSamples: int = 0
        self.TriggerDelaySamples: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "SampleRate",
            "Position",
            "PretriggerSamples",
            "TriggerDelaySamples",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDaisyChainDeviceInformation"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDaisyChainDeviceInformation):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.SampleRate == other.SampleRate)
            and (self.Position == other.Position)
            and (self.PretriggerSamples == other.PretriggerSamples)
            and (self.TriggerDelaySamples == other.TriggerDelaySamples)
        )

    def _to_ct(self) -> _ADQDaisyChainDeviceInformation:
        ret = _ADQDaisyChainDeviceInformation()
        ret.SampleRate = self.SampleRate
        ret.Position = self.Position
        ret.PretriggerSamples = self.PretriggerSamples
        ret.TriggerDelaySamples = self.TriggerDelaySamples
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDaisyChainDeviceInformation" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDaisyChainDeviceInformation"
                )
            )

        return ADQDaisyChainDeviceInformation._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDaisyChainDeviceInformation()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _SDCardConfiguration(_struct_base):
    _fields_ = [
        ("Version", ct.c_uint),
        ("Valid", ct.c_uint),
        ("Length", ct.c_uint),
        ("SerialNumber", (ct.c_char * 16)),
        ("ISODate", (ct.c_char * 32)),
        ("NumberOfChannels", ct.c_uint),
        ("ChannelMask", ct.c_uint),
        ("NumberOfParallelSamples", ct.c_uint),
        ("CyclicBuffersEnabled", ct.c_uint),
        ("ChunkSize", ct.c_uint),
        ("TriggerMode", ct.c_uint),
        ("DaisyChainPosition", ct.c_int),
        ("CBufSize", ct.c_uint),
        ("CBufMemArea", ct.c_uint),
        ("RecordLength", (ct.c_uint * 8)),
        ("NumberOfRecords", (ct.c_uint * 8)),
        ("SampleSkip", (ct.c_uint * 8)),
        ("PreTrigger", (ct.c_uint * 8)),
        ("TriggerDelay", (ct.c_uint * 8)),
    ]

    def _to_native(self) -> "SDCardConfiguration":
        ret = SDCardConfiguration()
        ret.Version = self.Version
        ret.Valid = self.Valid
        ret.Length = self.Length
        ret.SerialNumber = self.SerialNumber.decode("ascii")
        ret.ISODate = self.ISODate.decode("ascii")
        ret.NumberOfChannels = self.NumberOfChannels
        ret.ChannelMask = self.ChannelMask
        ret.NumberOfParallelSamples = self.NumberOfParallelSamples
        ret.CyclicBuffersEnabled = self.CyclicBuffersEnabled
        ret.ChunkSize = self.ChunkSize
        ret.TriggerMode = self.TriggerMode
        ret.DaisyChainPosition = self.DaisyChainPosition
        ret.CBufSize = self.CBufSize
        ret.CBufMemArea = self.CBufMemArea
        ret.RecordLength = [a for a in self.RecordLength]
        ret.NumberOfRecords = [a for a in self.NumberOfRecords]
        ret.SampleSkip = [a for a in self.SampleSkip]
        ret.PreTrigger = [a for a in self.PreTrigger]
        ret.TriggerDelay = [a for a in self.TriggerDelay]
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class SDCardConfiguration(_native_base):
    def __init__(self):
        self.Version: int = 0
        self.Valid: int = 0
        self.Length: int = 0
        self.SerialNumber: str = ""
        self.ISODate: str = ""
        self.NumberOfChannels: int = 0
        self.ChannelMask: int = 0
        self.NumberOfParallelSamples: int = 0
        self.CyclicBuffersEnabled: int = 0
        self.ChunkSize: int = 0
        self.TriggerMode: int = 0
        self.DaisyChainPosition: int = 0
        self.CBufSize: int = 0
        self.CBufMemArea: int = 0
        self.RecordLength: List[int] = [0] * 8
        self.NumberOfRecords: List[int] = [0] * 8
        self.SampleSkip: List[int] = [0] * 8
        self.PreTrigger: List[int] = [0] * 8
        self.TriggerDelay: List[int] = [0] * 8

    def __setattr__(self, name, value):
        if name not in [
            "Version",
            "Valid",
            "Length",
            "SerialNumber",
            "ISODate",
            "NumberOfChannels",
            "ChannelMask",
            "NumberOfParallelSamples",
            "CyclicBuffersEnabled",
            "ChunkSize",
            "TriggerMode",
            "DaisyChainPosition",
            "CBufSize",
            "CBufMemArea",
            "RecordLength",
            "NumberOfRecords",
            "SampleSkip",
            "PreTrigger",
            "TriggerDelay",
        ]:
            raise AttributeError(f"No field named '{name}' for SDCardConfiguration")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, SDCardConfiguration):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.Version == other.Version)
            and (self.Valid == other.Valid)
            and (self.Length == other.Length)
            and (self.SerialNumber == other.SerialNumber)
            and (self.ISODate == other.ISODate)
            and (self.NumberOfChannels == other.NumberOfChannels)
            and (self.ChannelMask == other.ChannelMask)
            and (self.NumberOfParallelSamples == other.NumberOfParallelSamples)
            and (self.CyclicBuffersEnabled == other.CyclicBuffersEnabled)
            and (self.ChunkSize == other.ChunkSize)
            and (self.TriggerMode == other.TriggerMode)
            and (self.DaisyChainPosition == other.DaisyChainPosition)
            and (self.CBufSize == other.CBufSize)
            and (self.CBufMemArea == other.CBufMemArea)
            and (self.RecordLength == other.RecordLength)
            and (self.NumberOfRecords == other.NumberOfRecords)
            and (self.SampleSkip == other.SampleSkip)
            and (self.PreTrigger == other.PreTrigger)
            and (self.TriggerDelay == other.TriggerDelay)
        )

    def _to_ct(self) -> _SDCardConfiguration:
        ret = _SDCardConfiguration()
        ret.Version = self.Version
        ret.Valid = self.Valid
        ret.Length = self.Length
        ret.SerialNumber = self.SerialNumber.encode("ascii")
        ret.ISODate = self.ISODate.encode("ascii")
        ret.NumberOfChannels = self.NumberOfChannels
        ret.ChannelMask = self.ChannelMask
        ret.NumberOfParallelSamples = self.NumberOfParallelSamples
        ret.CyclicBuffersEnabled = self.CyclicBuffersEnabled
        ret.ChunkSize = self.ChunkSize
        ret.TriggerMode = self.TriggerMode
        ret.DaisyChainPosition = self.DaisyChainPosition
        ret.CBufSize = self.CBufSize
        ret.CBufMemArea = self.CBufMemArea
        for a in range(len(self.RecordLength)):
            ret.RecordLength[a] = self.RecordLength[a]
        for a in range(len(self.NumberOfRecords)):
            ret.NumberOfRecords[a] = self.NumberOfRecords[a]
        for a in range(len(self.SampleSkip)):
            ret.SampleSkip[a] = self.SampleSkip[a]
        for a in range(len(self.PreTrigger)):
            ret.PreTrigger[a] = self.PreTrigger[a]
        for a in range(len(self.TriggerDelay)):
            ret.TriggerDelay[a] = self.TriggerDelay[a]
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "SDCardConfiguration" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "SDCardConfiguration"
                )
            )

        return SDCardConfiguration._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _SDCardConfiguration()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQOverflowStatus(_struct_base):
    _fields_ = [
        ("overflow", ct.c_int32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQOverflowStatus":
        ret = ADQOverflowStatus()
        ret.overflow = self.overflow
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQOverflowStatus(_native_base):
    def __init__(self):
        self.overflow: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "overflow",
            "reserved",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQOverflowStatus")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQOverflowStatus):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (self.overflow == other.overflow) and (self.reserved == other.reserved)

    def _to_ct(self) -> _ADQOverflowStatus:
        ret = _ADQOverflowStatus()
        ret.overflow = self.overflow
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQOverflowStatus" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQOverflowStatus"
                )
            )

        return ADQOverflowStatus._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQOverflowStatus()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDramStatus(_struct_base):
    _fields_ = [
        ("fill", ct.c_uint64),
        ("fill_max", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQDramStatus":
        ret = ADQDramStatus()
        ret.fill = self.fill
        ret.fill_max = self.fill_max
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDramStatus(_native_base):
    def __init__(self):
        self.fill: int = 0
        self.fill_max: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "fill",
            "fill_max",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQDramStatus")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDramStatus):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (self.fill == other.fill) and (self.fill_max == other.fill_max)

    def _to_ct(self) -> _ADQDramStatus:
        ret = _ADQDramStatus()
        ret.fill = self.fill
        ret.fill_max = self.fill_max
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDramStatus" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDramStatus"
                )
            )

        return ADQDramStatus._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDramStatus()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQAcquisitionStatus(_struct_base):
    _fields_ = [
        ("acquired_records", (ct.c_int64 * 8)),
    ]

    def _to_native(self) -> "ADQAcquisitionStatus":
        ret = ADQAcquisitionStatus()
        ret.acquired_records = [a for a in self.acquired_records]
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQAcquisitionStatus(_native_base):
    def __init__(self):
        self.acquired_records: List[int] = [0] * 8

    def __setattr__(self, name, value):
        if name not in [
            "acquired_records",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQAcquisitionStatus")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQAcquisitionStatus):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return self.acquired_records == other.acquired_records

    def _to_ct(self) -> _ADQAcquisitionStatus:
        ret = _ADQAcquisitionStatus()
        for a in range(len(self.acquired_records)):
            ret.acquired_records[a] = self.acquired_records[a]
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQAcquisitionStatus" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQAcquisitionStatus"
                )
            )

        return ADQAcquisitionStatus._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQAcquisitionStatus()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQTemperatureStatusSensor(_struct_base):
    _fields_ = [
        ("label", (ct.c_char * 32)),
        ("value", ct.c_float),
    ]

    def _to_native(self) -> "ADQTemperatureStatusSensor":
        ret = ADQTemperatureStatusSensor()
        ret.label = self.label.decode("ascii")
        ret.value = self.value
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQTemperatureStatusSensor(_native_base):
    def __init__(self):
        self.label: str = ""
        self.value: float = 0

    def __setattr__(self, name, value):
        if name not in [
            "label",
            "value",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQTemperatureStatusSensor"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQTemperatureStatusSensor):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (self.label == other.label) and (self.value == other.value)

    def _to_ct(self) -> _ADQTemperatureStatusSensor:
        ret = _ADQTemperatureStatusSensor()
        ret.label = self.label.encode("ascii")
        ret.value = self.value
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQTemperatureStatusSensor" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQTemperatureStatusSensor"
                )
            )

        return ADQTemperatureStatusSensor._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQTemperatureStatusSensor()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQTemperatureStatus(_struct_base):
    _fields_ = [
        ("nof_sensors", ct.c_int32),
        ("sensor", (_ADQTemperatureStatusSensor * 16)),
    ]

    def _to_native(self) -> "ADQTemperatureStatus":
        ret = ADQTemperatureStatus()
        ret.nof_sensors = self.nof_sensors
        ret.sensor = [a._to_native() for a in self.sensor]
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQTemperatureStatus(_native_base):
    def __init__(self):
        self.nof_sensors: int = 0
        self.sensor: List[ADQTemperatureStatusSensor] = [
            ADQTemperatureStatusSensor()
        ] * 16

    def __setattr__(self, name, value):
        if name not in [
            "nof_sensors",
            "sensor",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQTemperatureStatus")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQTemperatureStatus")

    def _to_ct(self) -> _ADQTemperatureStatus:
        ret = _ADQTemperatureStatus()
        ret.nof_sensors = self.nof_sensors
        for a in range(len(self.sensor)):
            ret.sensor[a] = self.sensor[a]._to_ct()
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQTemperatureStatus" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQTemperatureStatus"
                )
            )

        return ADQTemperatureStatus._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQTemperatureStatus()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQGen4RecordHeader(_struct_base):
    _fields_ = [
        ("version_major", ct.c_uint8),
        ("version_minor", ct.c_uint8),
        ("timestamp_synchronization_counter", ct.c_uint16),
        ("general_purpose_start", ct.c_uint16),
        ("general_purpose_stop", ct.c_uint16),
        ("timestamp", ct.c_uint64),
        ("record_start", ct.c_int64),
        ("record_length", ct.c_uint32),
        ("user_id", ct.c_uint8),
        ("misc", ct.c_uint8),
        ("record_status", ct.c_uint16),
        ("record_number", ct.c_uint32),
        ("channel", ct.c_uint8),
        ("data_format", ct.c_uint8),
        ("serial_number", (ct.c_char * 10)),
        ("sampling_period", ct.c_uint64),
        ("time_unit", ct.c_float),
        ("reserved", ct.c_uint32),
    ]

    def _to_native(self) -> "ADQGen4RecordHeader":
        ret = ADQGen4RecordHeader()
        ret.version_major = self.version_major
        ret.version_minor = self.version_minor
        ret.timestamp_synchronization_counter = self.timestamp_synchronization_counter
        ret.general_purpose_start = self.general_purpose_start
        ret.general_purpose_stop = self.general_purpose_stop
        ret.timestamp = self.timestamp
        ret.record_start = self.record_start
        ret.record_length = self.record_length
        ret.user_id = self.user_id
        ret.misc = self.misc
        ret.record_status = self.record_status
        ret.record_number = self.record_number
        ret.channel = self.channel
        ret.data_format = self.data_format
        ret.serial_number = self.serial_number.decode("ascii")
        ret.sampling_period = self.sampling_period
        ret.time_unit = self.time_unit
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQGen4RecordHeader(_native_base):
    def __init__(self):
        self.version_major: int = 0
        self.version_minor: int = 0
        self.timestamp_synchronization_counter: int = 0
        self.general_purpose_start: int = 0
        self.general_purpose_stop: int = 0
        self.timestamp: int = 0
        self.record_start: int = 0
        self.record_length: int = 0
        self.user_id: int = 0
        self.misc: int = 0
        self.record_status: int = 0
        self.record_number: int = 0
        self.channel: int = 0
        self.data_format: int = 0
        self.serial_number: str = ""
        self.sampling_period: int = 0
        self.time_unit: float = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "version_major",
            "version_minor",
            "timestamp_synchronization_counter",
            "general_purpose_start",
            "general_purpose_stop",
            "timestamp",
            "record_start",
            "record_length",
            "user_id",
            "misc",
            "record_status",
            "record_number",
            "channel",
            "data_format",
            "serial_number",
            "sampling_period",
            "time_unit",
            "reserved",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQGen4RecordHeader")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQGen4RecordHeader):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.version_major == other.version_major)
            and (self.version_minor == other.version_minor)
            and (
                self.timestamp_synchronization_counter
                == other.timestamp_synchronization_counter
            )
            and (self.general_purpose_start == other.general_purpose_start)
            and (self.general_purpose_stop == other.general_purpose_stop)
            and (self.timestamp == other.timestamp)
            and (self.record_start == other.record_start)
            and (self.record_length == other.record_length)
            and (self.user_id == other.user_id)
            and (self.misc == other.misc)
            and (self.record_status == other.record_status)
            and (self.record_number == other.record_number)
            and (self.channel == other.channel)
            and (self.data_format == other.data_format)
            and (self.serial_number == other.serial_number)
            and (self.sampling_period == other.sampling_period)
            and (self.time_unit == other.time_unit)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQGen4RecordHeader:
        ret = _ADQGen4RecordHeader()
        ret.version_major = self.version_major
        ret.version_minor = self.version_minor
        ret.timestamp_synchronization_counter = self.timestamp_synchronization_counter
        ret.general_purpose_start = self.general_purpose_start
        ret.general_purpose_stop = self.general_purpose_stop
        ret.timestamp = self.timestamp
        ret.record_start = self.record_start
        ret.record_length = self.record_length
        ret.user_id = self.user_id
        ret.misc = self.misc
        ret.record_status = self.record_status
        ret.record_number = self.record_number
        ret.channel = self.channel
        ret.data_format = self.data_format
        ret.serial_number = self.serial_number.encode("ascii")
        ret.sampling_period = self.sampling_period
        ret.time_unit = self.time_unit
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQGen4RecordHeader" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQGen4RecordHeader"
                )
            )

        return ADQGen4RecordHeader._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQGen4RecordHeader()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQGen4RecordHeaderRaw(_struct_base):
    _fields_ = [
        ("version_major", ct.c_uint8),
        ("version_minor", ct.c_uint8),
        ("timestamp_synchronization_counter", ct.c_uint16),
        ("general_purpose_start", ct.c_uint16),
        ("general_purpose_stop", ct.c_uint16),
        ("timestamp", ct.c_uint64),
        ("trigger_vector", ct.c_uint32),
        ("record_start_index", ct.c_uint8),
        ("pad0", (ct.c_uint8 * 3)),
        ("record_length", ct.c_uint32),
        ("user_id", ct.c_uint8),
        ("misc", ct.c_uint8),
        ("record_status", ct.c_uint16),
        ("record_number", ct.c_uint32),
        ("channel", ct.c_uint8),
        ("data_format", ct.c_uint8),
        ("serial_number", (ct.c_char * 10)),
        ("sampling_period", ct.c_uint64),
        ("time_unit", ct.c_float),
        ("reserved", ct.c_uint32),
    ]

    def _to_native(self) -> "ADQGen4RecordHeaderRaw":
        ret = ADQGen4RecordHeaderRaw()
        ret.version_major = self.version_major
        ret.version_minor = self.version_minor
        ret.timestamp_synchronization_counter = self.timestamp_synchronization_counter
        ret.general_purpose_start = self.general_purpose_start
        ret.general_purpose_stop = self.general_purpose_stop
        ret.timestamp = self.timestamp
        ret.trigger_vector = self.trigger_vector
        ret.record_start_index = self.record_start_index
        ret.pad0 = [a for a in self.pad0]
        ret.record_length = self.record_length
        ret.user_id = self.user_id
        ret.misc = self.misc
        ret.record_status = self.record_status
        ret.record_number = self.record_number
        ret.channel = self.channel
        ret.data_format = self.data_format
        ret.serial_number = self.serial_number.decode("ascii")
        ret.sampling_period = self.sampling_period
        ret.time_unit = self.time_unit
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQGen4RecordHeaderRaw(_native_base):
    def __init__(self):
        self.version_major: int = 0
        self.version_minor: int = 0
        self.timestamp_synchronization_counter: int = 0
        self.general_purpose_start: int = 0
        self.general_purpose_stop: int = 0
        self.timestamp: int = 0
        self.trigger_vector: int = 0
        self.record_start_index: int = 0
        self.pad0: List[int] = [0] * 3
        self.record_length: int = 0
        self.user_id: int = 0
        self.misc: int = 0
        self.record_status: int = 0
        self.record_number: int = 0
        self.channel: int = 0
        self.data_format: int = 0
        self.serial_number: str = ""
        self.sampling_period: int = 0
        self.time_unit: float = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "version_major",
            "version_minor",
            "timestamp_synchronization_counter",
            "general_purpose_start",
            "general_purpose_stop",
            "timestamp",
            "trigger_vector",
            "record_start_index",
            "pad0",
            "record_length",
            "user_id",
            "misc",
            "record_status",
            "record_number",
            "channel",
            "data_format",
            "serial_number",
            "sampling_period",
            "time_unit",
            "reserved",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQGen4RecordHeaderRaw")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQGen4RecordHeaderRaw):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.version_major == other.version_major)
            and (self.version_minor == other.version_minor)
            and (
                self.timestamp_synchronization_counter
                == other.timestamp_synchronization_counter
            )
            and (self.general_purpose_start == other.general_purpose_start)
            and (self.general_purpose_stop == other.general_purpose_stop)
            and (self.timestamp == other.timestamp)
            and (self.trigger_vector == other.trigger_vector)
            and (self.record_start_index == other.record_start_index)
            and (self.pad0 == other.pad0)
            and (self.record_length == other.record_length)
            and (self.user_id == other.user_id)
            and (self.misc == other.misc)
            and (self.record_status == other.record_status)
            and (self.record_number == other.record_number)
            and (self.channel == other.channel)
            and (self.data_format == other.data_format)
            and (self.serial_number == other.serial_number)
            and (self.sampling_period == other.sampling_period)
            and (self.time_unit == other.time_unit)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQGen4RecordHeaderRaw:
        ret = _ADQGen4RecordHeaderRaw()
        ret.version_major = self.version_major
        ret.version_minor = self.version_minor
        ret.timestamp_synchronization_counter = self.timestamp_synchronization_counter
        ret.general_purpose_start = self.general_purpose_start
        ret.general_purpose_stop = self.general_purpose_stop
        ret.timestamp = self.timestamp
        ret.trigger_vector = self.trigger_vector
        ret.record_start_index = self.record_start_index
        for a in range(len(self.pad0)):
            ret.pad0[a] = self.pad0[a]
        ret.record_length = self.record_length
        ret.user_id = self.user_id
        ret.misc = self.misc
        ret.record_status = self.record_status
        ret.record_number = self.record_number
        ret.channel = self.channel
        ret.data_format = self.data_format
        ret.serial_number = self.serial_number.encode("ascii")
        ret.sampling_period = self.sampling_period
        ret.time_unit = self.time_unit
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQGen4RecordHeaderRaw" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQGen4RecordHeaderRaw"
                )
            )

        return ADQGen4RecordHeaderRaw._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQGen4RecordHeaderRaw()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQGen4Record(_struct_base):
    _fields_ = [
        ("header", ct.POINTER(_ADQGen4RecordHeader)),
        ("data", ct.c_void_p),
        ("size", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQGen4Record":
        ret = ADQGen4Record()
        ret.header = self.header
        ret.data = self.data
        ret.size = self.size
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQGen4Record(_native_base):
    def __init__(self):
        self.header: ct.POINTER(_ADQGen4RecordHeader) = ct.POINTER(
            _ADQGen4RecordHeader
        )()
        self.data: ct.c_void_p = ct.c_void_p()
        self.size: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "header",
            "data",
            "size",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQGen4Record")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQGen4Record")

    def _to_ct(self) -> _ADQGen4Record:
        ret = _ADQGen4Record()
        ret.header = self.header
        ret.data = self.data
        ret.size = self.size
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQGen4Record" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQGen4Record"
                )
            )

        return ADQGen4Record._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQGen4Record()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQClockSystemParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("clock_generator", ct.c_int),
        ("reference_source", ct.c_int),
        ("sampling_frequency", ct.c_double),
        ("reference_frequency", ct.c_double),
        ("delay_adjustment", ct.c_double),
        ("low_jitter_mode_enabled", ct.c_int32),
        ("delay_adjustment_enabled", ct.c_int32),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQClockSystemParameters":
        ret = ADQClockSystemParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.clock_generator = self.clock_generator
        ret.reference_source = self.reference_source
        ret.sampling_frequency = self.sampling_frequency
        ret.reference_frequency = self.reference_frequency
        ret.delay_adjustment = self.delay_adjustment
        ret.low_jitter_mode_enabled = self.low_jitter_mode_enabled
        ret.delay_adjustment_enabled = self.delay_adjustment_enabled
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQClockSystemParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.clock_generator: int = 0  # enum
        self.reference_source: int = 0  # enum
        self.sampling_frequency: float = 0
        self.reference_frequency: float = 0
        self.delay_adjustment: float = 0
        self.low_jitter_mode_enabled: int = 0
        self.delay_adjustment_enabled: int = 0
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "clock_generator",
            "reference_source",
            "sampling_frequency",
            "reference_frequency",
            "delay_adjustment",
            "low_jitter_mode_enabled",
            "delay_adjustment_enabled",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQClockSystemParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQClockSystemParameters):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.id == other.id)
            and (self.reserved == other.reserved)
            and (self.clock_generator == other.clock_generator)
            and (self.reference_source == other.reference_source)
            and (self.sampling_frequency == other.sampling_frequency)
            and (self.reference_frequency == other.reference_frequency)
            and (self.delay_adjustment == other.delay_adjustment)
            and (self.low_jitter_mode_enabled == other.low_jitter_mode_enabled)
            and (self.delay_adjustment_enabled == other.delay_adjustment_enabled)
            and (self.magic == other.magic)
        )

    def _to_ct(self) -> _ADQClockSystemParameters:
        ret = _ADQClockSystemParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.clock_generator = self.clock_generator
        ret.reference_source = self.reference_source
        ret.sampling_frequency = self.sampling_frequency
        ret.reference_frequency = self.reference_frequency
        ret.delay_adjustment = self.delay_adjustment
        ret.low_jitter_mode_enabled = self.low_jitter_mode_enabled
        ret.delay_adjustment_enabled = self.delay_adjustment_enabled
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQClockSystemParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQClockSystemParameters"
                )
            )

        return ADQClockSystemParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQClockSystemParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQPatternGeneratorInstruction(_struct_base):
    _fields_ = [
        ("count", ct.c_int64),
        ("count_prescaling", ct.c_int64),
        ("op", ct.c_int),
        ("source", ct.c_int),
        ("source_edge", ct.c_int),
        ("reset_source", ct.c_int),
        ("reset_source_edge", ct.c_int),
        ("output_value", ct.c_int32),
        ("output_value_transition", ct.c_int32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQPatternGeneratorInstruction":
        ret = ADQPatternGeneratorInstruction()
        ret.count = self.count
        ret.count_prescaling = self.count_prescaling
        ret.op = self.op
        ret.source = self.source
        ret.source_edge = self.source_edge
        ret.reset_source = self.reset_source
        ret.reset_source_edge = self.reset_source_edge
        ret.output_value = self.output_value
        ret.output_value_transition = self.output_value_transition
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQPatternGeneratorInstruction(_native_base):
    def __init__(self):
        self.count: int = 0
        self.count_prescaling: int = 0
        self.op: int = 0  # enum
        self.source: int = 0  # enum
        self.source_edge: int = 0  # enum
        self.reset_source: int = 0  # enum
        self.reset_source_edge: int = 0  # enum
        self.output_value: int = 0
        self.output_value_transition: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "count",
            "count_prescaling",
            "op",
            "source",
            "source_edge",
            "reset_source",
            "reset_source_edge",
            "output_value",
            "output_value_transition",
            "reserved",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQPatternGeneratorInstruction"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQPatternGeneratorInstruction):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.count == other.count)
            and (self.count_prescaling == other.count_prescaling)
            and (self.op == other.op)
            and (self.source == other.source)
            and (self.source_edge == other.source_edge)
            and (self.reset_source == other.reset_source)
            and (self.reset_source_edge == other.reset_source_edge)
            and (self.output_value == other.output_value)
            and (self.output_value_transition == other.output_value_transition)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQPatternGeneratorInstruction:
        ret = _ADQPatternGeneratorInstruction()
        ret.count = self.count
        ret.count_prescaling = self.count_prescaling
        ret.op = self.op
        ret.source = self.source
        ret.source_edge = self.source_edge
        ret.reset_source = self.reset_source
        ret.reset_source_edge = self.reset_source_edge
        ret.output_value = self.output_value
        ret.output_value_transition = self.output_value_transition
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQPatternGeneratorInstruction" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQPatternGeneratorInstruction"
                )
            )

        return ADQPatternGeneratorInstruction._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQPatternGeneratorInstruction()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQPatternGeneratorParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("nof_instructions", ct.c_int32),
        ("instruction", (_ADQPatternGeneratorInstruction * 16)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQPatternGeneratorParameters":
        ret = ADQPatternGeneratorParameters()
        ret.id = self.id
        ret.nof_instructions = self.nof_instructions
        ret.instruction = [a._to_native() for a in self.instruction]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQPatternGeneratorParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.nof_instructions: int = 0
        self.instruction: List[ADQPatternGeneratorInstruction] = [
            ADQPatternGeneratorInstruction()
        ] * 16
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "nof_instructions",
            "instruction",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQPatternGeneratorParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQPatternGeneratorParameters"
        )

    def _to_ct(self) -> _ADQPatternGeneratorParameters:
        ret = _ADQPatternGeneratorParameters()
        ret.id = self.id
        ret.nof_instructions = self.nof_instructions
        for a in range(len(self.instruction)):
            ret.instruction[a] = self.instruction[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQPatternGeneratorParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQPatternGeneratorParameters"
                )
            )

        return ADQPatternGeneratorParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQPatternGeneratorParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQPulseGeneratorParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("source", ct.c_int),
        ("edge", ct.c_int),
        ("reserved", ct.c_int32),
        ("length", ct.c_int64),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQPulseGeneratorParameters":
        ret = ADQPulseGeneratorParameters()
        ret.id = self.id
        ret.source = self.source
        ret.edge = self.edge
        ret.reserved = self.reserved
        ret.length = self.length
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQPulseGeneratorParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.source: int = 0  # enum
        self.edge: int = 0  # enum
        self.reserved: int = 0
        self.length: int = 0
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "source",
            "edge",
            "reserved",
            "length",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQPulseGeneratorParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQPulseGeneratorParameters):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.id == other.id)
            and (self.source == other.source)
            and (self.edge == other.edge)
            and (self.reserved == other.reserved)
            and (self.length == other.length)
            and (self.magic == other.magic)
        )

    def _to_ct(self) -> _ADQPulseGeneratorParameters:
        ret = _ADQPulseGeneratorParameters()
        ret.id = self.id
        ret.source = self.source
        ret.edge = self.edge
        ret.reserved = self.reserved
        ret.length = self.length
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQPulseGeneratorParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQPulseGeneratorParameters"
                )
            )

        return ADQPulseGeneratorParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQPulseGeneratorParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataAcquisitionParametersCommon(_struct_base):
    _fields_ = [
        ("reserved", ct.c_int64),
    ]

    def _to_native(self) -> "ADQDataAcquisitionParametersCommon":
        ret = ADQDataAcquisitionParametersCommon()
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataAcquisitionParametersCommon(_native_base):
    def __init__(self):
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "reserved",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataAcquisitionParametersCommon"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDataAcquisitionParametersCommon):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return self.reserved == other.reserved

    def _to_ct(self) -> _ADQDataAcquisitionParametersCommon:
        ret = _ADQDataAcquisitionParametersCommon()
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataAcquisitionParametersCommon" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataAcquisitionParametersCommon"
                )
            )

        return ADQDataAcquisitionParametersCommon._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataAcquisitionParametersCommon()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataAcquisitionParametersChannel(_struct_base):
    _fields_ = [
        ("horizontal_offset", ct.c_int64),
        ("record_length", ct.c_int64),
        ("nof_records", ct.c_int64),
        ("trigger_source", ct.c_int),
        ("trigger_edge", ct.c_int),
        ("trigger_blocking_source", ct.c_int),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQDataAcquisitionParametersChannel":
        ret = ADQDataAcquisitionParametersChannel()
        ret.horizontal_offset = self.horizontal_offset
        ret.record_length = self.record_length
        ret.nof_records = self.nof_records
        ret.trigger_source = self.trigger_source
        ret.trigger_edge = self.trigger_edge
        ret.trigger_blocking_source = self.trigger_blocking_source
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataAcquisitionParametersChannel(_native_base):
    def __init__(self):
        self.horizontal_offset: int = 0
        self.record_length: int = 0
        self.nof_records: int = 0
        self.trigger_source: int = 0  # enum
        self.trigger_edge: int = 0  # enum
        self.trigger_blocking_source: int = 0  # enum
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "horizontal_offset",
            "record_length",
            "nof_records",
            "trigger_source",
            "trigger_edge",
            "trigger_blocking_source",
            "reserved",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataAcquisitionParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDataAcquisitionParametersChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.horizontal_offset == other.horizontal_offset)
            and (self.record_length == other.record_length)
            and (self.nof_records == other.nof_records)
            and (self.trigger_source == other.trigger_source)
            and (self.trigger_edge == other.trigger_edge)
            and (self.trigger_blocking_source == other.trigger_blocking_source)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQDataAcquisitionParametersChannel:
        ret = _ADQDataAcquisitionParametersChannel()
        ret.horizontal_offset = self.horizontal_offset
        ret.record_length = self.record_length
        ret.nof_records = self.nof_records
        ret.trigger_source = self.trigger_source
        ret.trigger_edge = self.trigger_edge
        ret.trigger_blocking_source = self.trigger_blocking_source
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataAcquisitionParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataAcquisitionParametersChannel"
                )
            )

        return ADQDataAcquisitionParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataAcquisitionParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataAcquisitionParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("common", _ADQDataAcquisitionParametersCommon),
        ("channel", (_ADQDataAcquisitionParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQDataAcquisitionParameters":
        ret = ADQDataAcquisitionParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.common = self.common._to_native()
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataAcquisitionParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.common: ADQDataAcquisitionParametersCommon = (
            ADQDataAcquisitionParametersCommon()
        )
        self.channel: List[ADQDataAcquisitionParametersChannel] = [
            ADQDataAcquisitionParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "common",
            "channel",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataAcquisitionParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQDataAcquisitionParameters"
        )

    def _to_ct(self) -> _ADQDataAcquisitionParameters:
        ret = _ADQDataAcquisitionParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.common = self.common._to_ct()
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataAcquisitionParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataAcquisitionParameters"
                )
            )

        return ADQDataAcquisitionParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataAcquisitionParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataTransferParametersCommon(_struct_base):
    _fields_ = [
        ("record_buffer_packed_size", ct.c_int64),
        ("metadata_buffer_packed_size", ct.c_int64),
        ("marker_mode", ct.c_int),
        ("write_lock_enabled", ct.c_int32),
        ("transfer_records_to_host_enabled", ct.c_int32),
        ("packed_buffers_enabled", ct.c_int32),
    ]

    def _to_native(self) -> "ADQDataTransferParametersCommon":
        ret = ADQDataTransferParametersCommon()
        ret.record_buffer_packed_size = self.record_buffer_packed_size
        ret.metadata_buffer_packed_size = self.metadata_buffer_packed_size
        ret.marker_mode = self.marker_mode
        ret.write_lock_enabled = self.write_lock_enabled
        ret.transfer_records_to_host_enabled = self.transfer_records_to_host_enabled
        ret.packed_buffers_enabled = self.packed_buffers_enabled
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataTransferParametersCommon(_native_base):
    def __init__(self):
        self.record_buffer_packed_size: int = 0
        self.metadata_buffer_packed_size: int = 0
        self.marker_mode: int = 0  # enum
        self.write_lock_enabled: int = 0
        self.transfer_records_to_host_enabled: int = 0
        self.packed_buffers_enabled: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "record_buffer_packed_size",
            "metadata_buffer_packed_size",
            "marker_mode",
            "write_lock_enabled",
            "transfer_records_to_host_enabled",
            "packed_buffers_enabled",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataTransferParametersCommon"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDataTransferParametersCommon):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.record_buffer_packed_size == other.record_buffer_packed_size)
            and (self.metadata_buffer_packed_size == other.metadata_buffer_packed_size)
            and (self.marker_mode == other.marker_mode)
            and (self.write_lock_enabled == other.write_lock_enabled)
            and (
                self.transfer_records_to_host_enabled
                == other.transfer_records_to_host_enabled
            )
            and (self.packed_buffers_enabled == other.packed_buffers_enabled)
        )

    def _to_ct(self) -> _ADQDataTransferParametersCommon:
        ret = _ADQDataTransferParametersCommon()
        ret.record_buffer_packed_size = self.record_buffer_packed_size
        ret.metadata_buffer_packed_size = self.metadata_buffer_packed_size
        ret.marker_mode = self.marker_mode
        ret.write_lock_enabled = self.write_lock_enabled
        ret.transfer_records_to_host_enabled = self.transfer_records_to_host_enabled
        ret.packed_buffers_enabled = self.packed_buffers_enabled
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataTransferParametersCommon" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataTransferParametersCommon"
                )
            )

        return ADQDataTransferParametersCommon._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataTransferParametersCommon()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataTransferParametersChannel(_struct_base):
    _fields_ = [
        ("record_buffer_bus_address", (ct.c_uint64 * 16)),
        ("metadata_buffer_bus_address", (ct.c_uint64 * 16)),
        ("marker_buffer_bus_address", (ct.c_uint64 * 16)),
        ("nof_buffers", ct.c_int64),
        ("record_size", ct.c_int64),
        ("record_buffer_size", ct.c_int64),
        ("metadata_buffer_size", ct.c_int64),
        ("record_buffer_packed_offset", ct.c_int64),
        ("metadata_buffer_packed_offset", ct.c_int64),
        ("record_buffer", (ct.c_void_p * 16)),
        ("metadata_buffer", (ct.c_void_p * 16)),
        ("marker_buffer", (ct.POINTER(ct.c_uint32) * 16)),
        ("record_length_infinite_enabled", ct.c_int32),
        ("metadata_enabled", ct.c_int32),
    ]

    def _to_native(self) -> "ADQDataTransferParametersChannel":
        ret = ADQDataTransferParametersChannel()
        ret.record_buffer_bus_address = [a for a in self.record_buffer_bus_address]
        ret.metadata_buffer_bus_address = [a for a in self.metadata_buffer_bus_address]
        ret.marker_buffer_bus_address = [a for a in self.marker_buffer_bus_address]
        ret.nof_buffers = self.nof_buffers
        ret.record_size = self.record_size
        ret.record_buffer_size = self.record_buffer_size
        ret.metadata_buffer_size = self.metadata_buffer_size
        ret.record_buffer_packed_offset = self.record_buffer_packed_offset
        ret.metadata_buffer_packed_offset = self.metadata_buffer_packed_offset
        ret.record_buffer = [a for a in self.record_buffer]
        ret.metadata_buffer = [a for a in self.metadata_buffer]
        ret.marker_buffer = [a for a in self.marker_buffer]
        ret.record_length_infinite_enabled = self.record_length_infinite_enabled
        ret.metadata_enabled = self.metadata_enabled
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataTransferParametersChannel(_native_base):
    def __init__(self):
        self.record_buffer_bus_address: List[int] = [0] * 16
        self.metadata_buffer_bus_address: List[int] = [0] * 16
        self.marker_buffer_bus_address: List[int] = [0] * 16
        self.nof_buffers: int = 0
        self.record_size: int = 0
        self.record_buffer_size: int = 0
        self.metadata_buffer_size: int = 0
        self.record_buffer_packed_offset: int = 0
        self.metadata_buffer_packed_offset: int = 0
        self.record_buffer: List[ct.c_void_p] = [ct.c_void_p()] * 16
        self.metadata_buffer: List[ct.c_void_p] = [ct.c_void_p()] * 16
        self.marker_buffer: List[ct.POINTER(ct.c_uint32)] = [
            ct.POINTER(ct.c_uint32)()
        ] * 16
        self.record_length_infinite_enabled: int = 0
        self.metadata_enabled: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "record_buffer_bus_address",
            "metadata_buffer_bus_address",
            "marker_buffer_bus_address",
            "nof_buffers",
            "record_size",
            "record_buffer_size",
            "metadata_buffer_size",
            "record_buffer_packed_offset",
            "metadata_buffer_packed_offset",
            "record_buffer",
            "metadata_buffer",
            "marker_buffer",
            "record_length_infinite_enabled",
            "metadata_enabled",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataTransferParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQDataTransferParametersChannel"
        )

    def _to_ct(self) -> _ADQDataTransferParametersChannel:
        ret = _ADQDataTransferParametersChannel()
        for a in range(len(self.record_buffer_bus_address)):
            ret.record_buffer_bus_address[a] = self.record_buffer_bus_address[a]
        for a in range(len(self.metadata_buffer_bus_address)):
            ret.metadata_buffer_bus_address[a] = self.metadata_buffer_bus_address[a]
        for a in range(len(self.marker_buffer_bus_address)):
            ret.marker_buffer_bus_address[a] = self.marker_buffer_bus_address[a]
        ret.nof_buffers = self.nof_buffers
        ret.record_size = self.record_size
        ret.record_buffer_size = self.record_buffer_size
        ret.metadata_buffer_size = self.metadata_buffer_size
        ret.record_buffer_packed_offset = self.record_buffer_packed_offset
        ret.metadata_buffer_packed_offset = self.metadata_buffer_packed_offset
        for a in range(len(self.record_buffer)):
            ret.record_buffer[a] = self.record_buffer[a]
        for a in range(len(self.metadata_buffer)):
            ret.metadata_buffer[a] = self.metadata_buffer[a]
        for a in range(len(self.marker_buffer)):
            ret.marker_buffer[a] = self.marker_buffer[a]
        ret.record_length_infinite_enabled = self.record_length_infinite_enabled
        ret.metadata_enabled = self.metadata_enabled
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataTransferParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataTransferParametersChannel"
                )
            )

        return ADQDataTransferParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataTransferParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataTransferParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("common", _ADQDataTransferParametersCommon),
        ("channel", (_ADQDataTransferParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQDataTransferParameters":
        ret = ADQDataTransferParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.common = self.common._to_native()
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataTransferParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.common: ADQDataTransferParametersCommon = ADQDataTransferParametersCommon()
        self.channel: List[ADQDataTransferParametersChannel] = [
            ADQDataTransferParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "common",
            "channel",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataTransferParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQDataTransferParameters")

    def _to_ct(self) -> _ADQDataTransferParameters:
        ret = _ADQDataTransferParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.common = self.common._to_ct()
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataTransferParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataTransferParameters"
                )
            )

        return ADQDataTransferParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataTransferParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataReadoutParametersCommon(_struct_base):
    _fields_ = [
        ("memory_owner", ct.c_int),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQDataReadoutParametersCommon":
        ret = ADQDataReadoutParametersCommon()
        ret.memory_owner = self.memory_owner
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataReadoutParametersCommon(_native_base):
    def __init__(self):
        self.memory_owner: int = 0  # enum
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "memory_owner",
            "reserved",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataReadoutParametersCommon"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDataReadoutParametersCommon):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (self.memory_owner == other.memory_owner) and (
            self.reserved == other.reserved
        )

    def _to_ct(self) -> _ADQDataReadoutParametersCommon:
        ret = _ADQDataReadoutParametersCommon()
        ret.memory_owner = self.memory_owner
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataReadoutParametersCommon" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataReadoutParametersCommon"
                )
            )

        return ADQDataReadoutParametersCommon._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataReadoutParametersCommon()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataReadoutParametersChannel(_struct_base):
    _fields_ = [
        ("nof_record_buffers_max", ct.c_int64),
        ("record_buffer_size_max", ct.c_int64),
        ("record_buffer_size_increment", ct.c_int64),
        ("incomplete_records_enabled", ct.c_int32),
        ("bytes_per_sample", ct.c_int32),
    ]

    def _to_native(self) -> "ADQDataReadoutParametersChannel":
        ret = ADQDataReadoutParametersChannel()
        ret.nof_record_buffers_max = self.nof_record_buffers_max
        ret.record_buffer_size_max = self.record_buffer_size_max
        ret.record_buffer_size_increment = self.record_buffer_size_increment
        ret.incomplete_records_enabled = self.incomplete_records_enabled
        ret.bytes_per_sample = self.bytes_per_sample
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataReadoutParametersChannel(_native_base):
    def __init__(self):
        self.nof_record_buffers_max: int = 0
        self.record_buffer_size_max: int = 0
        self.record_buffer_size_increment: int = 0
        self.incomplete_records_enabled: int = 0
        self.bytes_per_sample: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "nof_record_buffers_max",
            "record_buffer_size_max",
            "record_buffer_size_increment",
            "incomplete_records_enabled",
            "bytes_per_sample",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataReadoutParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDataReadoutParametersChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.nof_record_buffers_max == other.nof_record_buffers_max)
            and (self.record_buffer_size_max == other.record_buffer_size_max)
            and (
                self.record_buffer_size_increment == other.record_buffer_size_increment
            )
            and (self.incomplete_records_enabled == other.incomplete_records_enabled)
            and (self.bytes_per_sample == other.bytes_per_sample)
        )

    def _to_ct(self) -> _ADQDataReadoutParametersChannel:
        ret = _ADQDataReadoutParametersChannel()
        ret.nof_record_buffers_max = self.nof_record_buffers_max
        ret.record_buffer_size_max = self.record_buffer_size_max
        ret.record_buffer_size_increment = self.record_buffer_size_increment
        ret.incomplete_records_enabled = self.incomplete_records_enabled
        ret.bytes_per_sample = self.bytes_per_sample
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataReadoutParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataReadoutParametersChannel"
                )
            )

        return ADQDataReadoutParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataReadoutParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataReadoutParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("common", _ADQDataReadoutParametersCommon),
        ("channel", (_ADQDataReadoutParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQDataReadoutParameters":
        ret = ADQDataReadoutParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.common = self.common._to_native()
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataReadoutParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.common: ADQDataReadoutParametersCommon = ADQDataReadoutParametersCommon()
        self.channel: List[ADQDataReadoutParametersChannel] = [
            ADQDataReadoutParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "common",
            "channel",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDataReadoutParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQDataReadoutParameters")

    def _to_ct(self) -> _ADQDataReadoutParameters:
        ret = _ADQDataReadoutParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.common = self.common._to_ct()
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataReadoutParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataReadoutParameters"
                )
            )

        return ADQDataReadoutParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataReadoutParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDataReadoutStatus(_struct_base):
    _fields_ = [
        ("flags", ct.c_uint32),
    ]

    def _to_native(self) -> "ADQDataReadoutStatus":
        ret = ADQDataReadoutStatus()
        ret.flags = self.flags
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDataReadoutStatus(_native_base):
    def __init__(self):
        self.flags: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "flags",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQDataReadoutStatus")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDataReadoutStatus):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return self.flags == other.flags

    def _to_ct(self) -> _ADQDataReadoutStatus:
        ret = _ADQDataReadoutStatus()
        ret.flags = self.flags
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDataReadoutStatus" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDataReadoutStatus"
                )
            )

        return ADQDataReadoutStatus._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDataReadoutStatus()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQP2pStatusChannel(_struct_base):
    _fields_ = [
        ("flags", ct.c_uint32),
        ("nof_completed_buffers", ct.c_int32),
        ("completed_buffers", (ct.c_int16 * 16)),
    ]

    def _to_native(self) -> "ADQP2pStatusChannel":
        ret = ADQP2pStatusChannel()
        ret.flags = self.flags
        ret.nof_completed_buffers = self.nof_completed_buffers
        ret.completed_buffers = [a for a in self.completed_buffers]
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQP2pStatusChannel(_native_base):
    def __init__(self):
        self.flags: int = 0
        self.nof_completed_buffers: int = 0
        self.completed_buffers: List[int] = [0] * 16

    def __setattr__(self, name, value):
        if name not in [
            "flags",
            "nof_completed_buffers",
            "completed_buffers",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQP2pStatusChannel")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQP2pStatusChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.flags == other.flags)
            and (self.nof_completed_buffers == other.nof_completed_buffers)
            and (self.completed_buffers == other.completed_buffers)
        )

    def _to_ct(self) -> _ADQP2pStatusChannel:
        ret = _ADQP2pStatusChannel()
        ret.flags = self.flags
        ret.nof_completed_buffers = self.nof_completed_buffers
        for a in range(len(self.completed_buffers)):
            ret.completed_buffers[a] = self.completed_buffers[a]
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQP2pStatusChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQP2pStatusChannel"
                )
            )

        return ADQP2pStatusChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQP2pStatusChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQP2pStatus(_struct_base):
    _fields_ = [
        ("channel", (_ADQP2pStatusChannel * 8)),
        ("flags", ct.c_uint32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQP2pStatus":
        ret = ADQP2pStatus()
        ret.channel = [a._to_native() for a in self.channel]
        ret.flags = self.flags
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQP2pStatus(_native_base):
    def __init__(self):
        self.channel: List[ADQP2pStatusChannel] = [ADQP2pStatusChannel()] * 8
        self.flags: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "channel",
            "flags",
            "reserved",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQP2pStatus")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQP2pStatus")

    def _to_ct(self) -> _ADQP2pStatus:
        ret = _ADQP2pStatus()
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.flags = self.flags
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQP2pStatus" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(obj["name"], "ADQP2pStatus")
            )

        return ADQP2pStatus._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQP2pStatus()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQConstantParametersCommunicationInterface(_struct_base):
    _fields_ = [
        ("type", ct.c_int),
        ("link_width", ct.c_int32),
        ("link_generation", ct.c_int32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQConstantParametersCommunicationInterface":
        ret = ADQConstantParametersCommunicationInterface()
        ret.type = self.type
        ret.link_width = self.link_width
        ret.link_generation = self.link_generation
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQConstantParametersCommunicationInterface(_native_base):
    def __init__(self):
        self.type: int = 0  # enum
        self.link_width: int = 0
        self.link_generation: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "type",
            "link_width",
            "link_generation",
            "reserved",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQConstantParametersCommunicationInterface"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQConstantParametersCommunicationInterface):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.type == other.type)
            and (self.link_width == other.link_width)
            and (self.link_generation == other.link_generation)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQConstantParametersCommunicationInterface:
        ret = _ADQConstantParametersCommunicationInterface()
        ret.type = self.type
        ret.link_width = self.link_width
        ret.link_generation = self.link_generation
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQConstantParametersCommunicationInterface" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQConstantParametersCommunicationInterface"
                )
            )

        return ADQConstantParametersCommunicationInterface._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQConstantParametersCommunicationInterface()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQConstantParametersFirFilter(_struct_base):
    _fields_ = [
        ("is_present", ct.c_int32),
        ("order", ct.c_int32),
        ("nof_coefficients", ct.c_int32),
        ("coefficient_bits", ct.c_int32),
        ("coefficient_fractional_bits", ct.c_int32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQConstantParametersFirFilter":
        ret = ADQConstantParametersFirFilter()
        ret.is_present = self.is_present
        ret.order = self.order
        ret.nof_coefficients = self.nof_coefficients
        ret.coefficient_bits = self.coefficient_bits
        ret.coefficient_fractional_bits = self.coefficient_fractional_bits
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQConstantParametersFirFilter(_native_base):
    def __init__(self):
        self.is_present: int = 0
        self.order: int = 0
        self.nof_coefficients: int = 0
        self.coefficient_bits: int = 0
        self.coefficient_fractional_bits: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "is_present",
            "order",
            "nof_coefficients",
            "coefficient_bits",
            "coefficient_fractional_bits",
            "reserved",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQConstantParametersFirFilter"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQConstantParametersFirFilter):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.is_present == other.is_present)
            and (self.order == other.order)
            and (self.nof_coefficients == other.nof_coefficients)
            and (self.coefficient_bits == other.coefficient_bits)
            and (self.coefficient_fractional_bits == other.coefficient_fractional_bits)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQConstantParametersFirFilter:
        ret = _ADQConstantParametersFirFilter()
        ret.is_present = self.is_present
        ret.order = self.order
        ret.nof_coefficients = self.nof_coefficients
        ret.coefficient_bits = self.coefficient_bits
        ret.coefficient_fractional_bits = self.coefficient_fractional_bits
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQConstantParametersFirFilter" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQConstantParametersFirFilter"
                )
            )

        return ADQConstantParametersFirFilter._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQConstantParametersFirFilter()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQConstantParametersChannel(_struct_base):
    _fields_ = [
        ("base_sampling_rate", ct.c_double),
        ("input_range", (ct.c_double * 8)),
        ("label", (ct.c_char * 8)),
        ("nof_adc_cores", ct.c_int32),
        ("nof_input_ranges", ct.c_int32),
        ("has_variable_dc_offset", ct.c_int32),
        ("has_variable_input_range", ct.c_int32),
        ("fir_filter", _ADQConstantParametersFirFilter),
    ]

    def _to_native(self) -> "ADQConstantParametersChannel":
        ret = ADQConstantParametersChannel()
        ret.base_sampling_rate = self.base_sampling_rate
        ret.input_range = [a for a in self.input_range]
        ret.label = self.label.decode("ascii")
        ret.nof_adc_cores = self.nof_adc_cores
        ret.nof_input_ranges = self.nof_input_ranges
        ret.has_variable_dc_offset = self.has_variable_dc_offset
        ret.has_variable_input_range = self.has_variable_input_range
        ret.fir_filter = self.fir_filter._to_native()
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQConstantParametersChannel(_native_base):
    def __init__(self):
        self.base_sampling_rate: float = 0
        self.input_range: List[float] = [0] * 8
        self.label: str = ""
        self.nof_adc_cores: int = 0
        self.nof_input_ranges: int = 0
        self.has_variable_dc_offset: int = 0
        self.has_variable_input_range: int = 0
        self.fir_filter: ADQConstantParametersFirFilter = (
            ADQConstantParametersFirFilter()
        )

    def __setattr__(self, name, value):
        if name not in [
            "base_sampling_rate",
            "input_range",
            "label",
            "nof_adc_cores",
            "nof_input_ranges",
            "has_variable_dc_offset",
            "has_variable_input_range",
            "fir_filter",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQConstantParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQConstantParametersChannel"
        )

    def _to_ct(self) -> _ADQConstantParametersChannel:
        ret = _ADQConstantParametersChannel()
        ret.base_sampling_rate = self.base_sampling_rate
        for a in range(len(self.input_range)):
            ret.input_range[a] = self.input_range[a]
        ret.label = self.label.encode("ascii")
        ret.nof_adc_cores = self.nof_adc_cores
        ret.nof_input_ranges = self.nof_input_ranges
        ret.has_variable_dc_offset = self.has_variable_dc_offset
        ret.has_variable_input_range = self.has_variable_input_range
        ret.fir_filter = self.fir_filter._to_ct()
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQConstantParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQConstantParametersChannel"
                )
            )

        return ADQConstantParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQConstantParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQConstantParametersPin(_struct_base):
    _fields_ = [
        ("event_source", ct.c_int),
        ("direction", ct.c_int),
        ("has_configurable_threshold", ct.c_int32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQConstantParametersPin":
        ret = ADQConstantParametersPin()
        ret.event_source = self.event_source
        ret.direction = self.direction
        ret.has_configurable_threshold = self.has_configurable_threshold
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQConstantParametersPin(_native_base):
    def __init__(self):
        self.event_source: int = 0  # enum
        self.direction: int = 0  # enum
        self.has_configurable_threshold: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "event_source",
            "direction",
            "has_configurable_threshold",
            "reserved",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQConstantParametersPin"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQConstantParametersPin):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.event_source == other.event_source)
            and (self.direction == other.direction)
            and (self.has_configurable_threshold == other.has_configurable_threshold)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQConstantParametersPin:
        ret = _ADQConstantParametersPin()
        ret.event_source = self.event_source
        ret.direction = self.direction
        ret.has_configurable_threshold = self.has_configurable_threshold
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQConstantParametersPin" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQConstantParametersPin"
                )
            )

        return ADQConstantParametersPin._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQConstantParametersPin()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQConstantParametersPort(_struct_base):
    _fields_ = [
        ("nof_pins", ct.c_int32),
        ("is_present", ct.c_int32),
        ("label", (ct.c_char * 16)),
        ("pin", (_ADQConstantParametersPin * 16)),
    ]

    def _to_native(self) -> "ADQConstantParametersPort":
        ret = ADQConstantParametersPort()
        ret.nof_pins = self.nof_pins
        ret.is_present = self.is_present
        ret.label = self.label.decode("ascii")
        ret.pin = [a._to_native() for a in self.pin]
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQConstantParametersPort(_native_base):
    def __init__(self):
        self.nof_pins: int = 0
        self.is_present: int = 0
        self.label: str = ""
        self.pin: List[ADQConstantParametersPin] = [ADQConstantParametersPin()] * 16

    def __setattr__(self, name, value):
        if name not in [
            "nof_pins",
            "is_present",
            "label",
            "pin",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQConstantParametersPort"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQConstantParametersPort")

    def _to_ct(self) -> _ADQConstantParametersPort:
        ret = _ADQConstantParametersPort()
        ret.nof_pins = self.nof_pins
        ret.is_present = self.is_present
        ret.label = self.label.encode("ascii")
        for a in range(len(self.pin)):
            ret.pin[a] = self.pin[a]._to_ct()
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQConstantParametersPort" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQConstantParametersPort"
                )
            )

        return ADQConstantParametersPort._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQConstantParametersPort()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQConstantParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("clock_system", _ADQClockSystemParameters),
        ("nof_channels", ct.c_int32),
        ("nof_pattern_generators", ct.c_int32),
        ("max_nof_pattern_generator_instructions", ct.c_int32),
        ("nof_pulse_generators", ct.c_int32),
        ("dna", (ct.c_char * 40)),
        ("serial_number", (ct.c_char * 16)),
        ("product_name", (ct.c_char * 32)),
        ("product_options", (ct.c_char * 32)),
        ("firmware_name", (ct.c_char * 32)),
        ("firmware_revision", (ct.c_char * 16)),
        ("firmware_type", (ct.c_char * 16)),
        ("channel", (_ADQConstantParametersChannel * 8)),
        ("port", (_ADQConstantParametersPort * 8)),
        ("communication_interface", _ADQConstantParametersCommunicationInterface),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQConstantParameters":
        ret = ADQConstantParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.clock_system = self.clock_system._to_native()
        ret.nof_channels = self.nof_channels
        ret.nof_pattern_generators = self.nof_pattern_generators
        ret.max_nof_pattern_generator_instructions = (
            self.max_nof_pattern_generator_instructions
        )
        ret.nof_pulse_generators = self.nof_pulse_generators
        ret.dna = self.dna.decode("ascii")
        ret.serial_number = self.serial_number.decode("ascii")
        ret.product_name = self.product_name.decode("ascii")
        ret.product_options = self.product_options.decode("ascii")
        ret.firmware_name = self.firmware_name.decode("ascii")
        ret.firmware_revision = self.firmware_revision.decode("ascii")
        ret.firmware_type = self.firmware_type.decode("ascii")
        ret.channel = [a._to_native() for a in self.channel]
        ret.port = [a._to_native() for a in self.port]
        ret.communication_interface = self.communication_interface._to_native()
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQConstantParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.clock_system: ADQClockSystemParameters = ADQClockSystemParameters()
        self.nof_channels: int = 0
        self.nof_pattern_generators: int = 0
        self.max_nof_pattern_generator_instructions: int = 0
        self.nof_pulse_generators: int = 0
        self.dna: str = ""
        self.serial_number: str = ""
        self.product_name: str = ""
        self.product_options: str = ""
        self.firmware_name: str = ""
        self.firmware_revision: str = ""
        self.firmware_type: str = ""
        self.channel: List[ADQConstantParametersChannel] = [
            ADQConstantParametersChannel()
        ] * 8
        self.port: List[ADQConstantParametersPort] = [ADQConstantParametersPort()] * 8
        self.communication_interface: ADQConstantParametersCommunicationInterface = (
            ADQConstantParametersCommunicationInterface()
        )
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "clock_system",
            "nof_channels",
            "nof_pattern_generators",
            "max_nof_pattern_generator_instructions",
            "nof_pulse_generators",
            "dna",
            "serial_number",
            "product_name",
            "product_options",
            "firmware_name",
            "firmware_revision",
            "firmware_type",
            "channel",
            "port",
            "communication_interface",
            "magic",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQConstantParameters")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQConstantParameters")

    def _to_ct(self) -> _ADQConstantParameters:
        ret = _ADQConstantParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.clock_system = self.clock_system._to_ct()
        ret.nof_channels = self.nof_channels
        ret.nof_pattern_generators = self.nof_pattern_generators
        ret.max_nof_pattern_generator_instructions = (
            self.max_nof_pattern_generator_instructions
        )
        ret.nof_pulse_generators = self.nof_pulse_generators
        ret.dna = self.dna.encode("ascii")
        ret.serial_number = self.serial_number.encode("ascii")
        ret.product_name = self.product_name.encode("ascii")
        ret.product_options = self.product_options.encode("ascii")
        ret.firmware_name = self.firmware_name.encode("ascii")
        ret.firmware_revision = self.firmware_revision.encode("ascii")
        ret.firmware_type = self.firmware_type.encode("ascii")
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        for a in range(len(self.port)):
            ret.port[a] = self.port[a]._to_ct()
        ret.communication_interface = self.communication_interface._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQConstantParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQConstantParameters"
                )
            )

        return ADQConstantParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQConstantParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDigitalGainAndOffsetParametersChannel(_struct_base):
    _fields_ = [
        ("gain", ct.c_int64),
        ("offset", ct.c_int64),
    ]

    def _to_native(self) -> "ADQDigitalGainAndOffsetParametersChannel":
        ret = ADQDigitalGainAndOffsetParametersChannel()
        ret.gain = self.gain
        ret.offset = self.offset
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDigitalGainAndOffsetParametersChannel(_native_base):
    def __init__(self):
        self.gain: int = 0
        self.offset: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "gain",
            "offset",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDigitalGainAndOffsetParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDigitalGainAndOffsetParametersChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (self.gain == other.gain) and (self.offset == other.offset)

    def _to_ct(self) -> _ADQDigitalGainAndOffsetParametersChannel:
        ret = _ADQDigitalGainAndOffsetParametersChannel()
        ret.gain = self.gain
        ret.offset = self.offset
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDigitalGainAndOffsetParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDigitalGainAndOffsetParametersChannel"
                )
            )

        return ADQDigitalGainAndOffsetParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDigitalGainAndOffsetParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDigitalGainAndOffsetParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("channel", (_ADQDigitalGainAndOffsetParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQDigitalGainAndOffsetParameters":
        ret = ADQDigitalGainAndOffsetParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDigitalGainAndOffsetParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.channel: List[ADQDigitalGainAndOffsetParametersChannel] = [
            ADQDigitalGainAndOffsetParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "channel",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDigitalGainAndOffsetParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQDigitalGainAndOffsetParameters"
        )

    def _to_ct(self) -> _ADQDigitalGainAndOffsetParameters:
        ret = _ADQDigitalGainAndOffsetParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDigitalGainAndOffsetParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDigitalGainAndOffsetParameters"
                )
            )

        return ADQDigitalGainAndOffsetParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDigitalGainAndOffsetParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQEventSourceLevelParametersChannel(_struct_base):
    _fields_ = [
        ("level", ct.c_int64),
        ("arm_hysteresis", ct.c_int64),
    ]

    def _to_native(self) -> "ADQEventSourceLevelParametersChannel":
        ret = ADQEventSourceLevelParametersChannel()
        ret.level = self.level
        ret.arm_hysteresis = self.arm_hysteresis
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQEventSourceLevelParametersChannel(_native_base):
    def __init__(self):
        self.level: int = 0
        self.arm_hysteresis: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "level",
            "arm_hysteresis",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQEventSourceLevelParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQEventSourceLevelParametersChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (self.level == other.level) and (
            self.arm_hysteresis == other.arm_hysteresis
        )

    def _to_ct(self) -> _ADQEventSourceLevelParametersChannel:
        ret = _ADQEventSourceLevelParametersChannel()
        ret.level = self.level
        ret.arm_hysteresis = self.arm_hysteresis
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQEventSourceLevelParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQEventSourceLevelParametersChannel"
                )
            )

        return ADQEventSourceLevelParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQEventSourceLevelParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQEventSourceLevelParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("channel", (_ADQEventSourceLevelParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQEventSourceLevelParameters":
        ret = ADQEventSourceLevelParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQEventSourceLevelParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.channel: List[ADQEventSourceLevelParametersChannel] = [
            ADQEventSourceLevelParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "channel",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQEventSourceLevelParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQEventSourceLevelParameters"
        )

    def _to_ct(self) -> _ADQEventSourceLevelParameters:
        ret = _ADQEventSourceLevelParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQEventSourceLevelParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQEventSourceLevelParameters"
                )
            )

        return ADQEventSourceLevelParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQEventSourceLevelParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDbsParametersChannel(_struct_base):
    _fields_ = [
        ("level", ct.c_int64),
        ("lower_saturation_level", ct.c_int64),
        ("upper_saturation_level", ct.c_int64),
        ("bypass", ct.c_int32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQDbsParametersChannel":
        ret = ADQDbsParametersChannel()
        ret.level = self.level
        ret.lower_saturation_level = self.lower_saturation_level
        ret.upper_saturation_level = self.upper_saturation_level
        ret.bypass = self.bypass
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDbsParametersChannel(_native_base):
    def __init__(self):
        self.level: int = 0
        self.lower_saturation_level: int = 0
        self.upper_saturation_level: int = 0
        self.bypass: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "level",
            "lower_saturation_level",
            "upper_saturation_level",
            "bypass",
            "reserved",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQDbsParametersChannel")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDbsParametersChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.level == other.level)
            and (self.lower_saturation_level == other.lower_saturation_level)
            and (self.upper_saturation_level == other.upper_saturation_level)
            and (self.bypass == other.bypass)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQDbsParametersChannel:
        ret = _ADQDbsParametersChannel()
        ret.level = self.level
        ret.lower_saturation_level = self.lower_saturation_level
        ret.upper_saturation_level = self.upper_saturation_level
        ret.bypass = self.bypass
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDbsParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDbsParametersChannel"
                )
            )

        return ADQDbsParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDbsParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDbsParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("channel", (_ADQDbsParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQDbsParameters":
        ret = ADQDbsParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDbsParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.channel: List[ADQDbsParametersChannel] = [ADQDbsParametersChannel()] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "channel",
            "magic",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQDbsParameters")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQDbsParameters")

    def _to_ct(self) -> _ADQDbsParameters:
        ret = _ADQDbsParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDbsParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDbsParameters"
                )
            )

        return ADQDbsParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDbsParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQSampleSkipParametersChannel(_struct_base):
    _fields_ = [
        ("skip_factor", ct.c_int64),
    ]

    def _to_native(self) -> "ADQSampleSkipParametersChannel":
        ret = ADQSampleSkipParametersChannel()
        ret.skip_factor = self.skip_factor
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQSampleSkipParametersChannel(_native_base):
    def __init__(self):
        self.skip_factor: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "skip_factor",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQSampleSkipParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQSampleSkipParametersChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return self.skip_factor == other.skip_factor

    def _to_ct(self) -> _ADQSampleSkipParametersChannel:
        ret = _ADQSampleSkipParametersChannel()
        ret.skip_factor = self.skip_factor
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQSampleSkipParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQSampleSkipParametersChannel"
                )
            )

        return ADQSampleSkipParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQSampleSkipParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQSampleSkipParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("channel", (_ADQSampleSkipParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQSampleSkipParameters":
        ret = ADQSampleSkipParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQSampleSkipParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.channel: List[ADQSampleSkipParametersChannel] = [
            ADQSampleSkipParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "channel",
            "magic",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQSampleSkipParameters")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQSampleSkipParameters")

    def _to_ct(self) -> _ADQSampleSkipParameters:
        ret = _ADQSampleSkipParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQSampleSkipParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQSampleSkipParameters"
                )
            )

        return ADQSampleSkipParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQSampleSkipParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQFirFilterParametersChannel(_struct_base):
    _fields_ = [
        ("rounding_method", ct.c_int),
        ("format", ct.c_int),
        ("coefficient", (ct.c_double * 10)),
        ("coefficient_fixed_point", (ct.c_int32 * 10)),
    ]

    def _to_native(self) -> "ADQFirFilterParametersChannel":
        ret = ADQFirFilterParametersChannel()
        ret.rounding_method = self.rounding_method
        ret.format = self.format
        ret.coefficient = [a for a in self.coefficient]
        ret.coefficient_fixed_point = [a for a in self.coefficient_fixed_point]
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQFirFilterParametersChannel(_native_base):
    def __init__(self):
        self.rounding_method: int = 0  # enum
        self.format: int = 0  # enum
        self.coefficient: List[float] = [0] * 10
        self.coefficient_fixed_point: List[int] = [0] * 10

    def __setattr__(self, name, value):
        if name not in [
            "rounding_method",
            "format",
            "coefficient",
            "coefficient_fixed_point",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQFirFilterParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQFirFilterParametersChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.rounding_method == other.rounding_method)
            and (self.format == other.format)
            and (self.coefficient == other.coefficient)
            and (self.coefficient_fixed_point == other.coefficient_fixed_point)
        )

    def _to_ct(self) -> _ADQFirFilterParametersChannel:
        ret = _ADQFirFilterParametersChannel()
        ret.rounding_method = self.rounding_method
        ret.format = self.format
        for a in range(len(self.coefficient)):
            ret.coefficient[a] = self.coefficient[a]
        for a in range(len(self.coefficient_fixed_point)):
            ret.coefficient_fixed_point[a] = self.coefficient_fixed_point[a]
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQFirFilterParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQFirFilterParametersChannel"
                )
            )

        return ADQFirFilterParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQFirFilterParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQFirFilterParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("channel", (_ADQFirFilterParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQFirFilterParameters":
        ret = ADQFirFilterParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQFirFilterParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.channel: List[ADQFirFilterParametersChannel] = [
            ADQFirFilterParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "channel",
            "magic",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQFirFilterParameters")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQFirFilterParameters")

    def _to_ct(self) -> _ADQFirFilterParameters:
        ret = _ADQFirFilterParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQFirFilterParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQFirFilterParameters"
                )
            )

        return ADQFirFilterParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQFirFilterParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQTestPatternParametersPulse(_struct_base):
    _fields_ = [
        ("baseline", ct.c_int64),
        ("amplitude", ct.c_int64),
        ("period", ct.c_int64),
        ("width", ct.c_int64),
        ("nof_pulses_in_burst", ct.c_int64),
        ("nof_bursts", ct.c_int64),
        ("burst_period", ct.c_int64),
        ("prbs_amplitude_seed", ct.c_int64),
        ("prbs_amplitude_scale", ct.c_int64),
        ("prbs_width_seed", ct.c_int64),
        ("prbs_width_scale", ct.c_int64),
        ("prbs_noise_seed", ct.c_int64),
        ("prbs_noise_scale", ct.c_int64),
        ("trigger_mode_enabled", ct.c_int32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQTestPatternParametersPulse":
        ret = ADQTestPatternParametersPulse()
        ret.baseline = self.baseline
        ret.amplitude = self.amplitude
        ret.period = self.period
        ret.width = self.width
        ret.nof_pulses_in_burst = self.nof_pulses_in_burst
        ret.nof_bursts = self.nof_bursts
        ret.burst_period = self.burst_period
        ret.prbs_amplitude_seed = self.prbs_amplitude_seed
        ret.prbs_amplitude_scale = self.prbs_amplitude_scale
        ret.prbs_width_seed = self.prbs_width_seed
        ret.prbs_width_scale = self.prbs_width_scale
        ret.prbs_noise_seed = self.prbs_noise_seed
        ret.prbs_noise_scale = self.prbs_noise_scale
        ret.trigger_mode_enabled = self.trigger_mode_enabled
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQTestPatternParametersPulse(_native_base):
    def __init__(self):
        self.baseline: int = 0
        self.amplitude: int = 0
        self.period: int = 0
        self.width: int = 0
        self.nof_pulses_in_burst: int = 0
        self.nof_bursts: int = 0
        self.burst_period: int = 0
        self.prbs_amplitude_seed: int = 0
        self.prbs_amplitude_scale: int = 0
        self.prbs_width_seed: int = 0
        self.prbs_width_scale: int = 0
        self.prbs_noise_seed: int = 0
        self.prbs_noise_scale: int = 0
        self.trigger_mode_enabled: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "baseline",
            "amplitude",
            "period",
            "width",
            "nof_pulses_in_burst",
            "nof_bursts",
            "burst_period",
            "prbs_amplitude_seed",
            "prbs_amplitude_scale",
            "prbs_width_seed",
            "prbs_width_scale",
            "prbs_noise_seed",
            "prbs_noise_scale",
            "trigger_mode_enabled",
            "reserved",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQTestPatternParametersPulse"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQTestPatternParametersPulse):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.baseline == other.baseline)
            and (self.amplitude == other.amplitude)
            and (self.period == other.period)
            and (self.width == other.width)
            and (self.nof_pulses_in_burst == other.nof_pulses_in_burst)
            and (self.nof_bursts == other.nof_bursts)
            and (self.burst_period == other.burst_period)
            and (self.prbs_amplitude_seed == other.prbs_amplitude_seed)
            and (self.prbs_amplitude_scale == other.prbs_amplitude_scale)
            and (self.prbs_width_seed == other.prbs_width_seed)
            and (self.prbs_width_scale == other.prbs_width_scale)
            and (self.prbs_noise_seed == other.prbs_noise_seed)
            and (self.prbs_noise_scale == other.prbs_noise_scale)
            and (self.trigger_mode_enabled == other.trigger_mode_enabled)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQTestPatternParametersPulse:
        ret = _ADQTestPatternParametersPulse()
        ret.baseline = self.baseline
        ret.amplitude = self.amplitude
        ret.period = self.period
        ret.width = self.width
        ret.nof_pulses_in_burst = self.nof_pulses_in_burst
        ret.nof_bursts = self.nof_bursts
        ret.burst_period = self.burst_period
        ret.prbs_amplitude_seed = self.prbs_amplitude_seed
        ret.prbs_amplitude_scale = self.prbs_amplitude_scale
        ret.prbs_width_seed = self.prbs_width_seed
        ret.prbs_width_scale = self.prbs_width_scale
        ret.prbs_noise_seed = self.prbs_noise_seed
        ret.prbs_noise_scale = self.prbs_noise_scale
        ret.trigger_mode_enabled = self.trigger_mode_enabled
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQTestPatternParametersPulse" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQTestPatternParametersPulse"
                )
            )

        return ADQTestPatternParametersPulse._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQTestPatternParametersPulse()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQTestPatternParametersChannel(_struct_base):
    _fields_ = [
        ("source", ct.c_int),
        ("reserved", ct.c_int32),
        ("pulse", _ADQTestPatternParametersPulse),
    ]

    def _to_native(self) -> "ADQTestPatternParametersChannel":
        ret = ADQTestPatternParametersChannel()
        ret.source = self.source
        ret.reserved = self.reserved
        ret.pulse = self.pulse._to_native()
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQTestPatternParametersChannel(_native_base):
    def __init__(self):
        self.source: int = 0  # enum
        self.reserved: int = 0
        self.pulse: ADQTestPatternParametersPulse = ADQTestPatternParametersPulse()

    def __setattr__(self, name, value):
        if name not in [
            "source",
            "reserved",
            "pulse",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQTestPatternParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQTestPatternParametersChannel"
        )

    def _to_ct(self) -> _ADQTestPatternParametersChannel:
        ret = _ADQTestPatternParametersChannel()
        ret.source = self.source
        ret.reserved = self.reserved
        ret.pulse = self.pulse._to_ct()
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQTestPatternParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQTestPatternParametersChannel"
                )
            )

        return ADQTestPatternParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQTestPatternParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQTestPatternParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("channel", (_ADQTestPatternParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQTestPatternParameters":
        ret = ADQTestPatternParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQTestPatternParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.channel: List[ADQTestPatternParametersChannel] = [
            ADQTestPatternParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "channel",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQTestPatternParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQTestPatternParameters")

    def _to_ct(self) -> _ADQTestPatternParameters:
        ret = _ADQTestPatternParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQTestPatternParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQTestPatternParameters"
                )
            )

        return ADQTestPatternParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQTestPatternParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQEventSourcePortParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("threshold", ct.c_double),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQEventSourcePortParameters":
        ret = ADQEventSourcePortParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.threshold = self.threshold
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQEventSourcePortParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.threshold: float = 0
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "threshold",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQEventSourcePortParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQEventSourcePortParameters):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.id == other.id)
            and (self.reserved == other.reserved)
            and (self.threshold == other.threshold)
            and (self.magic == other.magic)
        )

    def _to_ct(self) -> _ADQEventSourcePortParameters:
        ret = _ADQEventSourcePortParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.threshold = self.threshold
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQEventSourcePortParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQEventSourcePortParameters"
                )
            )

        return ADQEventSourcePortParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQEventSourcePortParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQEventSourcePeriodicParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("synchronization_source", ct.c_int),
        ("period", ct.c_int64),
        ("high", ct.c_int64),
        ("low", ct.c_int64),
        ("frequency", ct.c_double),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQEventSourcePeriodicParameters":
        ret = ADQEventSourcePeriodicParameters()
        ret.id = self.id
        ret.synchronization_source = self.synchronization_source
        ret.period = self.period
        ret.high = self.high
        ret.low = self.low
        ret.frequency = self.frequency
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQEventSourcePeriodicParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.synchronization_source: int = 0  # enum
        self.period: int = 0
        self.high: int = 0
        self.low: int = 0
        self.frequency: float = 0
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "synchronization_source",
            "period",
            "high",
            "low",
            "frequency",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQEventSourcePeriodicParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQEventSourcePeriodicParameters):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.id == other.id)
            and (self.synchronization_source == other.synchronization_source)
            and (self.period == other.period)
            and (self.high == other.high)
            and (self.low == other.low)
            and (self.frequency == other.frequency)
            and (self.magic == other.magic)
        )

    def _to_ct(self) -> _ADQEventSourcePeriodicParameters:
        ret = _ADQEventSourcePeriodicParameters()
        ret.id = self.id
        ret.synchronization_source = self.synchronization_source
        ret.period = self.period
        ret.high = self.high
        ret.low = self.low
        ret.frequency = self.frequency
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQEventSourcePeriodicParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQEventSourcePeriodicParameters"
                )
            )

        return ADQEventSourcePeriodicParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQEventSourcePeriodicParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQPortParametersPin(_struct_base):
    _fields_ = [
        ("input_impedance", ct.c_int),
        ("direction", ct.c_int),
        ("function", ct.c_int),
        ("value", ct.c_int32),
        ("invert_output", ct.c_int32),
        ("reserved", ct.c_int32),
    ]

    def _to_native(self) -> "ADQPortParametersPin":
        ret = ADQPortParametersPin()
        ret.input_impedance = self.input_impedance
        ret.direction = self.direction
        ret.function = self.function
        ret.value = self.value
        ret.invert_output = self.invert_output
        ret.reserved = self.reserved
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQPortParametersPin(_native_base):
    def __init__(self):
        self.input_impedance: int = 0  # enum
        self.direction: int = 0  # enum
        self.function: int = 0  # enum
        self.value: int = 0
        self.invert_output: int = 0
        self.reserved: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "input_impedance",
            "direction",
            "function",
            "value",
            "invert_output",
            "reserved",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQPortParametersPin")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQPortParametersPin):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.input_impedance == other.input_impedance)
            and (self.direction == other.direction)
            and (self.function == other.function)
            and (self.value == other.value)
            and (self.invert_output == other.invert_output)
            and (self.reserved == other.reserved)
        )

    def _to_ct(self) -> _ADQPortParametersPin:
        ret = _ADQPortParametersPin()
        ret.input_impedance = self.input_impedance
        ret.direction = self.direction
        ret.function = self.function
        ret.value = self.value
        ret.invert_output = self.invert_output
        ret.reserved = self.reserved
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQPortParametersPin" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQPortParametersPin"
                )
            )

        return ADQPortParametersPin._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQPortParametersPin()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQPortParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("pin", (_ADQPortParametersPin * 16)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQPortParameters":
        ret = ADQPortParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.pin = [a._to_native() for a in self.pin]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQPortParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.pin: List[ADQPortParametersPin] = [ADQPortParametersPin()] * 16
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "pin",
            "magic",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQPortParameters")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQPortParameters")

    def _to_ct(self) -> _ADQPortParameters:
        ret = _ADQPortParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.pin)):
            ret.pin[a] = self.pin[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQPortParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQPortParameters"
                )
            )

        return ADQPortParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQPortParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQAnalogFrontendParametersChannel(_struct_base):
    _fields_ = [
        ("input_range", ct.c_double),
        ("dc_offset", ct.c_double),
    ]

    def _to_native(self) -> "ADQAnalogFrontendParametersChannel":
        ret = ADQAnalogFrontendParametersChannel()
        ret.input_range = self.input_range
        ret.dc_offset = self.dc_offset
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQAnalogFrontendParametersChannel(_native_base):
    def __init__(self):
        self.input_range: float = 0
        self.dc_offset: float = 0

    def __setattr__(self, name, value):
        if name not in [
            "input_range",
            "dc_offset",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQAnalogFrontendParametersChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQAnalogFrontendParametersChannel):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (self.input_range == other.input_range) and (
            self.dc_offset == other.dc_offset
        )

    def _to_ct(self) -> _ADQAnalogFrontendParametersChannel:
        ret = _ADQAnalogFrontendParametersChannel()
        ret.input_range = self.input_range
        ret.dc_offset = self.dc_offset
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQAnalogFrontendParametersChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQAnalogFrontendParametersChannel"
                )
            )

        return ADQAnalogFrontendParametersChannel._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQAnalogFrontendParametersChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQAnalogFrontendParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("channel", (_ADQAnalogFrontendParametersChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQAnalogFrontendParameters":
        ret = ADQAnalogFrontendParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQAnalogFrontendParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.channel: List[ADQAnalogFrontendParametersChannel] = [
            ADQAnalogFrontendParametersChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "channel",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQAnalogFrontendParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQAnalogFrontendParameters"
        )

    def _to_ct(self) -> _ADQAnalogFrontendParameters:
        ret = _ADQAnalogFrontendParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQAnalogFrontendParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQAnalogFrontendParameters"
                )
            )

        return ADQAnalogFrontendParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQAnalogFrontendParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQTimestampSynchronizationParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("source", ct.c_int),
        ("edge", ct.c_int),
        ("mode", ct.c_int),
        ("arm", ct.c_int),
        ("reserved", ct.c_int32),
        ("seed", ct.c_uint64),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQTimestampSynchronizationParameters":
        ret = ADQTimestampSynchronizationParameters()
        ret.id = self.id
        ret.source = self.source
        ret.edge = self.edge
        ret.mode = self.mode
        ret.arm = self.arm
        ret.reserved = self.reserved
        ret.seed = self.seed
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQTimestampSynchronizationParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.source: int = 0  # enum
        self.edge: int = 0  # enum
        self.mode: int = 0  # enum
        self.arm: int = 0  # enum
        self.reserved: int = 0
        self.seed: int = 0
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "source",
            "edge",
            "mode",
            "arm",
            "reserved",
            "seed",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQTimestampSynchronizationParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQTimestampSynchronizationParameters):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.id == other.id)
            and (self.source == other.source)
            and (self.edge == other.edge)
            and (self.mode == other.mode)
            and (self.arm == other.arm)
            and (self.reserved == other.reserved)
            and (self.seed == other.seed)
            and (self.magic == other.magic)
        )

    def _to_ct(self) -> _ADQTimestampSynchronizationParameters:
        ret = _ADQTimestampSynchronizationParameters()
        ret.id = self.id
        ret.source = self.source
        ret.edge = self.edge
        ret.mode = self.mode
        ret.arm = self.arm
        ret.reserved = self.reserved
        ret.seed = self.seed
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQTimestampSynchronizationParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQTimestampSynchronizationParameters"
                )
            )

        return ADQTimestampSynchronizationParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQTimestampSynchronizationParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQEventSourceParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("periodic", _ADQEventSourcePeriodicParameters),
        ("level", _ADQEventSourceLevelParameters),
        ("port", (_ADQEventSourcePortParameters * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQEventSourceParameters":
        ret = ADQEventSourceParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.periodic = self.periodic._to_native()
        ret.level = self.level._to_native()
        ret.port = [a._to_native() for a in self.port]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQEventSourceParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.periodic: ADQEventSourcePeriodicParameters = (
            ADQEventSourcePeriodicParameters()
        )
        self.level: ADQEventSourceLevelParameters = ADQEventSourceLevelParameters()
        self.port: List[ADQEventSourcePortParameters] = [
            ADQEventSourcePortParameters()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "periodic",
            "level",
            "port",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQEventSourceParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQEventSourceParameters")

    def _to_ct(self) -> _ADQEventSourceParameters:
        ret = _ADQEventSourceParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.periodic = self.periodic._to_ct()
        ret.level = self.level._to_ct()
        for a in range(len(self.port)):
            ret.port[a] = self.port[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQEventSourceParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQEventSourceParameters"
                )
            )

        return ADQEventSourceParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQEventSourceParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQSignalProcessingParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("gain_offset", _ADQDigitalGainAndOffsetParameters),
        ("sample_skip", _ADQSampleSkipParameters),
        ("dbs", _ADQDbsParameters),
        ("fir_filter", _ADQFirFilterParameters),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQSignalProcessingParameters":
        ret = ADQSignalProcessingParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.gain_offset = self.gain_offset._to_native()
        ret.sample_skip = self.sample_skip._to_native()
        ret.dbs = self.dbs._to_native()
        ret.fir_filter = self.fir_filter._to_native()
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQSignalProcessingParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.gain_offset: ADQDigitalGainAndOffsetParameters = (
            ADQDigitalGainAndOffsetParameters()
        )
        self.sample_skip: ADQSampleSkipParameters = ADQSampleSkipParameters()
        self.dbs: ADQDbsParameters = ADQDbsParameters()
        self.fir_filter: ADQFirFilterParameters = ADQFirFilterParameters()
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "gain_offset",
            "sample_skip",
            "dbs",
            "fir_filter",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQSignalProcessingParameters"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQSignalProcessingParameters"
        )

    def _to_ct(self) -> _ADQSignalProcessingParameters:
        ret = _ADQSignalProcessingParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.gain_offset = self.gain_offset._to_ct()
        ret.sample_skip = self.sample_skip._to_ct()
        ret.dbs = self.dbs._to_ct()
        ret.fir_filter = self.fir_filter._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQSignalProcessingParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQSignalProcessingParameters"
                )
            )

        return ADQSignalProcessingParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQSignalProcessingParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQFunctionParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("pattern_generator", (_ADQPatternGeneratorParameters * 2)),
        ("pulse_generator", (_ADQPulseGeneratorParameters * 4)),
        ("timestamp_synchronization", _ADQTimestampSynchronizationParameters),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQFunctionParameters":
        ret = ADQFunctionParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.pattern_generator = [a._to_native() for a in self.pattern_generator]
        ret.pulse_generator = [a._to_native() for a in self.pulse_generator]
        ret.timestamp_synchronization = self.timestamp_synchronization._to_native()
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQFunctionParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.pattern_generator: List[ADQPatternGeneratorParameters] = [
            ADQPatternGeneratorParameters()
        ] * 2
        self.pulse_generator: List[ADQPulseGeneratorParameters] = [
            ADQPulseGeneratorParameters()
        ] * 4
        self.timestamp_synchronization: ADQTimestampSynchronizationParameters = (
            ADQTimestampSynchronizationParameters()
        )
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "pattern_generator",
            "pulse_generator",
            "timestamp_synchronization",
            "magic",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQFunctionParameters")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQFunctionParameters")

    def _to_ct(self) -> _ADQFunctionParameters:
        ret = _ADQFunctionParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.pattern_generator)):
            ret.pattern_generator[a] = self.pattern_generator[a]._to_ct()
        for a in range(len(self.pulse_generator)):
            ret.pulse_generator[a] = self.pulse_generator[a]._to_ct()
        ret.timestamp_synchronization = self.timestamp_synchronization._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQFunctionParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQFunctionParameters"
                )
            )

        return ADQFunctionParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQFunctionParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQParameters(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("constant", _ADQConstantParameters),
        ("afe", _ADQAnalogFrontendParameters),
        ("port", (_ADQPortParameters * 8)),
        ("event_source", _ADQEventSourceParameters),
        ("function", _ADQFunctionParameters),
        ("test_pattern", _ADQTestPatternParameters),
        ("signal_processing", _ADQSignalProcessingParameters),
        ("acquisition", _ADQDataAcquisitionParameters),
        ("transfer", _ADQDataTransferParameters),
        ("readout", _ADQDataReadoutParameters),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQParameters":
        ret = ADQParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.constant = self.constant._to_native()
        ret.afe = self.afe._to_native()
        ret.port = [a._to_native() for a in self.port]
        ret.event_source = self.event_source._to_native()
        ret.function = self.function._to_native()
        ret.test_pattern = self.test_pattern._to_native()
        ret.signal_processing = self.signal_processing._to_native()
        ret.acquisition = self.acquisition._to_native()
        ret.transfer = self.transfer._to_native()
        ret.readout = self.readout._to_native()
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQParameters(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.constant: ADQConstantParameters = ADQConstantParameters()
        self.afe: ADQAnalogFrontendParameters = ADQAnalogFrontendParameters()
        self.port: List[ADQPortParameters] = [ADQPortParameters()] * 8
        self.event_source: ADQEventSourceParameters = ADQEventSourceParameters()
        self.function: ADQFunctionParameters = ADQFunctionParameters()
        self.test_pattern: ADQTestPatternParameters = ADQTestPatternParameters()
        self.signal_processing: ADQSignalProcessingParameters = (
            ADQSignalProcessingParameters()
        )
        self.acquisition: ADQDataAcquisitionParameters = ADQDataAcquisitionParameters()
        self.transfer: ADQDataTransferParameters = ADQDataTransferParameters()
        self.readout: ADQDataReadoutParameters = ADQDataReadoutParameters()
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "constant",
            "afe",
            "port",
            "event_source",
            "function",
            "test_pattern",
            "signal_processing",
            "acquisition",
            "transfer",
            "readout",
            "magic",
        ]:
            raise AttributeError(f"No field named '{name}' for ADQParameters")
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError("Comparison not supported for type: ADQParameters")

    def _to_ct(self) -> _ADQParameters:
        ret = _ADQParameters()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.constant = self.constant._to_ct()
        ret.afe = self.afe._to_ct()
        for a in range(len(self.port)):
            ret.port[a] = self.port[a]._to_ct()
        ret.event_source = self.event_source._to_ct()
        ret.function = self.function._to_ct()
        ret.test_pattern = self.test_pattern._to_ct()
        ret.signal_processing = self.signal_processing._to_ct()
        ret.acquisition = self.acquisition._to_ct()
        ret.transfer = self.transfer._to_ct()
        ret.readout = self.readout._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQParameters" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQParameters"
                )
            )

        return ADQParameters._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQParameters()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDigitalGainAndOffsetParametersInternalCore(_struct_base):
    _fields_ = [
        ("gain", ct.c_int64),
        ("offset", ct.c_int64),
        ("override_all", ct.c_int32),
        ("override_input_range", ct.c_int32),
    ]

    def _to_native(self) -> "ADQDigitalGainAndOffsetParametersInternalCore":
        ret = ADQDigitalGainAndOffsetParametersInternalCore()
        ret.gain = self.gain
        ret.offset = self.offset
        ret.override_all = self.override_all
        ret.override_input_range = self.override_input_range
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDigitalGainAndOffsetParametersInternalCore(_native_base):
    def __init__(self):
        self.gain: int = 0
        self.offset: int = 0
        self.override_all: int = 0
        self.override_input_range: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "gain",
            "offset",
            "override_all",
            "override_input_range",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDigitalGainAndOffsetParametersInternalCore"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        if not isinstance(other, ADQDigitalGainAndOffsetParametersInternalCore):
            raise TypeError(
                f"Comparison is not supported between { self.__class__.__name__ } and {other.__class__.__name__}"
            )
        return (
            (self.gain == other.gain)
            and (self.offset == other.offset)
            and (self.override_all == other.override_all)
            and (self.override_input_range == other.override_input_range)
        )

    def _to_ct(self) -> _ADQDigitalGainAndOffsetParametersInternalCore:
        ret = _ADQDigitalGainAndOffsetParametersInternalCore()
        ret.gain = self.gain
        ret.offset = self.offset
        ret.override_all = self.override_all
        ret.override_input_range = self.override_input_range
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDigitalGainAndOffsetParametersInternalCore" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDigitalGainAndOffsetParametersInternalCore"
                )
            )

        return ADQDigitalGainAndOffsetParametersInternalCore._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDigitalGainAndOffsetParametersInternalCore()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDigitalGainAndOffsetParametersInternalChannel(_struct_base):
    _fields_ = [
        ("core", (_ADQDigitalGainAndOffsetParametersInternalCore * 4)),
    ]

    def _to_native(self) -> "ADQDigitalGainAndOffsetParametersInternalChannel":
        ret = ADQDigitalGainAndOffsetParametersInternalChannel()
        ret.core = [a._to_native() for a in self.core]
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDigitalGainAndOffsetParametersInternalChannel(_native_base):
    def __init__(self):
        self.core: List[ADQDigitalGainAndOffsetParametersInternalCore] = [
            ADQDigitalGainAndOffsetParametersInternalCore()
        ] * 4

    def __setattr__(self, name, value):
        if name not in [
            "core",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDigitalGainAndOffsetParametersInternalChannel"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQDigitalGainAndOffsetParametersInternalChannel"
        )

    def _to_ct(self) -> _ADQDigitalGainAndOffsetParametersInternalChannel:
        ret = _ADQDigitalGainAndOffsetParametersInternalChannel()
        for a in range(len(self.core)):
            ret.core[a] = self.core[a]._to_ct()
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDigitalGainAndOffsetParametersInternalChannel" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDigitalGainAndOffsetParametersInternalChannel"
                )
            )

        return ADQDigitalGainAndOffsetParametersInternalChannel._from_bytes(
            obj["__raw__"]
        )

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDigitalGainAndOffsetParametersInternalChannel()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


class _ADQDigitalGainAndOffsetParametersInternal(_struct_base):
    _fields_ = [
        ("id", ct.c_int),
        ("reserved", ct.c_int32),
        ("channel", (_ADQDigitalGainAndOffsetParametersInternalChannel * 8)),
        ("magic", ct.c_uint64),
    ]

    def _to_native(self) -> "ADQDigitalGainAndOffsetParametersInternal":
        ret = ADQDigitalGainAndOffsetParametersInternal()
        ret.id = self.id
        ret.reserved = self.reserved
        ret.channel = [a._to_native() for a in self.channel]
        ret.magic = self.magic
        return ret

    @classmethod
    def _from_bytes(cls, data: bytes):
        c = cls()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()


class ADQDigitalGainAndOffsetParametersInternal(_native_base):
    def __init__(self):
        self.id: int = 0  # enum
        self.reserved: int = 0
        self.channel: List[ADQDigitalGainAndOffsetParametersInternalChannel] = [
            ADQDigitalGainAndOffsetParametersInternalChannel()
        ] * 8
        self.magic: int = 0

    def __setattr__(self, name, value):
        if name not in [
            "id",
            "reserved",
            "channel",
            "magic",
        ]:
            raise AttributeError(
                f"No field named '{name}' for ADQDigitalGainAndOffsetParametersInternal"
            )
        else:
            return super().__setattr__(name, value)

    def __eq__(self, other):
        raise TypeError(
            "Comparison not supported for type: ADQDigitalGainAndOffsetParametersInternal"
        )

    def _to_ct(self) -> _ADQDigitalGainAndOffsetParametersInternal:
        ret = _ADQDigitalGainAndOffsetParametersInternal()
        ret.id = self.id
        ret.reserved = self.reserved
        for a in range(len(self.channel)):
            ret.channel[a] = self.channel[a]._to_ct()
        ret.magic = self.magic
        return ret

    def _to_bytes(self) -> bytes:
        b = self._to_ct()
        pdata = ct.cast(ct.byref(b), ct.POINTER(ct.c_char * ct.sizeof(b)))
        return pdata.contents.raw

    @staticmethod
    def _from_dict(obj: dict):
        if "ADQDigitalGainAndOffsetParametersInternal" != obj["name"]:
            raise DeserializeError(
                "Attempting to deserialize {} to {}".format(
                    obj["name"], "ADQDigitalGainAndOffsetParametersInternal"
                )
            )

        return ADQDigitalGainAndOffsetParametersInternal._from_bytes(obj["__raw__"])

    @staticmethod
    def _from_bytes(data: bytes):
        assert isinstance(data, bytes), f"Data is {type(data)}"
        c = _ADQDigitalGainAndOffsetParametersInternal()
        ct.memmove(ct.pointer(c), data, ct.sizeof(c))
        return c._to_native()

    def _to_dict(self) -> dict:
        ret = {"name": self.__class__.__name__, "__raw__": self._to_bytes()}
        return ret


ADQAPI_OBJECT_RESERVED = 0
ADQAPI_OBJECT_ATD_WFA_STRUCT = 1
ADQAPI_OBJECT_ADQ_RECORD_HEADER = 2
ADQAPI_OBJECT_ADQ_INFO_LIST_ENTRY = 3
ADQAPI_OBJECT_ADQ_INFO_LIST_PRE_ALLO_ARRAY = 4
ADQAPI_OBJECT_SD_CARD_CONFIGURATION = 5
ADQAPI_OBJECT_ADQ_DAISY_CHAIN_TRIGGER_INFORMATION = 7
ADQAPI_OBJECT_ADQ_DAISY_CHAIN_DEVICE_INFORMATION = 8
ATD_WFA_BUFFER_FORMAT_INT32 = 0
ATD_WFA_BUFFER_FORMAT_STRUCT = 1
PID_ADQ214 = 0x0001
PID_ADQ114 = 0x0003
PID_ADQ112 = 0x0005
PID_SphinxHS = 0x000B
PID_SphinxLS = 0x000C
PID_ADQ108 = 0x000E
PID_ADQDSP = 0x000F
PID_SphinxAA14 = 0x0011
PID_SphinxAA16 = 0x0012
PID_ADQ412 = 0x0014
PID_ADQ212 = 0x0015
PID_SphinxAA_LS2 = 0x0016
PID_SphinxHS_LS2 = 0x0017
PID_SDR14 = 0x001B
PID_ADQ1600 = 0x001C
PID_SphinxXT = 0x001D
PID_ADQ208 = 0x001E
PID_DSU = 0x001F
PID_ADQ14 = 0x0020
PID_SDR14RF = 0x0021
PID_EV12AS350_EVM = 0x0022
PID_ADQ7 = 0x0023
PID_ADQ8 = 0x0026
PID_ADQ12 = 0x0027
PID_ADQ7Virtual = 0x0030
PID_ADQ3 = 0x0031
PID_ADQSM = 0x0032
PID_TX320 = 0x201A
PID_RX320 = 0x201C
PID_S6000 = 0x2019
HWIF_USB = 0
HWIF_PCIE = 1
HWIF_USB3 = 2
HWIF_PCIELITE = 3
HWIF_ETH_ADQ7 = 4
HWIF_ETH_ADQ14 = 5
HWIF_VIRTUAL = 6
HWIF_QPCIE = 7
HWIF_OTHER = 8
ADQ_COMMUNICATION_INTERFACE_INVALID = 0
ADQ_COMMUNICATION_INTERFACE_PCIE = 1
ADQ_COMMUNICATION_INTERFACE_USB = 2
ADQ_COMMUNICATION_INTERFACE_MAX_VAL = 2147483647
ADQ_STATUS_ID_RESERVED = 0
ADQ_STATUS_ID_OVERFLOW = 1
ADQ_STATUS_ID_DRAM = 2
ADQ_STATUS_ID_ACQUISITION = 3
ADQ_STATUS_ID_TEMPERATURE = 4
ADQ_STATUS_ID_PACKET_OVERFLOW = 65537
ADQ_STATUS_ID_MEMCOM_OVERFLOW = 65538
ADQ_PARAMETER_ID_RESERVED = 0
ADQ_PARAMETER_ID_DATA_ACQUISITION = 1
ADQ_PARAMETER_ID_DATA_TRANSFER = 2
ADQ_PARAMETER_ID_DATA_READOUT = 3
ADQ_PARAMETER_ID_CONSTANT = 4
ADQ_PARAMETER_ID_DIGITAL_GAINANDOFFSET = 5
ADQ_PARAMETER_ID_EVENT_SOURCE_LEVEL = 6
ADQ_PARAMETER_ID_DBS = 7
ADQ_PARAMETER_ID_SAMPLE_SKIP = 8
ADQ_PARAMETER_ID_TEST_PATTERN = 9
ADQ_PARAMETER_ID_EVENT_SOURCE_PERIODIC = 10
ADQ_PARAMETER_ID_EVENT_SOURCE_TRIG = 11
ADQ_PARAMETER_ID_EVENT_SOURCE_SYNC = 12
ADQ_PARAMETER_ID_ANALOG_FRONTEND = 13
ADQ_PARAMETER_ID_PATTERN_GENERATOR0 = 14
ADQ_PARAMETER_ID_PATTERN_GENERATOR1 = 15
ADQ_PARAMETER_ID_EVENT_SOURCE = 16
ADQ_PARAMETER_ID_SIGNAL_PROCESSING = 17
ADQ_PARAMETER_ID_FUNCTION = 18
ADQ_PARAMETER_ID_TOP = 19
ADQ_PARAMETER_ID_PORT_TRIG = 20
ADQ_PARAMETER_ID_PORT_SYNC = 21
ADQ_PARAMETER_ID_PORT_SYNCO = 22
ADQ_PARAMETER_ID_PORT_SYNCI = 23
ADQ_PARAMETER_ID_PORT_CLK = 24
ADQ_PARAMETER_ID_PORT_CLKI = 25
ADQ_PARAMETER_ID_PORT_CLKO = 26
ADQ_PARAMETER_ID_PORT_GPIOA = 27
ADQ_PARAMETER_ID_PORT_GPIOB = 28
ADQ_PARAMETER_ID_PORT_PXIE = 29
ADQ_PARAMETER_ID_PORT_MTCA = 30
ADQ_PARAMETER_ID_PULSE_GENERATOR0 = 31
ADQ_PARAMETER_ID_PULSE_GENERATOR1 = 32
ADQ_PARAMETER_ID_PULSE_GENERATOR2 = 33
ADQ_PARAMETER_ID_PULSE_GENERATOR3 = 34
ADQ_PARAMETER_ID_TIMESTAMP_SYNCHRONIZATION = 35
ADQ_PARAMETER_ID_FIR_FILTER = 36
ADQ_PARAMETER_ID_CLOCK_SYSTEM = 40
ADQ_PARAMETER_ID_INTERNAL_DIGITAL_GAINANDOFFSET = 65536
ADQ_PARAMETER_ID_MAX_VAL = 2147483647
ADQ_EVENT_SOURCE_INVALID = 0
ADQ_EVENT_SOURCE_SOFTWARE = 1
ADQ_EVENT_SOURCE_TRIG = 2
ADQ_EVENT_SOURCE_LEVEL = 3
ADQ_EVENT_SOURCE_PERIODIC = 4
ADQ_EVENT_SOURCE_PXIE_STARB = 6
ADQ_EVENT_SOURCE_TRIG2 = 7
ADQ_EVENT_SOURCE_TRIG3 = 8
ADQ_EVENT_SOURCE_SYNC = 9
ADQ_EVENT_SOURCE_MTCA_MLVDS = 10
ADQ_EVENT_SOURCE_TRIG_GATED_SYNC = 11
ADQ_EVENT_SOURCE_TRIG_CLKREF_SYNC = 12
ADQ_EVENT_SOURCE_MTCA_MLVDS_CLKREF_SYNC = 13
ADQ_EVENT_SOURCE_PXI_TRIG = 14
ADQ_EVENT_SOURCE_PXIE_STARB_CLKREF_SYNC = 16
ADQ_EVENT_SOURCE_SYNC_CLKREF_SYNC = 19
ADQ_EVENT_SOURCE_DAISY_CHAIN = 23
ADQ_EVENT_SOURCE_SOFTWARE_CLKREF_SYNC = 24
ADQ_EVENT_SOURCE_GPIOA0 = 25
ADQ_EVENT_SOURCE_GPIOA1 = 26
ADQ_EVENT_SOURCE_LEVEL_CHANNEL0 = 100
ADQ_EVENT_SOURCE_LEVEL_CHANNEL1 = 101
ADQ_EVENT_SOURCE_LEVEL_CHANNEL2 = 102
ADQ_EVENT_SOURCE_LEVEL_CHANNEL3 = 103
ADQ_EVENT_SOURCE_LEVEL_CHANNEL4 = 104
ADQ_EVENT_SOURCE_LEVEL_CHANNEL5 = 105
ADQ_EVENT_SOURCE_LEVEL_CHANNEL6 = 106
ADQ_EVENT_SOURCE_LEVEL_CHANNEL7 = 107
ADQ_EVENT_SOURCE_MAX_VAL = 2147483647
ADQ_TEST_PATTERN_SOURCE_DISABLE = 0
ADQ_TEST_PATTERN_SOURCE_COUNT_UP = 1
ADQ_TEST_PATTERN_SOURCE_COUNT_DOWN = 2
ADQ_TEST_PATTERN_SOURCE_TRIANGLE = 3
ADQ_TEST_PATTERN_SOURCE_PULSE = 4
ADQ_TEST_PATTERN_SOURCE_PULSE_PRBS_WIDTH = 5
ADQ_TEST_PATTERN_SOURCE_PULSE_PRBS_AMPLITUDE = 6
ADQ_TEST_PATTERN_SOURCE_PULSE_PRBS_WIDTH_AMPLITUDE = 7
ADQ_TEST_PATTERN_SOURCE_PULSE_NOISE = 8
ADQ_TEST_PATTERN_SOURCE_PULSE_NOISE_PRBS_WIDTH = 9
ADQ_TEST_PATTERN_SOURCE_PULSE_NOISE_PRBS_AMPLITUDE = 10
ADQ_TEST_PATTERN_SOURCE_PULSE_NOISE_PRBS_WIDTH_AMPLITUDE = 11
ADQ_TEST_PATTERN_SOURCE_MAX_VAL = 2147483647
ADQ_PORT_TRIG = 0
ADQ_PORT_SYNC = 1
ADQ_PORT_SYNCO = 2
ADQ_PORT_SYNCI = 3
ADQ_PORT_CLK = 4
ADQ_PORT_CLKI = 5
ADQ_PORT_CLKO = 6
ADQ_PORT_GPIOA = 7
ADQ_PORT_GPIOB = 8
ADQ_PORT_PXIE = 9
ADQ_PORT_MTCA = 10
ADQ_PORT_MAX_VAL = 2147483647
ADQ_PIN_PXIE_TRIG0 = 0
ADQ_PIN_PXIE_TRIG1 = 1
ADQ_PIN_PXIE_STARA = 2
ADQ_PIN_PXIE_STARB = 3
ADQ_PIN_PXIE_MAX_VAL = 2147483647
ADQ_PIN_MTCA_R17 = 0
ADQ_PIN_MTCA_T17 = 1
ADQ_PIN_MTCA_R18 = 2
ADQ_PIN_MTCA_T18 = 3
ADQ_PIN_MTCA_R19 = 4
ADQ_PIN_MTCA_T19 = 5
ADQ_PIN_MTCA_R20 = 6
ADQ_PIN_MTCA_T20 = 7
ADQ_PIN_MTCA_MAX_VAL = 2147483647
ADQ_IMPEDANCE_50_OHM = 0
ADQ_IMPEDANCE_HIGH = 1
ADQ_IMPEDANCE_MAX_VAL = 2147483647
ADQ_DIRECTION_IN = 0
ADQ_DIRECTION_OUT = 1
ADQ_DIRECTION_INOUT = 2
ADQ_DIRECTION_MAXVAL = 2147483647
ADQ_EDGE_FALLING = 0
ADQ_EDGE_RISING = 1
ADQ_EDGE_BOTH = 2
ADQ_EDGE_MAX_VAL = 2147483647
ADQ_CLOCK_SOURCE_INVALID = -1
ADQ_CLOCK_SOURCE_INTREF = 0
ADQ_CLOCK_SOURCE_EXTREF = 1
ADQ_CLOCK_SOURCE_EXTCLK = 2
ADQ_CLOCK_SOURCE_PXIE_10M = 3
ADQ_CLOCK_SOURCE_MTCA_TCLKA = 4
ADQ_CLOCK_SOURCE_MTCA_TCLKB = 5
ADQ_CLOCK_SOURCE_PXIE_100M = 6
ADQ_CLOCK_SOURCE_EXTREF_LOWJITTER = 7
ADQ_CLOCK_SOURCE_EXTREF_DELAY = 8
ADQ_CLOCK_SOURCE_MAX_VAL = 2147483647
ADQ_CLOCK_REFERENCE_SOURCE_INVALID = 0
ADQ_CLOCK_REFERENCE_SOURCE_INTERNAL = 1
ADQ_CLOCK_REFERENCE_SOURCE_PORT_CLK = 2
ADQ_CLOCK_REFERENCE_SOURCE_PXIE_10M = 3
ADQ_CLOCK_REFERENCE_SOURCE_MTCA_TCLKA = 4
ADQ_CLOCK_REFERENCE_SOURCE_MTCA_TCLKB = 5
ADQ_CLOCK_REFERENCE_SOURCE_PXIE_100M = 6
ADQ_CLOCK_REFERENCE_SOURCE_MAX_VAL = 2147483647
ADQ_CLOCK_GENERATOR_INVALID = 0
ADQ_CLOCK_GENERATOR_INTERNAL_PLL = 1
ADQ_CLOCK_GENERATOR_EXTERNAL_CLOCK = 2
ADQ_CLOCK_GENERATOR_MAX_VAL = 2147483647
ADQ_FUNCTION_INVALID = 0
ADQ_FUNCTION_PATTERN_GENERATOR0 = 1
ADQ_FUNCTION_PATTERN_GENERATOR1 = 2
ADQ_FUNCTION_GPIO = 3
ADQ_FUNCTION_PULSE_GENERATOR0 = 4
ADQ_FUNCTION_PULSE_GENERATOR1 = 5
ADQ_FUNCTION_PULSE_GENERATOR2 = 6
ADQ_FUNCTION_PULSE_GENERATOR3 = 7
ADQ_FUNCTION_TIMESTAMP_SYNCHRONIZATION = 8
ADQ_FUNCTION_MAX_VAL = 2147483647
ADQ_ROUNDING_METHOD_TIE_AWAY_FROM_ZERO = 0
ADQ_ROUNDING_METHOD_TIE_TOWARDS_ZERO = 1
ADQ_ROUNDING_METHOD_TIE_TO_EVEN = 2
ADQ_ROUNDING_METHOD_MAX_VAL = 2147483647
ADQ_COEFFICIENT_FORMAT_DOUBLE = 0
ADQ_COEFFICIENT_FORMAT_FIXED_POINT = 1
ADQ_COEFFICIENT_FORMAT_MAX_VAL = 2147483647
ADQ_USER_LOGIC_RESERVED = 0
ADQ_USER_LOGIC1 = 1
ADQ_USER_LOGIC2 = 2
ADQ_USER_LOGIC_MAX_VAL = 2147483647
ADQ_PATTERN_GENERATOR_OPERATION_TIMER = 0
ADQ_PATTERN_GENERATOR_OPERATION_EVENT = 1
ADQ_PATTERN_GENERATOR_OPERATION_MAX_VAL = 2147483647
ADQ_MARKER_MODE_HOST_AUTO = 0
ADQ_MARKER_MODE_HOST_MANUAL = 1
ADQ_MARKER_MODE_USER_ADDR = 2
ADQ_MARKER_MODE_MAX_VAL = 2147483647
ADQ_MEMORY_OWNER_API = 0
ADQ_MEMORY_OWNER_USER = 1
ADQ_MEMORY_OWNER_MAX_VAL = 2147483647
ADQ_TIMESTAMP_SYNCHRONIZATION_MODE_DISABLE = 0
ADQ_TIMESTAMP_SYNCHRONIZATION_MODE_FIRST = 1
ADQ_TIMESTAMP_SYNCHRONIZATION_MODE_ALL = 2
ADQ_TIMESTAMP_SYNCHRONIZATION_MODE_MAX_VAL = 2147483647
ADQ_TIMESTAMP_SYNCHRONIZATION_ARM_IMMEDIATE = 0
ADQ_TIMESTAMP_SYNCHRONIZATION_ARM_ACQUISITION = 1
ADQ_TIMESTAMP_SYNCHRONIZATION_ARM_MAX_VAL = 2147483647
ADQ_SYSTEM_MANAGER_NOT_PRESENT = 0
ADQ_SYSTEM_MANAGER_CONMAN_I2C = 1
ADQ_SYSTEM_MANAGER_CONMAN_SPI = 2
ADQ_SYSTEM_MANAGER_SYSMAN_GEN4 = 3
ADQ_SYSTEM_MANAGER_MAX_VAL = 2147483647

ADQAPI_REVISION = 59780
ADQ_EOK = 0
ADQ_EINVAL = -1
ADQ_EAGAIN = -2
ADQ_EOVERFLOW = -3
ADQ_ENOTREADY = -4
ADQ_EINTERRUPTED = -5
ADQ_EIO = -6
ADQ_EEXTERNAL = -7
ADQ_EUNSUPPORTED = -8
ADQ_EINTERNAL = -9
INT32_MAX = 2147483647
ADQ7_STREAM_RECORD_MIN_BYTES = 128
ADQ7_STREAM_CHUNK_BYTES = 1024
ADQ14_STREAM_RECORD_MIN_BYTES = 128
ADQ14_STREAM_CHUNK_BYTES = 1024
ADQAPI_VERSION_MAJOR = 4
ADQAPI_VERSION_MINOR = 0
ADQ_MAX_NOF_CHANNELS = 8
ADQ_MAX_NOF_BUFFERS = 16
ADQ_MAX_NOF_PORTS = 8
ADQ_MAX_NOF_PINS = 16
ADQ_MAX_NOF_ADC_CORES = 4
ADQ_MAX_NOF_INPUT_RANGES = 8
ADQ_MAX_NOF_PATTERN_GENERATORS = 2
ADQ_MAX_NOF_PULSE_GENERATORS = 4
ADQ_MAX_NOF_PATTERN_INSTRUCTIONS = 16
ADQ_MAX_NOF_TEMPERATURE_SENSORS = 16
ADQ_MAX_NOF_FILTER_COEFFICIENTS = 10
ADQ_MARKER_BYTES_WRITTEN_INDEX = 0
ADQ_MARKER_NOF_RECORDS_INDEX = 1
ADQ_MARKER_STATUS_INDEX = 2
ADQ_MARKER_DRAM_LEVEL_INDEX = 3
ADQ_MARKER_COUNTER_INDEX = 4
ADQ_MARKER_STATUS_OVERFLOW_POS = 0
ADQ_MARKER_STATUS_FLUSH_POS = 1
ADQ_ANY_CHANNEL = -1
ADQ_INFINITE_RECORD_LENGTH = -1
ADQ_INFINITE_NOF_RECORDS = -1
ADQ_PARAMETERS_MAGIC = 0xAA559977AA559977
ADQ_GEN4_RECORD_HEADER_MISC_PATTERN_GENERATOR_POS = 0
ADQ_DATA_READOUT_STATUS_FLAGS_OK = 0
ADQ_DATA_READOUT_STATUS_FLAGS_STARVING = 1
ADQ_DATA_READOUT_STATUS_FLAGS_INCOMPLETE = 2
ADQ_UNITY_GAIN = 1024
ADQ_CLOCK_INT_INTREF = 0
ADQ_CLOCK_INT_EXTREF = 1
ADQ_CLOCK_EXT = 2
ADQ_CLOCK_INT_PXIREF = 3
ADQ_CLOCK_INT_MTCA_A = 4
ADQ_CLOCK_INT_MTCA_B = 5
ADQ_CLOCK_INT_PXIREF100 = 6
ADQ_CLOCK_INT_RESERVED = 7
ADQ_CLOCK_INT_RESERVED2 = 8
ADQ_TRANSFER_MODE_NORMAL = 0x0
ADQ_TRANSFER_MODE_HEADER_ONLY = 0x1
ADQ_ALL_CHANNELS_MASK = 0xFF
ADQ_GETDATA_MAX_NOF_CHANNELS = 8
ADQ_SW_TRIGGER_MODE = 1
ADQ_EXT_TRIGGER_MODE = 2
ADQ_LEVEL_TRIGGER_MODE = 3
ADQ_INTERNAL_TRIGGER_MODE = 4
ADQ_GATED_ACQ_ACTIVE_HIGH_TRIGGER_MODE = 20
ADQ_GATED_ACQ_ACTIVE_LOW_TRIGGER_MODE = 21
ADQ_LEVEL_TRIGGER_USE_DEFAULT_RESETLEVEL = 0xFFFFFFFF
ADQ_LEVEL_TRIGGER_ALL_CHANNELS = 0xF
ADQ_D2DFLAG_CONST_ADDR = 0x1
LOG_LEVEL_PRINT = 0x0
LOG_LEVEL_ERROR = 0x1
LOG_LEVEL_WARN = 0x2
LOG_LEVEL_INFO = 0x3
LOG_LEVEL_RTONLY = 0x20000
ETH10_FREQ_156_25MHZ = 1
ETH10_FREQ_125MHZ = 0
ETH1_FREQ_156_25MHZ = 1
ETH1_FREQ_125MHZ = 0
PP_FREQ_330MHZ = 3
PP_FREQ_250MHZ = 2
PP_FREQ_156_25MHZ = 1
PP_FREQ_125MHZ = 0
ADQ112_DATA_FORMAT_PACKED_12BIT = 0
ADQ112_DATA_FORMAT_UNPACKED_12BIT = 1
ADQ112_DATA_FORMAT_UNPACKED_16BIT = 2
ADQ112_DATA_FORMAT_UNPACKED_32BIT = 3
ADQ112_STREAM_DISABLED = 0
ADQ112_STREAM_ENABLED = 7
ADQ114_DATA_FORMAT_PACKED_14BIT = 0
ADQ114_DATA_FORMAT_UNPACKED_14BIT = 1
ADQ114_DATA_FORMAT_UNPACKED_16BIT = 2
ADQ114_DATA_FORMAT_UNPACKED_32BIT = 3
ADQ114_STREAM_DISABLED = 0
ADQ114_STREAM_ENABLED = 7
ADQ212_DATA_FORMAT_PACKED_14BIT = 0
ADQ212_DATA_FORMAT_UNPACKED_14BIT = 1
ADQ212_DATA_FORMAT_UNPACKED_16BIT = 2
ADQ212_DATA_FORMAT_UNPACKED_32BIT = 3
ADQ212_STREAM_DISABLED = 0
ADQ212_STREAM_ENABLED_BOTH = 7
ADQ212_STREAM_ENABLED_A = 3
ADQ212_STREAM_ENABLED_B = 5
ADQ214_DATA_FORMAT_PACKED_14BIT = 0
ADQ214_DATA_FORMAT_UNPACKED_14BIT = 1
ADQ214_DATA_FORMAT_UNPACKED_16BIT = 2
ADQ214_DATA_FORMAT_UNPACKED_32BIT = 3
ADQ214_STREAM_DISABLED = 0
ADQ214_STREAM_ENABLED_BOTH = 7
ADQ214_STREAM_ENABLED_A = 3
ADQ214_STREAM_ENABLED_B = 5
ADQ412_DATA_FORMAT_PACKED_12BIT = 0
ADQ412_DATA_FORMAT_UNPACKED_16BIT = 2
ADQ412_STREAM_DISABLED = 0
ADQ412_STREAM_ENABLED = 1
REC_IP_STATUS_SETUP_OK = 0x1
REC_IP_STATUS_WAITINGFORDATA = 0x2
REC_IP_STATUS_CMD_ANSWERED = 0x4
REC_IP_STATUS_CMD_SUCCESS = 0x8
REC_IP_STATUS_DISK_INIT_OK = 0x4000
REC_IP_STATUS_ERROR = 0xF0000000
REC_IP_STATUS_READ_STUCK_ERROR = 0x8000000
REC_IP_STATUS_WRITE_STUCK_ERROR = 0x4000000
REC_IP_STATUS_DISK_SECTOR_ERROR = 0x2000000
REC_IP_STATUS_DISK_ERASE_ERROR = 0x1000000
REC_IP_STATUS_IN_TEST = 0x10
REC_IP_STATUS_IN_WRITE = 0x20
REC_IP_STATUS_IN_READ = 0x40
REC_IP_DISK_STATUS_INIT_OK = 0x1
REC_IP_DISK_STATUS_ERASE_ERROR = 0x10
REC_IP_CMD_SET_NOFDISKS = 0x1
REC_IP_CMD_DISK_INIT = 0x2
REC_IP_CMD_SET_PARAMETER = 0x3
REC_IP_CMD_ERASE_DISK = 0x4
REC_IP_CMD_TEST_PERFORMANCE = 0x5
REC_IP_CMD_START_DATA_RECORDING = 0x6
REC_IP_CMD_END_DATA_RECORDING = 0x7
REC_IP_CMD_START_DATA_READING = 0x8
REC_IP_CMD_RESTART_DATA_RECORDING = 0x9
REC_IP_CMD_DEBUG = 0xA
REC_IP_CMD_READ_INTERNAL_STATUS = 0xB
REC_IP_CMD_GET_PARAMETER = 0xC
REC_IP_CMD_RESET = 0xD
REC_IP_PAR_SECTOR_SIZE = 1
REC_IP_PAR_REC_STRIP_SIZE = 2
REC_IP_PAR_REC_START_ADDRESS = 100
REC_IP_PAR_REC_END_ADDRESS = 101
REC_IP_PAR_SECTORS_PER_ATA = 105


_ParameterStructs = Union[
    ADQDataAcquisitionParameters,
    ADQDataTransferParameters,
    ADQDataReadoutParameters,
    ADQConstantParameters,
    ADQDigitalGainAndOffsetParameters,
    ADQEventSourceLevelParameters,
    ADQDbsParameters,
    ADQSampleSkipParameters,
    ADQTestPatternParameters,
    ADQEventSourcePeriodicParameters,
    ADQEventSourcePortParameters,
    ADQAnalogFrontendParameters,
    ADQPatternGeneratorParameters,
    ADQEventSourceParameters,
    ADQSignalProcessingParameters,
    ADQFunctionParameters,
    ADQParameters,
    ADQPortParameters,
    ADQPulseGeneratorParameters,
    ADQTimestampSynchronizationParameters,
    ADQClockSystemParameters,
    ADQDigitalGainAndOffsetParametersInternal,
    ADQFirFilterParameters,
]


def _enum_to_parameter_struct(param_id: int) -> _ParameterStructs:
    if param_id == ADQ_PARAMETER_ID_DATA_ACQUISITION:
        return ADQDataAcquisitionParameters()
    if param_id == ADQ_PARAMETER_ID_DATA_TRANSFER:
        return ADQDataTransferParameters()
    if param_id == ADQ_PARAMETER_ID_DATA_READOUT:
        return ADQDataReadoutParameters()
    if param_id == ADQ_PARAMETER_ID_CONSTANT:
        return ADQConstantParameters()
    if param_id == ADQ_PARAMETER_ID_DIGITAL_GAINANDOFFSET:
        return ADQDigitalGainAndOffsetParameters()
    if param_id == ADQ_PARAMETER_ID_EVENT_SOURCE_LEVEL:
        return ADQEventSourceLevelParameters()
    if param_id == ADQ_PARAMETER_ID_DBS:
        return ADQDbsParameters()
    if param_id == ADQ_PARAMETER_ID_SAMPLE_SKIP:
        return ADQSampleSkipParameters()
    if param_id == ADQ_PARAMETER_ID_TEST_PATTERN:
        return ADQTestPatternParameters()
    if param_id == ADQ_PARAMETER_ID_EVENT_SOURCE_PERIODIC:
        return ADQEventSourcePeriodicParameters()
    if param_id == ADQ_PARAMETER_ID_EVENT_SOURCE_TRIG:
        return ADQEventSourcePortParameters()
    if param_id == ADQ_PARAMETER_ID_EVENT_SOURCE_SYNC:
        return ADQEventSourcePortParameters()
    if param_id == ADQ_PARAMETER_ID_ANALOG_FRONTEND:
        return ADQAnalogFrontendParameters()
    if param_id == ADQ_PARAMETER_ID_PATTERN_GENERATOR0:
        return ADQPatternGeneratorParameters()
    if param_id == ADQ_PARAMETER_ID_PATTERN_GENERATOR1:
        return ADQPatternGeneratorParameters()
    if param_id == ADQ_PARAMETER_ID_EVENT_SOURCE:
        return ADQEventSourceParameters()
    if param_id == ADQ_PARAMETER_ID_SIGNAL_PROCESSING:
        return ADQSignalProcessingParameters()
    if param_id == ADQ_PARAMETER_ID_FUNCTION:
        return ADQFunctionParameters()
    if param_id == ADQ_PARAMETER_ID_TOP:
        return ADQParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_TRIG:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_SYNC:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_SYNCO:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_SYNCI:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_CLK:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_CLKI:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_CLKO:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_GPIOA:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_GPIOB:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_PXIE:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PORT_MTCA:
        return ADQPortParameters()
    if param_id == ADQ_PARAMETER_ID_PULSE_GENERATOR0:
        return ADQPulseGeneratorParameters()
    if param_id == ADQ_PARAMETER_ID_PULSE_GENERATOR1:
        return ADQPulseGeneratorParameters()
    if param_id == ADQ_PARAMETER_ID_PULSE_GENERATOR2:
        return ADQPulseGeneratorParameters()
    if param_id == ADQ_PARAMETER_ID_PULSE_GENERATOR3:
        return ADQPulseGeneratorParameters()
    if param_id == ADQ_PARAMETER_ID_TIMESTAMP_SYNCHRONIZATION:
        return ADQTimestampSynchronizationParameters()
    if param_id == ADQ_PARAMETER_ID_CLOCK_SYSTEM:
        return ADQClockSystemParameters()
    if param_id == ADQ_PARAMETER_ID_INTERNAL_DIGITAL_GAINANDOFFSET:
        return ADQDigitalGainAndOffsetParametersInternal()
    if param_id == ADQ_PARAMETER_ID_FIR_FILTER:
        return ADQFirFilterParameters()
    raise Error(f"Unsupported parameter id: {param_id}")


_StatusStructs = Union[
    ADQOverflowStatus,
    ADQDramStatus,
    ADQAcquisitionStatus,
    ADQTemperatureStatus,
]


def _enum_to_status_struct(status_id: int) -> _StatusStructs:
    if status_id == ADQ_STATUS_ID_OVERFLOW:
        return ADQOverflowStatus()
    if status_id == ADQ_STATUS_ID_DRAM:
        return ADQDramStatus()
    if status_id == ADQ_STATUS_ID_ACQUISITION:
        return ADQAcquisitionStatus()
    if status_id == ADQ_STATUS_ID_TEMPERATURE:
        return ADQTemperatureStatus()
    raise Error(f"Unsupported status id: {status_id}")


# Custom class to handle char* -> python str conversion
class _c_utf8_p(ct.c_char_p):
    @classmethod
    def _check_retval_(cls, result):
        value = result.value
        return value.decode("utf-8")

    @classmethod
    def from_param(cls, obj: Any):
        if isinstance(obj, str):
            return super().from_param(obj.encode("utf-8"))
        else:
            return super().from_param(obj)


def _set_api_function_types(obj):
    obj.ADQ_GetBoardSerialNumber.restype = _c_utf8_p  # type: ignore
    obj.ADQ_GetBoardProductName.restype = _c_utf8_p  # type: ignore
    obj.ADQ_GetCardOption.restype = _c_utf8_p  # type: ignore

    try:
        obj.ADQ_GetPtrData.restype = ct.c_void_p  # type: ignore
        obj.ADQ_GetPtrData.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPtrData' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetDataFormat.restype = ct.c_int  # type: ignore
        obj.ADQ_SetDataFormat.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetDataFormat' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetADQType.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetADQType' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetNofChannels.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetNofChannels' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetNofProcessingChannels.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetNofProcessingChannels' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetNofHwChannels.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetNofHwChannels' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetNofFPGAs.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetNofFPGAs' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDRAMPhysEndAddr.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetDRAMPhysEndAddr.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetDRAMPhysEndAddr' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetPtrDataChA.restype = ct.POINTER(ct.c_int)  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPtrDataChA' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetPtrDataChB.restype = ct.POINTER(ct.c_int)  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPtrDataChB' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetLvlTrigChannel.restype = ct.c_int  # type: ignore
        obj.ADQ_SetLvlTrigChannel.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetLvlTrigChannel' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetLvlTrigChannel.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetLvlTrigChannel' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTriggedCh.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTriggedCh' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetAlgoNyquistBand.restype = ct.c_int  # type: ignore
        obj.ADQ_SetAlgoNyquistBand.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetAlgoNyquistBand' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetAlgoStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_SetAlgoStatus.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetAlgoStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetSampleSkip.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetSampleSkip.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetSampleSkip' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetSampleSkip.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetSampleSkip' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_MultiRecordGetRecord.restype = ct.c_uint  # type: ignore
        obj.ADQ_MultiRecordGetRecord.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_MultiRecordGetRecord' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_CollectRecord.restype = ct.c_uint  # type: ignore
        obj.ADQ_CollectRecord.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_CollectRecord' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetSampleDecimation.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetSampleDecimation.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetSampleDecimation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetSampleDecimation.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetSampleDecimation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetChannelDecimation.restype = ct.c_int  # type: ignore
        obj.ADQ_SetChannelDecimation.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetChannelDecimation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetChannelDecimation.restype = ct.c_int  # type: ignore
        obj.ADQ_GetChannelDecimation.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetChannelDecimation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetAfeSwitch.restype = ct.c_int  # type: ignore
        obj.ADQ_SetAfeSwitch.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetAfeSwitch' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetAfeSwitch.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetAfeSwitch.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_ubyte),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetAfeSwitch' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetNofAdcCores.restype = ct.c_int  # type: ignore
        obj.ADQ_GetNofAdcCores.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetNofAdcCores' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetGainAndOffset.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetGainAndOffset.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_int,
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetGainAndOffset' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetGainAndOffset.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetGainAndOffset.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_int),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetGainAndOffset' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetInterleavingMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInterleavingMode.argtypes = [  # type: ignore
            ct.c_char,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInterleavingMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetInterleavingIPEstimationMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInterleavingIPEstimationMode.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInterleavingIPEstimationMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetInterleavingIPEstimationMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetInterleavingIPEstimationMode.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetInterleavingIPEstimationMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetInterleavingIPBypassMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInterleavingIPBypassMode.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInterleavingIPBypassMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetInterleavingIPBypassMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetInterleavingIPBypassMode.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetInterleavingIPBypassMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetInterleavingIPCalibration.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInterleavingIPCalibration.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInterleavingIPCalibration' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetInterleavingIPCalibration.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetInterleavingIPCalibration.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetInterleavingIPCalibration' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ResetInterleavingIP.restype = ct.c_uint  # type: ignore
        obj.ADQ_ResetInterleavingIP.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ResetInterleavingIP' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_InterleavingIPTemperatureAutoUpdate.restype = ct.c_int  # type: ignore
        obj.ADQ_InterleavingIPTemperatureAutoUpdate.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_InterleavingIPTemperatureAutoUpdate' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ReadADCCalibration.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReadADCCalibration.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_ushort),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ReadADCCalibration' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WriteADCCalibration.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteADCCalibration.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_ushort),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WriteADCCalibration' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnableClockRefOut.restype = ct.c_uint  # type: ignore
        obj.ADQ_EnableClockRefOut.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_EnableClockRefOut' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetPPTStatus.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPPTStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_InitPPT.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_InitPPT' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetPPTActive.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetPPTActive.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetPPTActive' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetPPTInitOffset.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetPPTInitOffset.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetPPTInitOffset' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetPPTPeriod.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetPPTPeriod.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetPPTPeriod' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetPPTBurstMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetPPTBurstMode.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetPPTBurstMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetComFlashEnableBit.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetComFlashEnableBit' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_RebootCOMFPGAFromSecondaryImage.restype = ct.c_uint  # type: ignore
        obj.ADQ_RebootCOMFPGAFromSecondaryImage.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_RebootCOMFPGAFromSecondaryImage' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_RebootALGFPGAFromPrimaryImage.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_RebootALGFPGAFromPrimaryImage' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ReBootADQFromFlash.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReBootADQFromFlash.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ReBootADQFromFlash' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ProcessorFlashControl.restype = ct.c_uint  # type: ignore
        obj.ADQ_ProcessorFlashControl.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ProcessorFlashControl' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ProcessorFlashControlData.restype = ct.c_uint  # type: ignore
        obj.ADQ_ProcessorFlashControlData.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ProcessorFlashControlData' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetInternalTriggerFrequency.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInternalTriggerFrequency.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInternalTriggerFrequency' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingOneChannelSetup.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingOneChannelSetup.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingOneChannelSetup' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingSetupV5.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingSetupV5.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingSetupV5' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingArmV5.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingArmV5' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingGetStatusV5.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingGetStatusV5.argtypes = [  # type: ignore
            ct.POINTER(ct.c_ubyte),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_ubyte),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingGetStatusV5' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingShutdownV5.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingShutdownV5' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingGetWaveformV5.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingGetWaveformV5.argtypes = [  # type: ignore
            ct.POINTER(ct.c_short),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingGetWaveformV5' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingDisarmV5.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingDisarmV5' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingParseDataStream.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingParseDataStream.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.POINTER(ct.c_int)),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingParseDataStream' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingSetup.restype = ct.c_uint  # type: ignore
        obj.ADQ_WaveformAveragingSetup.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingSetup' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingArm.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingArm' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingDisarm.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingDisarm' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingStartReadout.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingStartReadout' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingGetWaveform.restype = ct.c_uint  # type: ignore
        obj.ADQ_WaveformAveragingGetWaveform.argtypes = [  # type: ignore
            ct.POINTER(ct.c_int),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingGetWaveform' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingGetStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_WaveformAveragingGetStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_ubyte),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_ubyte),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingGetStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingShutdown.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingShutdown' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingParseDataStream.restype = ct.c_uint  # type: ignore
        obj.ADQ_WaveformAveragingParseDataStream.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.POINTER(ct.c_int)),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingParseDataStream' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaveformAveragingSoftwareTrigger.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaveformAveragingSoftwareTrigger' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ResetOverheat.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ResetOverheat' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDSPData.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDSPData' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDSPDataNowait.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDSPDataNowait' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PacketStreamingSetup.restype = ct.c_uint  # type: ignore
        obj.ADQ_PacketStreamingSetup.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PacketStreamingSetup' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PacketStreamingArm.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PacketStreamingArm' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PacketStreamingDisarm.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PacketStreamingDisarm' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_InitTransfer.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_InitTransfer' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetSendLength.restype = ct.c_int  # type: ignore
        obj.ADQ_SetSendLength.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetSendLength' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetSendLength.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetSendLength' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WaitForPCIeDMAFinish.restype = ct.c_int  # type: ignore
        obj.ADQ_WaitForPCIeDMAFinish.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaitForPCIeDMAFinish' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetPhysicalAddress.restype = ct.c_ulong  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetPhysicalAddress' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetDACOffsetVoltage.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetDACOffsetVoltage.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_float,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetDACOffsetVoltage' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_AWGReset.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGReset.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGReset' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGmalloc.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGmalloc.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGmalloc' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGSegmentMalloc.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGSegmentMalloc.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGSegmentMalloc' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGWriteSegment.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGWriteSegment.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_int),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGWriteSegment' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGWriteSegments.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGWriteSegments.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.POINTER(ct.c_short)),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGWriteSegments' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGWritePlaylist.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGWritePlaylist.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGWritePlaylist' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGWritePlaylistItem.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGWritePlaylistItem.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_AWGWritePlaylistItem' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_AWGPlaylistMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGPlaylistMode.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGPlaylistMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGEnableSegments.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGEnableSegments.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGEnableSegments' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGAutoRearm.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGAutoRearm.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGAutoRearm' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGContinuous.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGContinuous.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGContinuous' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGTrigMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGTrigMode.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGTrigMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGArm.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGArm.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGArm' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGDisarm.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGDisarm.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGDisarm' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGTrig.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGTrig.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGTrig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SendIPCommand.restype = ct.c_uint  # type: ignore
        obj.ADQ_SendIPCommand.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SendIPCommand' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OffsetDACSpiWrite.restype = ct.c_uint  # type: ignore
        obj.ADQ_OffsetDACSpiWrite.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OffsetDACSpiWrite' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DACSpiWrite.restype = ct.c_uint  # type: ignore
        obj.ADQ_DACSpiWrite.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DACSpiWrite' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DACSpiRead.restype = ct.c_uint  # type: ignore
        obj.ADQ_DACSpiRead.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
            ct.POINTER(ct.c_ubyte),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DACSpiRead' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TrigOutEn.restype = ct.c_int  # type: ignore
        obj.ADQ_TrigOutEn.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TrigOutEn' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ADCCalibrate.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ADCCalibrate' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteSTARBDelay.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteSTARBDelay.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteSTARBDelay' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_EnablePXIeTriggers.restype = ct.c_uint  # type: ignore
        obj.ADQ_EnablePXIeTriggers.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnablePXIeTriggers' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnablePXIeTrigout.restype = ct.c_uint  # type: ignore
        obj.ADQ_EnablePXIeTrigout.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_EnablePXIeTrigout' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PXIeSoftwareTrigger.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PXIeSoftwareTrigger' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetPXIeTrigDirection.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetPXIeTrigDirection.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetPXIeTrigDirection' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_AWGSetupTrigout.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGSetupTrigout.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGSetupTrigout' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGTrigoutArm.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGTrigoutArm.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGTrigoutArm' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGTrigoutDisarm.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGTrigoutDisarm.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_AWGTrigoutDisarm' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AWGSetTriggerEnable.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGSetTriggerEnable.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_AWGSetTriggerEnable' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_AWGSetInterpolationFilter.restype = ct.c_uint  # type: ignore
        obj.ADQ_AWGSetInterpolationFilter.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_AWGSetInterpolationFilter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ResetRecorder.restype = ct.c_uint  # type: ignore
        obj.ADQ_ResetRecorder.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ResetRecorder' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ResetFIFOPaths.restype = ct.c_uint  # type: ignore
        obj.ADQ_ResetFIFOPaths.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ResetFIFOPaths' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RunRecorderSelfTest.restype = ct.c_uint  # type: ignore
        obj.ADQ_RunRecorderSelfTest.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_RunRecorderSelfTest' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetRecorderStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetRecorderStatus.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetRecorderStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetRecorderDiskStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetRecorderDiskStatus.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetRecorderDiskStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_BreakRecorderCommand.restype = ct.c_uint  # type: ignore
        obj.ADQ_BreakRecorderCommand.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_BreakRecorderCommand' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SendRecorderCommand.restype = ct.c_uint  # type: ignore
        obj.ADQ_SendRecorderCommand.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SendRecorderCommand' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WriteDataToDSU.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteDataToDSU.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_ubyte),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteDataToDSU' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadDataFromDSU.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReadDataFromDSU.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_ubyte),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadDataFromDSU' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupDSUAcquisition.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetupDSUAcquisition.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupDSUAcquisition' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_StartDSUAcquisition.restype = ct.c_uint  # type: ignore
        obj.ADQ_StartDSUAcquisition.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_StartDSUAcquisition' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetNextDSURecordingAddress.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetNextDSURecordingAddress.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetNextDSURecordingAddress' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetPCIeLinkWidth.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPCIeLinkWidth' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetPCIeLinkRate.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPCIeLinkRate' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetPCIeTLPSize.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPCIeTLPSize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetExtTrigThreshold.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetExtTrigThreshold.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_double,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetExtTrigThreshold' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_Blink.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_Blink' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetInterleavingIPFrequencyCalibrationMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetInterleavingIPFrequencyCalibrationMode.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetInterleavingIPFrequencyCalibrationMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetInterleavingIPFrequencyCalibrationMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInterleavingIPFrequencyCalibrationMode.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInterleavingIPFrequencyCalibrationMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WriteUserRegister.restype = ct.c_int  # type: ignore
        obj.ADQ_WriteUserRegister.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_uint32,
            ct.c_uint32,
            ct.c_uint32,
            ct.POINTER(ct.c_uint32),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteUserRegister' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadUserRegister.restype = ct.c_int  # type: ignore
        obj.ADQ_ReadUserRegister.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_uint32,
            ct.POINTER(ct.c_uint32),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadUserRegister' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteBlockUserRegister.restype = ct.c_int  # type: ignore
        obj.ADQ_WriteBlockUserRegister.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_uint32,
            ct.POINTER(ct.c_uint32),
            ct.c_uint32,
            ct.c_uint32,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WriteBlockUserRegister' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ReadBlockUserRegister.restype = ct.c_int  # type: ignore
        obj.ADQ_ReadBlockUserRegister.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_uint32,
            ct.POINTER(ct.c_uint32),
            ct.c_uint32,
            ct.c_uint32,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ReadBlockUserRegister' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_BypassUserLogic.restype = ct.c_uint  # type: ignore
        obj.ADQ_BypassUserLogic.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_BypassUserLogic' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_EnableUseOfUserHeaders.restype = ct.c_uint  # type: ignore
        obj.ADQ_EnableUseOfUserHeaders.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableUseOfUserHeaders' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetUserLogicFilter.restype = ct.c_int  # type: ignore
        obj.ADQ_SetUserLogicFilter.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_void_p,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetUserLogicFilter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnableUserLogicFilter.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableUserLogicFilter.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableUserLogicFilter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ResetUserLogicFilter.restype = ct.c_int  # type: ignore
        obj.ADQ_ResetUserLogicFilter.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ResetUserLogicFilter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetProductFamily.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetProductFamily.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetProductFamily' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetHardwareAssemblyPartNumber.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetHardwareAssemblyPartNumber.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetHardwareAssemblyPartNumber' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetHardwareSubassemblyPartNumber.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetHardwareSubassemblyPartNumber.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetHardwareSubassemblyPartNumber' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetPCBAssemblyPartNumber.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetPCBAssemblyPartNumber.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetPCBAssemblyPartNumber' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetPCBPartNumber.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetPCBPartNumber.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPCBPartNumber' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetFPGApart.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetFPGApart.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetFPGApart' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetFPGATempGrade.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetFPGATempGrade.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetFPGATempGrade' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetFPGASpeedGrade.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetFPGASpeedGrade.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetFPGASpeedGrade' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetBiasDACPercentage.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetBiasDACPercentage.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_float,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetBiasDACPercentage' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupLevelTrigger.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetupLevelTrigger.argtypes = [  # type: ignore
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_int),
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupLevelTrigger' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetLevelTriggerSequenceLength.restype = ct.c_int  # type: ignore
        obj.ADQ_SetLevelTriggerSequenceLength.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetLevelTriggerSequenceLength' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnableLevelTriggerLogicOr.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableLevelTriggerLogicOr.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableLevelTriggerLogicOr' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetRxFifoOverflow.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetRxFifoOverflow' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_HasTriggeredStreamingFunctionality.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_HasTriggeredStreamingFunctionality' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingSetup.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingSetup.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingSetup' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingSetupGatedAcq.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingSetupGatedAcq.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingSetupGatedAcq' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ContinuousStreamingSetup.restype = ct.c_uint  # type: ignore
        obj.ADQ_ContinuousStreamingSetup.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ContinuousStreamingSetup' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTriggeredStreamingTotalNofRecords.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetTriggeredStreamingTotalNofRecords.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTriggeredStreamingTotalNofRecords' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTriggeredStreamingRecordSizeBytes.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTriggeredStreamingRecordSizeBytes' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTriggeredStreamingHeaderSizeBytes.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTriggeredStreamingHeaderSizeBytes' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTriggeredStreamingRecords.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetTriggeredStreamingRecords.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_void_p),
            ct.c_void_p,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTriggeredStreamingRecords' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingGetNofRecordsCompleted.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingGetNofRecordsCompleted.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingGetNofRecordsCompleted' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingGetStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_TriggeredStreamingGetStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingGetStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTriggeredStreamingHeaderRegister.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetTriggeredStreamingHeaderRegister.argtypes = [  # type: ignore
            ct.c_char,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTriggeredStreamingHeaderRegister' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTriggeredStreamingHeaderSerial.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetTriggeredStreamingHeaderSerial.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTriggeredStreamingHeaderSerial' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingArm.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingArm' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TriggeredStreamingDisarm.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TriggeredStreamingDisarm' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ParseTriggeredStreamingHeader.restype = ct.c_uint  # type: ignore
        obj.ADQ_ParseTriggeredStreamingHeader.argtypes = [  # type: ignore
            ct.c_void_p,
            ct.POINTER(ct.c_ulonglong),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ParseTriggeredStreamingHeader' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_HasAdjustableInputRange.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_HasAdjustableInputRange' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_HasGPIOHardware.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_HasGPIOHardware' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetInputRange.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInputRange.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_float,
            ct.POINTER(ct.c_float),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetInputRange' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetAdjustableBias.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetAdjustableBias.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetAdjustableBias' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteADQATTStateManual.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteADQATTStateManual.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WriteADQATTStateManual' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetAdjustableBias.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetAdjustableBias.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_int),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetAdjustableBias' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetInputRange.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetInputRange.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_float),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetInputRange' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetRecorderBytesPerAddress.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetRecorderBytesPerAddress' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetFanControl.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetFanControl.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetFanControl' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PowerStandby.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PowerStandby' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ADCReg.restype = ct.c_int  # type: ignore
        obj.ADQ_ADCReg.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ADCReg' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupDBS.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetupDBS.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_uint,
            ct.c_int,
            ct.c_int,
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupDBS' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_EnableWFATriggerCounter.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableWFATriggerCounter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DisableWFATriggerCounter.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DisableWFATriggerCounter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_StartWFATriggerCounter.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_StartWFATriggerCounter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetWFANumberOfTriggers.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetWFANumberOfTriggers.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetWFANumberOfTriggers' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_MeasureInputOffset.restype = ct.c_uint  # type: ignore
        obj.ADQ_MeasureInputOffset.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_int),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_MeasureInputOffset' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetOffsetCompensationDAC.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetOffsetCompensationDAC.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetOffsetCompensationDAC' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_RunCalibrationADQ412DC.restype = ct.c_uint  # type: ignore
        obj.ADQ_RunCalibrationADQ412DC.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_RunCalibrationADQ412DC' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ResetCalibrationStateADQ412DC.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ResetCalibrationStateADQ412DC' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DisconnectInputs.restype = ct.c_uint  # type: ignore
        obj.ADQ_DisconnectInputs.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DisconnectInputs' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetFrequency.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetFrequency.argtypes = [  # type: ignore
            ct.c_ulonglong,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetFrequency' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetRfAmplifier.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetRfAmplifier.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetRfAmplifier' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetRfPath.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetRfPath.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetRfPath' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetLoOut.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetLoOut.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetLoOut' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetRfAttenuation.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetRfAttenuation.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_RxSetRfAttenuation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_RxSetRfFilter.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetRfFilter.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetRfFilter' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetLoFilter.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetLoFilter.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetLoFilter' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetIfGainDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetIfGainDac.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetIfGainDac' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetVcomDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetVcomDac.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ushort,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetVcomDac' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetDcOffsetDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetDcOffsetDac.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ushort,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetDcOffsetDac' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RxSetLinearityDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_RxSetLinearityDac.argtypes = [  # type: ignore
            ct.c_ushort,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_RxSetLinearityDac' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TxSetFrequency.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetFrequency.argtypes = [  # type: ignore
            ct.c_ulonglong,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TxSetFrequency' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TxSetRfAmplifier.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetRfAmplifier.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TxSetRfAmplifier' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TxSetRfPath.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetRfPath.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TxSetRfPath' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TxSetLoOut.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetLoOut.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TxSetLoOut' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TxSetRfAttenuation.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetRfAttenuation.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_TxSetRfAttenuation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_TxSetRfFilter.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetRfFilter.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TxSetRfFilter' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TxSetLoFilter.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetLoFilter.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TxSetLoFilter' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TxSetDcOffsetDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetDcOffsetDac.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ushort,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TxSetDcOffsetDac' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TxSetLinearityDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_TxSetLinearityDac.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ushort,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TxSetLinearityDac' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SynthSetDeviceStandby.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthSetDeviceStandby.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SynthSetDeviceStandby' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SynthSetFrequency.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthSetFrequency.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ulonglong,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SynthSetFrequency' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SynthSetPowerLevel.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthSetPowerLevel.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_float,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SynthSetPowerLevel' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SynthSetRfOutput.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthSetRfOutput.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SynthSetRfOutput' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SynthSetAlcMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthSetAlcMode.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SynthSetAlcMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SynthDisableAutoLevel.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthDisableAutoLevel.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SynthDisableAutoLevel' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SynthSetClockReference.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthSetClockReference.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SynthSetClockReference' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SynthSetReferenceDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthSetReferenceDac.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SynthSetReferenceDac' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SynthSetAlcDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthSetAlcDac.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SynthSetAlcDac' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SynthGetAlcDac.restype = ct.c_uint  # type: ignore
        obj.ADQ_SynthGetAlcDac.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SynthGetAlcDac' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDeviceStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetDeviceStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDeviceStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetData.restype = ct.c_int  # type: ignore
        obj.ADQ_GetData.argtypes = [  # type: ignore
            ct.POINTER(ct.c_void_p),
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetData' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDataWH.restype = ct.c_int  # type: ignore
        obj.ADQ_GetDataWH.argtypes = [  # type: ignore
            ct.POINTER(ct.c_void_p),
            ct.c_void_p,
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDataWH' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDataWHTS.restype = ct.c_int  # type: ignore
        obj.ADQ_GetDataWHTS.argtypes = [  # type: ignore
            ct.POINTER(ct.c_void_p),
            ct.c_void_p,
            ct.c_void_p,
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDataWHTS' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDataStreaming.restype = ct.c_int  # type: ignore
        obj.ADQ_GetDataStreaming.argtypes = [  # type: ignore
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_void_p),
            ct.c_ubyte,
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDataStreaming' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PlotAssist.restype = ct.c_uint  # type: ignore
        obj.ADQ_PlotAssist.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
            ct.c_void_p,
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PlotAssist' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetLastError.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetLastError' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetPtrStream.restype = ct.c_void_p  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPtrStream' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetErrorVector.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetErrorVector' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsAlive.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsAlive' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadEEPROMDB.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReadEEPROMDB.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadEEPROMDB' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadEEPROM.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReadEEPROM.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadEEPROM' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ResetDevice.restype = ct.c_uint  # type: ignore
        obj.ADQ_ResetDevice.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ResetDevice' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_InvalidateCache.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_InvalidateCache' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetCacheSize.restype = ct.c_int  # type: ignore
        obj.ADQ_SetCacheSize.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetCacheSize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTransferBuffers.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTransferBuffers.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTransferBuffers' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaitForTransferBuffer.restype = ct.c_uint  # type: ignore
        obj.ADQ_WaitForTransferBuffer.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaitForTransferBuffer' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTransferBufferStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetTransferBufferStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTransferBufferStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_FlushDMA.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_FlushDMA' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTimeoutFlush.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetTimeoutFlush.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTimeoutFlush' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetFlushDMASize.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetFlushDMASize.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetFlushDMASize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteEEPROM.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteEEPROM.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteEEPROM' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteEEPROMDB.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteEEPROMDB.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteEEPROMDB' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ParseEEPROMBlock.restype = ct.c_int  # type: ignore
        obj.ADQ_ParseEEPROMBlock.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
            ct.POINTER(ct.c_char),
            ct.c_uint,
            ct.POINTER(ct.c_ubyte),
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ParseEEPROMBlock' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetDelayLineValues.restype = ct.c_int  # type: ignore
        obj.ADQ_SetDelayLineValues.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetDelayLineValues' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetDelayLineValuesDirect.restype = ct.c_int  # type: ignore
        obj.ADQ_SetDelayLineValuesDirect.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetDelayLineValuesDirect' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetLvlTrigLevel.restype = ct.c_int  # type: ignore
        obj.ADQ_SetLvlTrigLevel.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetLvlTrigLevel' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetLvlTrigEdge.restype = ct.c_int  # type: ignore
        obj.ADQ_SetLvlTrigEdge.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetLvlTrigEdge' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetClockSource.restype = ct.c_int  # type: ignore
        obj.ADQ_SetClockSource.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetClockSource' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetExternalReferenceFrequency.restype = ct.c_int  # type: ignore
        obj.ADQ_SetExternalReferenceFrequency.argtypes = [  # type: ignore
            ct.c_float,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetExternalReferenceFrequency' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetClockFrequencyMode.restype = ct.c_int  # type: ignore
        obj.ADQ_SetClockFrequencyMode.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetClockFrequencyMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetPllFreqDivider.restype = ct.c_int  # type: ignore
        obj.ADQ_SetPllFreqDivider.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetPllFreqDivider' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetPll.restype = ct.c_int  # type: ignore
        obj.ADQ_SetPll.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_int,
            ct.c_int,
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetPll' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTriggerMode.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTriggerMode.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTriggerMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetAuxTriggerMode.restype = ct.c_int  # type: ignore
        obj.ADQ_SetAuxTriggerMode.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetAuxTriggerMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetPreTrigSamples.restype = ct.c_int  # type: ignore
        obj.ADQ_SetPreTrigSamples.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetPreTrigSamples' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTriggerDelay.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTriggerDelay.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTriggerDelay' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTriggerHoldOffSamples.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTriggerHoldOffSamples.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTriggerHoldOffSamples' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetBufferSizePages.restype = ct.c_int  # type: ignore
        obj.ADQ_SetBufferSizePages.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetBufferSizePages' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetBufferSizeWords.restype = ct.c_int  # type: ignore
        obj.ADQ_SetBufferSizeWords.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetBufferSizeWords' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetBufferSize.restype = ct.c_int  # type: ignore
        obj.ADQ_SetBufferSize.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetBufferSize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetNofBits.restype = ct.c_int  # type: ignore
        obj.ADQ_SetNofBits.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetNofBits' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetSampleWidth.restype = ct.c_int  # type: ignore
        obj.ADQ_SetSampleWidth.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetSampleWidth' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetWordsPerPage.restype = ct.c_int  # type: ignore
        obj.ADQ_SetWordsPerPage.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetWordsPerPage' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetPreTrigWords.restype = ct.c_int  # type: ignore
        obj.ADQ_SetPreTrigWords.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetPreTrigWords' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetWordsAfterTrig.restype = ct.c_int  # type: ignore
        obj.ADQ_SetWordsAfterTrig.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetWordsAfterTrig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTrigLevelResetValue.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigLevelResetValue.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTrigLevelResetValue' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTrigMask1.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigMask1.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTrigMask1' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTrigLevel1.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigLevel1.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTrigLevel1' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTrigPreLevel1.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigPreLevel1.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTrigPreLevel1' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTrigCompareMask1.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigCompareMask1.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTrigCompareMask1' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTrigMask2.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigMask2.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTrigMask2' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTrigLevel2.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigLevel2.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTrigLevel2' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTrigPreLevel2.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigPreLevel2.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTrigPreLevel2' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTrigCompareMask2.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigCompareMask2.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTrigCompareMask2' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetFixedShiftValue.restype = ct.c_int  # type: ignore
        obj.ADQ_SetFixedShiftValue.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetFixedShiftValue' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnableFixedShift.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableFixedShift.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_EnableFixedShift' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetExternTrigEdge.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetExternTrigEdge.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetExternTrigEdge' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetSTARBTrigEdge.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetSTARBTrigEdge.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetSTARBTrigEdge' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetExternTrigEdge.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetExternTrigEdge.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetExternTrigEdge' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetExternalTriggerDelay.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetExternalTriggerDelay.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetExternalTriggerDelay' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetSyncTriggerDelay.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetSyncTriggerDelay.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetSyncTriggerDelay' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ArmTrigger.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ArmTrigger' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DisarmTrigger.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DisarmTrigger' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_StartStreaming.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_StartStreaming' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_StopStreaming.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_StopStreaming' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SWTrig.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SWTrig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_FlushPacketOnRecordStop.restype = ct.c_int  # type: ignore
        obj.ADQ_FlushPacketOnRecordStop.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_FlushPacketOnRecordStop' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_CollectDataNextPage.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_CollectDataNextPage' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_CollectDataNextPageWithPrefetch.restype = ct.c_int  # type: ignore
        obj.ADQ_CollectDataNextPageWithPrefetch.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_CollectDataNextPageWithPrefetch' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetWaitingForTrigger.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetWaitingForTrigger' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetAcquired.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetAcquired' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTrigged.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTrigged' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetAcquiredRecords.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetAcquiredRecords' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetAcquiredRecordsAndLoopCounter.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetAcquiredRecordsAndLoopCounter.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetAcquiredRecordsAndLoopCounter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetPageCount.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPageCount' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetLvlTrigLevel.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetLvlTrigLevel' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetLvlTrigFlank.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetLvlTrigFlank' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetLvlTrigEdge.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetLvlTrigEdge' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetOutputWidth.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetOutputWidth' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetPllFreqDivider.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPllFreqDivider' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetClockSource.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetClockSource' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTriggerMode.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTriggerMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetBufferSizePages.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetBufferSizePages' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetBufferSize.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetBufferSize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetMaxBufferSize.restype = ct.c_ulonglong  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetMaxBufferSize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetMaxBufferSizePages.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetMaxBufferSizePages' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetSamplesPerPage.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetSamplesPerPage' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetUSBAddress.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetUSBAddress' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetPCIeAddress.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetPCIeAddress' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetEthernetAddress.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetEthernetAddress' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupEthernet.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupEthernet.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
            ct.POINTER(ct.c_char),
            ct.POINTER(ct.c_char),
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupEthernet' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetEthernetDMASpeed.restype = ct.c_int  # type: ignore
        obj.ADQ_SetEthernetDMASpeed.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetEthernetDMASpeed' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetBcdDevice.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetBcdDevice' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetStreamConfig.restype = ct.c_int  # type: ignore
        obj.ADQ_SetStreamConfig.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetStreamConfig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetStreamConfig.restype = ct.c_int  # type: ignore
        obj.ADQ_GetStreamConfig.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetStreamConfig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetStreamStatus.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetStreamStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetStreamStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_SetStreamStatus.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetStreamStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetStreamOverflow.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetStreamOverflow' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_GetStatus.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_void_p,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetCalibrationInformation.restype = ct.c_int  # type: ignore
        obj.ADQ_GetCalibrationInformation.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetCalibrationInformation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetRevision.restype = ct.POINTER(ct.c_int)  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetRevision' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTriggerInformation.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTriggerInformation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTrigPoint.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTrigPoint' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTrigType.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTrigType' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetOverflow.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetOverflow' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetRecordSize.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetRecordSize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetNofRecords.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetNofRecords' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsUSBDevice.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsUSBDevice' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsEthernetDevice.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsEthernetDevice' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsUSB3Device.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsUSB3Device' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsPCIeDevice.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsPCIeDevice' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsMTCADevice.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsMTCADevice' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsPCIeLiteDevice.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsPCIeLiteDevice' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsVirtualDevice.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsVirtualDevice' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SendProcessorCommand.restype = ct.c_uint  # type: ignore
        obj.ADQ_SendProcessorCommand.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SendProcessorCommand' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SendLongProcessorCommand.restype = ct.c_uint  # type: ignore
        obj.ADQ_SendLongProcessorCommand.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SendLongProcessorCommand' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WriteRegister.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteRegister.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteRegister' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadRegister.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReadRegister.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadRegister' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteAlgoRegister.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteAlgoRegister.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteAlgoRegister' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadAlgoRegister.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReadAlgoRegister.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadAlgoRegister' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteI2C.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteI2C.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteI2C' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteDBI2C.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteDBI2C.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteDBI2C' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadI2C.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReadI2C.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadI2C' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadDBI2C.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReadDBI2C.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadDBI2C' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteReadI2C.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteReadI2C.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteReadI2C' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTemperature.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetTemperature.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTemperature' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTemperatureFloat.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetTemperatureFloat.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_float),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTemperatureFloat' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetCurrentFloat.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetCurrentFloat.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_float),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetCurrentFloat' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetCurrentSensorName.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetCurrentSensorName.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetCurrentSensorName' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetNofCurrentSensors.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetNofCurrentSensors' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_MultiRecordSetup.restype = ct.c_uint  # type: ignore
        obj.ADQ_MultiRecordSetup.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_MultiRecordSetup' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_MultiRecordSetupGP.restype = ct.c_uint  # type: ignore
        obj.ADQ_MultiRecordSetupGP.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_MultiRecordSetupGP' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetMaxNofSamplesFromNofRecords.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetMaxNofSamplesFromNofRecords.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetMaxNofSamplesFromNofRecords' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetMaxNofRecordsFromNofSamples.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetMaxNofRecordsFromNofSamples.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetMaxNofRecordsFromNofSamples' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetDataMultiRecordSetup.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetDataMultiRecordSetup.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetDataMultiRecordSetup' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_MultiRecordClose.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_MultiRecordClose' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetAcquiredAll.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetAcquiredAll' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTriggedAll.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTriggedAll' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsStartedOK.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsStartedOK' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_MemoryDump.restype = ct.c_uint  # type: ignore
        obj.ADQ_MemoryDump.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_ubyte),
            ct.POINTER(ct.c_uint),
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_MemoryDump' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_MemoryDumpRecords.restype = ct.c_uint  # type: ignore
        obj.ADQ_MemoryDumpRecords.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_ubyte),
            ct.POINTER(ct.c_uint),
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_MemoryDumpRecords' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_MemoryShadow.restype = ct.c_uint  # type: ignore
        obj.ADQ_MemoryShadow.argtypes = [  # type: ignore
            ct.c_void_p,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_MemoryShadow' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDataFormat.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDataFormat' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTestPatternMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetTestPatternMode.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTestPatternMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupTestPatternPulseGenerator.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupTestPatternPulseGenerator.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
            ct.c_int,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupTestPatternPulseGenerator' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnableTestPatternPulseGenerator.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableTestPatternPulseGenerator.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableTestPatternPulseGenerator' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupTestPatternPulseGeneratorPRBS.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupTestPatternPulseGeneratorPRBS.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_int,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupTestPatternPulseGeneratorPRBS' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnableTestPatternPulseGeneratorOutput.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableTestPatternPulseGeneratorOutput.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableTestPatternPulseGeneratorOutput' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTestPatternConstant.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetTestPatternConstant.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTestPatternConstant' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetDirectionTrig.restype = ct.c_int  # type: ignore
        obj.ADQ_SetDirectionTrig.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetDirectionTrig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteTrig.restype = ct.c_int  # type: ignore
        obj.ADQ_WriteTrig.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteTrig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetConfigurationTrig.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetConfigurationTrig.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetConfigurationTrig' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupTriggerOutput.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetupTriggerOutput.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupTriggerOutput' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTriggerGate.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetTriggerGate.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTriggerGate' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetInternalTriggerSyncMode.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInternalTriggerSyncMode.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInternalTriggerSyncMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnableInternalTriggerCounts.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableInternalTriggerCounts' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DisableInternalTriggerCounts.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DisableInternalTriggerCounts' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ClearInternalTriggerCounts.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ClearInternalTriggerCounts' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetInternalTriggerCounts.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInternalTriggerCounts.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInternalTriggerCounts' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ConfigureDebugCounter.restype = ct.c_uint  # type: ignore
        obj.ADQ_ConfigureDebugCounter.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ConfigureDebugCounter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetDirectionGPIO.restype = ct.c_int  # type: ignore
        obj.ADQ_SetDirectionGPIO.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetDirectionGPIO' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteGPIO.restype = ct.c_int  # type: ignore
        obj.ADQ_WriteGPIO.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteGPIO' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadGPIO.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadGPIO' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetMultiRecordHeader.restype = ct.POINTER(ct.c_uint)  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetMultiRecordHeader' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTrigTime.restype = ct.c_ulonglong  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTrigTime' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTrigTimeCycles.restype = ct.c_ulonglong  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTrigTimeCycles' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTrigTimeSyncs.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTrigTimeSyncs' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTrigTimeStart.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTrigTimeStart' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTrigTimeMode.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTrigTimeMode.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTrigTimeMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ResetTrigTimer.restype = ct.c_int  # type: ignore
        obj.ADQ_ResetTrigTimer.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ResetTrigTimer' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ra.restype = ct.c_uint  # type: ignore
        obj.ADQ_ra.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ra' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_RegisterNameLookup.restype = ct.c_uint  # type: ignore
        obj.ADQ_RegisterNameLookup.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
            ct.POINTER(ct.c_uint),
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_RegisterNameLookup' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SpiSend.restype = ct.c_int  # type: ignore
        obj.ADQ_SpiSend.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.POINTER(ct.c_char),
            ct.c_ubyte,
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SpiSend' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetExternalClockReferenceStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetExternalClockReferenceStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetExternalClockReferenceStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTransferTimeout.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetTransferTimeout.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTransferTimeout' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTransferTimeout.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetTransferTimeout.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTransferTimeout' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_StorePCIeConfig.restype = ct.c_uint  # type: ignore
        obj.ADQ_StorePCIeConfig.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_StorePCIeConfig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReloadPCIeConfig.restype = ct.c_uint  # type: ignore
        obj.ADQ_ReloadPCIeConfig.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReloadPCIeConfig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetADQDSPOption.restype = ct.POINTER(ct.c_char)  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetADQDSPOption' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetEthernetPllFreq.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetEthernetPllFreq.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetEthernetPllFreq' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetPointToPointPllFreq.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetPointToPointPllFreq.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetPointToPointPllFreq' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetEthernetPll.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetEthernetPll.argtypes = [  # type: ignore
            ct.c_ushort,
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_ushort,
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetEthernetPll' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetPointToPointPll.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetPointToPointPll.argtypes = [  # type: ignore
            ct.c_ushort,
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_ushort,
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_ubyte,
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetPointToPointPll' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetDirectionMLVDS.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetDirectionMLVDS.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetDirectionMLVDS' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetDirectionPXI.restype = ct.c_int  # type: ignore
        obj.ADQ_SetDirectionPXI.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetDirectionPXI' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetNGCPartNumber.restype = ct.POINTER(ct.c_char)  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetNGCPartNumber' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetUserLogicPartNumber.restype = ct.POINTER(ct.c_char)  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetUserLogicPartNumber' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetProductVariant.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetProductVariant.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetProductVariant' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetInternalTriggerPeriod.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetInternalTriggerPeriod.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInternalTriggerPeriod' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetInternalTriggerHighLow.restype = ct.c_int  # type: ignore
        obj.ADQ_SetInternalTriggerHighLow.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetInternalTriggerHighLow' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_FX2ReadRequest.restype = ct.c_uint  # type: ignore
        obj.ADQ_FX2ReadRequest.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_long,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_FX2ReadRequest' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_FX2WriteRequest.restype = ct.c_uint  # type: ignore
        obj.ADQ_FX2WriteRequest.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_long,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_FX2WriteRequest' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_FX2SetRetryLimit.restype = ct.c_uint  # type: ignore
        obj.ADQ_FX2SetRetryLimit.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_FX2SetRetryLimit' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetUSBFWVersion.restype = ct.c_int  # type: ignore
        obj.ADQ_GetUSBFWVersion.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetUSBFWVersion' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetProductID.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetProductID' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_BootAdqFromFlash.restype = ct.c_uint  # type: ignore
        obj.ADQ_BootAdqFromFlash.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_BootAdqFromFlash' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_IsBootloader.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_IsBootloader' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_TrigoutEnable.restype = ct.c_uint  # type: ignore
        obj.ADQ_TrigoutEnable.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_TrigoutEnable' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_HasTrigHardware.restype = ct.c_uint  # type: ignore
        obj.ADQ_HasTrigHardware.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_HasTrigHardware' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_HasTrigoutHardware.restype = ct.c_uint  # type: ignore
        obj.ADQ_HasTrigoutHardware.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_HasTrigoutHardware' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_HasVariableTrigThreshold.restype = ct.c_uint  # type: ignore
        obj.ADQ_HasVariableTrigThreshold.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_HasVariableTrigThreshold' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WriteToDataEP.restype = ct.c_uint  # type: ignore
        obj.ADQ_WriteToDataEP.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteToDataEP' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SendDataDev2Dev.restype = ct.c_uint  # type: ignore
        obj.ADQ_SendDataDev2Dev.argtypes = [  # type: ignore
            ct.c_ulong,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SendDataDev2Dev' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupDMADev2GPUDGMA.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetupDMADev2GPUDGMA.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_ulonglong),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupDMADev2GPUDGMA' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupDMADev2GPUDDMA.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetupDMADev2GPUDDMA.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_ulonglong),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupDMADev2GPUDDMA' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupDMAP2p2D.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetupDMAP2p2D.argtypes = [  # type: ignore
            ct.POINTER(ct.c_ulonglong),
            ct.POINTER(ct.c_ulonglong),
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_void_p,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupDMAP2p2D' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WaitforGPUMarker.restype = ct.c_uint  # type: ignore
        obj.ADQ_WaitforGPUMarker.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WaitforGPUMarker' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetP2pStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetP2pStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetP2pStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetP2pSize.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetP2pSize.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetP2pSize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetP2pSize.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetP2pSize.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetP2pSize' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetUserTransferBuffers.restype = ct.c_int  # type: ignore
        obj.ADQ_SetUserTransferBuffers.argtypes = [  # type: ignore
            ct.c_uint32,
            ct.c_size_t,
            ct.POINTER(ct.c_uint64),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetUserTransferBuffers' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_HasAdjustableBias.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_HasAdjustableBias' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetUSB3Config.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetUSB3Config.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetUSB3Config' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetUSB3Config.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetUSB3Config.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetUSB3Config' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetDMATest.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetDMATest.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetDMATest' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetCalibratedInputImpedance.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetCalibratedInputImpedance.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_float),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetCalibratedInputImpedance' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetNofBytesPerSample.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetNofBytesPerSample.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetNofBytesPerSample' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetNofDBSInstances.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetNofDBSInstances.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetNofDBSInstances' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetCalibrationModeADQ412DC.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetCalibrationModeADQ412DC.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetCalibrationModeADQ412DC' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetFPGARebootMethod.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetFPGARebootMethod.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetFPGARebootMethod' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetNofRecorderIP.restype = ct.c_uint  # type: ignore
        obj.ADQ_GetNofRecorderIP.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetNofRecorderIP' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetOvervoltageProtection.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetOvervoltageProtection.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetOvervoltageProtection' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetADCClockDelay.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetADCClockDelay.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_float,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetADCClockDelay' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetAttenuators.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetAttenuators.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetAttenuators' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ATDGetWFAStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDGetWFAStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ATDGetWFAStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ATDStartWFA.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDStartWFA.argtypes = [  # type: ignore
            ct.POINTER(ct.c_void_p),
            ct.c_ubyte,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ATDStartWFA' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ATDStopWFA.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ATDStopWFA' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ATDFlushWFA.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ATDFlushWFA' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ATDWaitForWFACompletion.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDWaitForWFACompletion' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDWaitForWFABuffer.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDWaitForWFABuffer.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_void_p),
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDWaitForWFABuffer' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDRegisterWFABuffer.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDRegisterWFABuffer.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_void_p,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDRegisterWFABuffer' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDSetupWFAAdvanced.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDSetupWFAAdvanced.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDSetupWFAAdvanced' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDSetupWFA.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDSetupWFA.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ATDSetupWFA' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ATDSetupThreshold.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDSetupThreshold.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
            ct.c_int,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ATDSetupThreshold' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ATDSetThresholdFilter.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDSetThresholdFilter.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDSetThresholdFilter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDSetupTestPattern.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDSetupTestPattern.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDSetupTestPattern' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDEnableTestPattern.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDEnableTestPattern.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDEnableTestPattern' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDGetAdjustedRecordLength.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDGetAdjustedRecordLength.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDGetAdjustedRecordLength' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDGetDeviceNofAccumulations.restype = ct.c_uint  # type: ignore
        obj.ADQ_ATDGetDeviceNofAccumulations.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDGetDeviceNofAccumulations' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDUpdateNofAccumulations.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDUpdateNofAccumulations.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDUpdateNofAccumulations' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDGetWFAPartitionBoundaries.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDGetWFAPartitionBoundaries.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDGetWFAPartitionBoundaries' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDSetWFAPartitionBoundaries.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDSetWFAPartitionBoundaries.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDSetWFAPartitionBoundaries' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDSetWFAPartitionBoundariesDefault.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDSetWFAPartitionBoundariesDefault' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDSetWFAInternalTimeout.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDSetWFAInternalTimeout.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDSetWFAInternalTimeout' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDEnableAccumulationGridSync.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDEnableAccumulationGridSync.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDEnableAccumulationGridSync' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ATDSetWFABufferFormat.restype = ct.c_int  # type: ignore
        obj.ADQ_ATDSetWFABufferFormat.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ATDSetWFABufferFormat' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupBlockAvg.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupBlockAvg.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupBlockAvg' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_EnableRecordSegmenter.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableRecordSegmenter.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableRecordSegmenter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupRecordSegmenter.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupRecordSegmenter.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupRecordSegmenter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupInternal000.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupInternal000.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
            ct.c_int,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal000' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ArmInternal001.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ArmInternal001' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DisarmInternal002.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DisarmInternal002' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WriteInternal003.restype = ct.c_int  # type: ignore
        obj.ADQ_WriteInternal003.argtypes = [  # type: ignore
            ct.c_void_p,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteInternal003' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupInternal004.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupInternal004.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal004' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupInternal005.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupInternal005.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal005' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupInternal006.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupInternal006.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal006' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupInternal007.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupInternal007.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal007' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupInternal008.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupInternal008.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal008' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupInternal009.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupInternal009.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal009' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupInternal010.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupInternal010.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal010' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupInternal011.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetupInternal011.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupInternal011' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadInternal000.restype = ct.c_int  # type: ignore
        obj.ADQ_ReadInternal000.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadInternal000' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetDNA.restype = ct.c_int  # type: ignore
        obj.ADQ_GetDNA.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDNA' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ResetDNA.restype = ct.c_int  # type: ignore
        obj.ADQ_ResetDNA.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ResetDNA' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDSetupStreaming.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupStreaming.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDSetupStreaming' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDSetupLevelTrig.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupLevelTrig.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
            ct.c_int,
            ct.c_int,
            ct.c_int,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDSetupLevelTrig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDEnableLevelTrig.restype = ct.c_int  # type: ignore
        obj.ADQ_PDEnableLevelTrig.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDEnableLevelTrig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDGetLevelTrigStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_PDGetLevelTrigStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDGetLevelTrigStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDSetupTiming.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupTiming.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDSetupTiming' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDSetupTriggerCoincidence2.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupTriggerCoincidence2.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDSetupTriggerCoincidence2' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDSetupTriggerCoincidenceCore.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupTriggerCoincidenceCore.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_ubyte),
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDSetupTriggerCoincidenceCore' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDSetupTriggerCoincidence.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupTriggerCoincidence.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDSetupTriggerCoincidence' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDResetTriggerCoincidence.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDResetTriggerCoincidence' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDEnableTriggerCoincidence.restype = ct.c_int  # type: ignore
        obj.ADQ_PDEnableTriggerCoincidence.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDEnableTriggerCoincidence' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDSetupMovingAverageBypass.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupMovingAverageBypass.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDSetupMovingAverageBypass' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDSetupHistogram.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupHistogram.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDSetupHistogram' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDReadHistogram.restype = ct.c_int  # type: ignore
        obj.ADQ_PDReadHistogram.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDReadHistogram' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDGetHistogramStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_PDGetHistogramStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDGetHistogramStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDClearHistogram.restype = ct.c_int  # type: ignore
        obj.ADQ_PDClearHistogram.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDClearHistogram' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDSetDataMux.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetDataMux.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDSetDataMux' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDSetupCharacterization.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetupCharacterization.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDSetupCharacterization' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDGetCharacterizationStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_PDGetCharacterizationStatus.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDGetCharacterizationStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDGetEventCounters.restype = ct.c_int  # type: ignore
        obj.ADQ_PDGetEventCounters.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDGetEventCounters' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_PDAutoTrig.restype = ct.c_int  # type: ignore
        obj.ADQ_PDAutoTrig.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDAutoTrig' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDGetGeneration.restype = ct.c_int  # type: ignore
        obj.ADQ_PDGetGeneration.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_PDGetGeneration' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_PDSetMinimumFrameLength.restype = ct.c_int  # type: ignore
        obj.ADQ_PDSetMinimumFrameLength.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_PDSetMinimumFrameLength' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_HasFeature.restype = ct.c_int  # type: ignore
        obj.ADQ_HasFeature.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_HasFeature' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetSWTrigValue.restype = ct.c_int  # type: ignore
        obj.ADQ_SetSWTrigValue.argtypes = [  # type: ignore
            ct.c_float,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetSWTrigValue' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetDACPercentage.restype = ct.c_uint  # type: ignore
        obj.ADQ_SetDACPercentage.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_float,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetDACPercentage' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_MultiRecordSetChannelMask.restype = ct.c_uint  # type: ignore
        obj.ADQ_MultiRecordSetChannelMask.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_MultiRecordSetChannelMask' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_USBReConnect.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_USBReConnect' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OCTDebug.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTDebug.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OCTDebug' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OCTResetOVP.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OCTResetOVP' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OCTSetOVPLevel.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTSetOVPLevel.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OCTSetOVPLevel' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OCTGetOVPLevel.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTGetOVPLevel.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OCTGetOVPLevel' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OCTGetOVPStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTGetOVPStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OCTGetOVPStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OCTSetTriggerCount.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTSetTriggerCount.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_OCTSetTriggerCount' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_OCTSetFFTLength.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTSetFFTLength.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OCTSetFFTLength' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OCTSetFFTEnable.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTSetFFTEnable.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OCTSetFFTEnable' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_OCTSetFFTEnableWin.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTSetFFTEnableWin.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_OCTSetFFTEnableWin' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_OCTSetFFTHoldOff.restype = ct.c_int  # type: ignore
        obj.ADQ_OCTSetFFTHoldOff.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_OCTSetFFTHoldOff' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_EnableGPIOSupplyOutput.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableGPIOSupplyOutput.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_EnableGPIOSupplyOutput' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_USBLinkupTest.restype = ct.c_int  # type: ignore
        obj.ADQ_USBLinkupTest.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_USBLinkupTest' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetClockInputImpedance.restype = ct.c_int  # type: ignore
        obj.ADQ_SetClockInputImpedance.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetClockInputImpedance' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTriggerInputImpedance.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTriggerInputImpedance.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTriggerInputImpedance' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTriggerInputImpedance.restype = ct.c_int  # type: ignore
        obj.ADQ_GetTriggerInputImpedance.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTriggerInputImpedance' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_MeasureSupplyVoltage.restype = ct.c_int  # type: ignore
        obj.ADQ_MeasureSupplyVoltage.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_float),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_MeasureSupplyVoltage' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetWriteCount.restype = ct.c_int  # type: ignore
        obj.ADQ_GetWriteCount.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetWriteCount' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetWriteCountMax.restype = ct.c_int  # type: ignore
        obj.ADQ_GetWriteCountMax.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetWriteCountMax' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ResetWriteCountMax.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ResetWriteCountMax' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_EnableGPIOPort.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableGPIOPort.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_EnableGPIOPort' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetDirectionGPIOPort.restype = ct.c_int  # type: ignore
        obj.ADQ_SetDirectionGPIOPort.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetDirectionGPIOPort' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WriteGPIOPort.restype = ct.c_int  # type: ignore
        obj.ADQ_WriteGPIOPort.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WriteGPIOPort' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetFunctionGPIOPort.restype = ct.c_int  # type: ignore
        obj.ADQ_SetFunctionGPIOPort.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetFunctionGPIOPort' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupUserRangeGPIO.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupUserRangeGPIO.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupUserRangeGPIO' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ReadGPIOPort.restype = ct.c_int  # type: ignore
        obj.ADQ_ReadGPIOPort.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ReadGPIOPort' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SDCardInit.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SDCardInit' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SDCardErase.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardErase.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SDCardErase' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SDCardRead.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardRead.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SDCardRead' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SDCardWriterStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardWriterStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardWriterStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardBackupEnable.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardBackupEnable.argtypes = [  # type: ignore
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardBackupEnable' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardBackupGetConfiguration.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardBackupGetConfiguration.argtypes = [  # type: ignore
            ct.POINTER(_SDCardConfiguration),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardBackupGetConfiguration' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardBackupGetStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardBackupGetStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardBackupGetStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardBackupResetWriterProcess.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardBackupResetWriterProcess' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardBackupSetAdditionalData.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardBackupSetAdditionalData.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardBackupSetAdditionalData' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardGetNofSectors.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardGetNofSectors' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardIsInserted.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardIsInserted.argtypes = [  # type: ignore
            ct.POINTER(ct.c_int),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SDCardIsInserted' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SDCardBackupGetProgress.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardBackupGetProgress.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardBackupGetProgress' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardBackupGetData.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardBackupGetData.argtypes = [  # type: ignore
            ct.POINTER(ct.c_void_p),
            ct.c_void_p,
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
            ct.c_ubyte,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardBackupGetData' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SDCardBackupDaisyChainGetTriggerInformation.restype = ct.c_int  # type: ignore
        obj.ADQ_SDCardBackupDaisyChainGetTriggerInformation.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_int,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(_ADQDaisyChainDeviceInformation),
            ct.c_uint,
            ct.POINTER(_ADQDaisyChainTriggerInformation),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SDCardBackupDaisyChainGetTriggerInformation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupTimestampSync.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupTimestampSync.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupTimestampSync' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupTimestampSync2.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupTimestampSync2.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_int,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupTimestampSync2' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ArmTimestampSync.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ArmTimestampSync' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DisarmTimestampSync.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DisarmTimestampSync' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTimestampSyncSeed.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTimestampSyncSeed.argtypes = [  # type: ignore
            ct.c_uint64,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTimestampSyncSeed' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTimestampSyncState.restype = ct.c_int  # type: ignore
        obj.ADQ_GetTimestampSyncState.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTimestampSyncState' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTimestampSyncCount.restype = ct.c_int  # type: ignore
        obj.ADQ_GetTimestampSyncCount.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTimestampSyncCount' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ResetTimestamp.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ResetTimestamp' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTimestampValue.restype = ct.c_int  # type: ignore
        obj.ADQ_GetTimestampValue.argtypes = [  # type: ignore
            ct.POINTER(ct.c_ulonglong),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTimestampValue' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetExternalTimestamp.restype = ct.c_int  # type: ignore
        obj.ADQ_GetExternalTimestamp.argtypes = [  # type: ignore
            ct.POINTER(ct.c_ulonglong),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetExternalTimestamp' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupTriggerBlocking.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupTriggerBlocking.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint64,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetupTriggerBlocking' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ArmTriggerBlocking.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ArmTriggerBlocking' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DisarmTriggerBlocking.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DisarmTriggerBlocking' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetTriggerBlockingGateCount.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetTriggerBlockingGateCount' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTriggerEdge.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTriggerEdge.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTriggerEdge' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetTriggerEdge.restype = ct.c_int  # type: ignore
        obj.ADQ_GetTriggerEdge.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetTriggerEdge' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetTriggerMaskMLVDS.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTriggerMaskMLVDS.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTriggerMaskMLVDS' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTriggerMaskPXI.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTriggerMaskPXI.argtypes = [  # type: ignore
            ct.c_ubyte,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetTriggerMaskPXI' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ConfigureWfaDebugCounter.restype = ct.c_uint  # type: ignore
        obj.ADQ_ConfigureWfaDebugCounter.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ConfigureWfaDebugCounter' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WfaSetup.restype = ct.c_uint  # type: ignore
        obj.ADQ_WfaSetup.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WfaSetup' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WfaArm.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WfaArm' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WfaShutdown.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WfaShutdown' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WfaGetStatus.restype = ct.c_uint  # type: ignore
        obj.ADQ_WfaGetStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WfaGetStatus' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WfaGetWaveform.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WfaGetWaveform' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WfaDisarm.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WfaDisarm' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetMixerFrequency.restype = ct.c_int  # type: ignore
        obj.ADQ_SetMixerFrequency.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_double,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetMixerFrequency' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetMixerPhase.restype = ct.c_int  # type: ignore
        obj.ADQ_SetMixerPhase.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_double,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetMixerPhase' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetEqualizerSDR.restype = ct.c_int  # type: ignore
        obj.ADQ_SetEqualizerSDR.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_float),
            ct.POINTER(ct.c_float),
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetEqualizerSDR' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ForceResynchronizationSDR.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ForceResynchronizationSDR' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetCrosspointSDR.restype = ct.c_int  # type: ignore
        obj.ADQ_SetCrosspointSDR.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetCrosspointSDR' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetSampleRate.restype = ct.c_int  # type: ignore
        obj.ADQ_GetSampleRate.argtypes = [  # type: ignore
            ct.c_int,
            ct.POINTER(ct.c_double),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetSampleRate' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DebugParsePacketDataStreaming.restype = ct.c_int  # type: ignore
        obj.ADQ_DebugParsePacketDataStreaming.argtypes = [  # type: ignore
            ct.c_void_p,
            ct.c_uint,
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.c_ubyte,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DebugParsePacketDataStreaming' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DebugCmd.restype = ct.c_int  # type: ignore
        obj.ADQ_DebugCmd.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_float,
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DebugCmd' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetSystemManagerType.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetSystemManagerType' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetConManSPIVersion.restype = ct.c_int  # type: ignore
        obj.ADQ_GetConManSPIVersion.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetConManSPIVersion' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ConManSPI.restype = ct.c_int  # type: ignore
        obj.ADQ_ConManSPI.argtypes = [  # type: ignore
            ct.c_ubyte,
            ct.c_void_p,
            ct.c_uint,
            ct.c_void_p,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_ConManSPI' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_HasConManSPIFeature.restype = ct.c_int  # type: ignore
        obj.ADQ_HasConManSPIFeature.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_HasConManSPIFeature' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetDeviceSNConManSPI.restype = ct.c_int  # type: ignore
        obj.ADQ_GetDeviceSNConManSPI.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetDeviceSNConManSPI' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTriggerThresholdVoltage.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTriggerThresholdVoltage.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_double,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTriggerThresholdVoltage' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetGPVectorMode.restype = ct.c_int  # type: ignore
        obj.ADQ_SetGPVectorMode.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetGPVectorMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetGPVectorMode.restype = ct.c_int  # type: ignore
        obj.ADQ_GetGPVectorMode.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetGPVectorMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetDACNyquistBand.restype = ct.c_int  # type: ignore
        obj.ADQ_SetDACNyquistBand.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetDACNyquistBand' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupFrameSync.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupFrameSync.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupFrameSync' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_EnableFrameSync.restype = ct.c_int  # type: ignore
        obj.ADQ_EnableFrameSync.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_EnableFrameSync' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SendWrCommand.restype = ct.c_int  # type: ignore
        obj.ADQ_SendWrCommand.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SendWrCommand' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_ReadWrCommandRxBuffer.restype = ct.c_int  # type: ignore
        obj.ADQ_ReadWrCommandRxBuffer.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ReadWrCommandRxBuffer' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ClearWrCommandRxBuffer.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ClearWrCommandRxBuffer' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WrReadSpiFlash.restype = ct.c_int  # type: ignore
        obj.ADQ_WrReadSpiFlash.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WrReadSpiFlash' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WrWriteSpiFlash.restype = ct.c_int  # type: ignore
        obj.ADQ_WrWriteSpiFlash.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WrWriteSpiFlash' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WrWriteFileToLM32Mem.restype = ct.c_int  # type: ignore
        obj.ADQ_WrWriteFileToLM32Mem.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WrWriteFileToLM32Mem' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetDevAddress.restype = ct.c_uint  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetDevAddress' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetInputImpedance.restype = ct.c_int  # type: ignore
        obj.ADQ_SetInputImpedance.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetInputImpedance' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetInputImpedance.restype = ct.c_int  # type: ignore
        obj.ADQ_GetInputImpedance.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetInputImpedance' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DaisyChainSetMode.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainSetMode.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DaisyChainSetMode' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DaisyChainEnable.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainEnable.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DaisyChainEnable' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DaisyChainReset.restype = ct.c_int  # type: ignore
    except AttributeError:
        print("WARNING: Could not find 'ADQ_DaisyChainReset' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_DaisyChainSetupLevelTrigger.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainSetupLevelTrigger.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
            ct.c_int,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainSetupLevelTrigger' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DaisyChainSetupOutput.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainSetupOutput.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainSetupOutput' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DaisyChainSetOutputState.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainSetOutputState.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainSetOutputState' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DaisyChainGetInputState.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainGetInputState.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainGetInputState' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DaisyChainEnableOutput.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainEnableOutput.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainEnableOutput' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DaisyChainSetTriggerSource.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainSetTriggerSource.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainSetTriggerSource' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DaisyChainGetStatus.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainGetStatus.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainGetStatus' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DaisyChainGetNofPretriggerSamples.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainGetNofPretriggerSamples.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_int64,
            ct.POINTER(ct.c_int),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainGetNofPretriggerSamples' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_DaisyChainGetTriggerInformation.restype = ct.c_int  # type: ignore
        obj.ADQ_DaisyChainGetTriggerInformation.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_int,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.c_uint,
            ct.POINTER(_ADQDaisyChainDeviceInformation),
            ct.c_uint,
            ct.POINTER(_ADQDaisyChainTriggerInformation),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_DaisyChainGetTriggerInformation' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetClockReferenceDelayDAC.restype = ct.c_int  # type: ignore
        obj.ADQ_SetClockReferenceDelayDAC.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetClockReferenceDelayDAC' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetStreamErrors.restype = ct.c_int  # type: ignore
        obj.ADQ_GetStreamErrors.argtypes = [  # type: ignore
            ct.c_uint,
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetStreamErrors' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_AdjustClockReferenceDelay.restype = ct.c_int  # type: ignore
        obj.ADQ_AdjustClockReferenceDelay.argtypes = [  # type: ignore
            ct.c_float,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_AdjustClockReferenceDelay' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetChannelSampleSkip.restype = ct.c_int  # type: ignore
        obj.ADQ_SetChannelSampleSkip.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetChannelSampleSkip' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetChannelPretrigger.restype = ct.c_int  # type: ignore
        obj.ADQ_SetChannelPretrigger.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetChannelPretrigger' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetChannelTriggerDelay.restype = ct.c_int  # type: ignore
        obj.ADQ_SetChannelTriggerDelay.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetChannelTriggerDelay' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetChannelRecordLength.restype = ct.c_int  # type: ignore
        obj.ADQ_SetChannelRecordLength.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetChannelRecordLength' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetChannelNumberOfRecords.restype = ct.c_int  # type: ignore
        obj.ADQ_SetChannelNumberOfRecords.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetChannelNumberOfRecords' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetChannelLevelTriggerMask.restype = ct.c_int  # type: ignore
        obj.ADQ_SetChannelLevelTriggerMask.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetChannelLevelTriggerMask' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetChannelTriggerMode.restype = ct.c_int  # type: ignore
        obj.ADQ_SetChannelTriggerMode.argtypes = [  # type: ignore
            ct.c_uint,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetChannelTriggerMode' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetStreamingChannelMask.restype = ct.c_int  # type: ignore
        obj.ADQ_SetStreamingChannelMask.argtypes = [  # type: ignore
            ct.c_uint,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetStreamingChannelMask' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_InitializeStreaming.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_InitializeStreaming' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetADQDataDeviceStructSize.restype = ct.c_int  # type: ignore
        obj.ADQ_GetADQDataDeviceStructSize.argtypes = [  # type: ignore
            ct.POINTER(ct.c_uint),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetADQDataDeviceStructSize' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetADQDataDeviceStruct.restype = ct.c_int  # type: ignore
        obj.ADQ_GetADQDataDeviceStruct.argtypes = [  # type: ignore
            ct.c_void_p,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetADQDataDeviceStruct' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetTargetSampleRate.restype = ct.c_int  # type: ignore
        obj.ADQ_SetTargetSampleRate.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_double,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetTargetSampleRate' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SmTransaction.restype = ct.c_int  # type: ignore
        obj.ADQ_SmTransaction.argtypes = [  # type: ignore
            ct.c_uint16,
            ct.c_void_p,
            ct.c_size_t,
            ct.c_void_p,
            ct.c_size_t,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SmTransaction' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SmTransactionImmediate.restype = ct.c_int  # type: ignore
        obj.ADQ_SmTransactionImmediate.argtypes = [  # type: ignore
            ct.c_uint16,
            ct.c_void_p,
            ct.c_size_t,
            ct.c_void_p,
            ct.c_size_t,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SmTransactionImmediate' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_UnlockP2pBuffers.restype = ct.c_int  # type: ignore
        obj.ADQ_UnlockP2pBuffers.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_uint64,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_UnlockP2pBuffers' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_WaitForP2pBuffers.restype = ct.c_int  # type: ignore
        obj.ADQ_WaitForP2pBuffers.argtypes = [  # type: ignore
            ct.POINTER(_ADQP2pStatus),
            ct.c_int,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_WaitForP2pBuffers' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_StartDataAcquisition.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_StartDataAcquisition' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_StopDataAcquisition.restype = ct.c_int  # type: ignore
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_StopDataAcquisition' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_WaitForRecordBuffer.restype = ct.c_int64  # type: ignore
        obj.ADQ_WaitForRecordBuffer.argtypes = [  # type: ignore
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_void_p),
            ct.c_int,
            ct.POINTER(_ADQDataReadoutStatus),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_WaitForRecordBuffer' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ReturnRecordBuffer.restype = ct.c_int  # type: ignore
        obj.ADQ_ReturnRecordBuffer.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_void_p,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ReturnRecordBuffer' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetupEventSource.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupEventSource.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_void_p,
            ct.c_size_t,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupEventSource' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetupFunction.restype = ct.c_int  # type: ignore
        obj.ADQ_SetupFunction.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_void_p,
            ct.c_size_t,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetupFunction' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_InitializeParameters.restype = ct.c_int  # type: ignore
        obj.ADQ_InitializeParameters.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_void_p,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_InitializeParameters' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_InitializeParametersString.restype = ct.c_int  # type: ignore
        obj.ADQ_InitializeParametersString.argtypes = [  # type: ignore
            ct.c_int,
            ct.POINTER(ct.c_char),
            ct.c_size_t,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_InitializeParametersString' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_InitializeParametersFilename.restype = ct.c_int  # type: ignore
        obj.ADQ_InitializeParametersFilename.argtypes = [  # type: ignore
            ct.c_int,
            ct.POINTER(ct.c_char),
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_InitializeParametersFilename' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetParameters.restype = ct.c_int  # type: ignore
        obj.ADQ_GetParameters.argtypes = [  # type: ignore
            ct.c_int,
            ct.c_void_p,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_GetParameters' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_GetParametersString.restype = ct.c_int  # type: ignore
        obj.ADQ_GetParametersString.argtypes = [  # type: ignore
            ct.c_int,
            ct.POINTER(ct.c_char),
            ct.c_size_t,
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetParametersString' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_GetParametersFilename.restype = ct.c_int  # type: ignore
        obj.ADQ_GetParametersFilename.argtypes = [  # type: ignore
            ct.c_int,
            ct.POINTER(ct.c_char),
            ct.c_int,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_GetParametersFilename' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetParameters.restype = ct.c_int  # type: ignore
        obj.ADQ_SetParameters.argtypes = [  # type: ignore
            ct.c_void_p,
        ]
    except AttributeError:
        print("WARNING: Could not find 'ADQ_SetParameters' in ADQAPI.dll/libadq.so")

    try:
        obj.ADQ_SetParametersString.restype = ct.c_int  # type: ignore
        obj.ADQ_SetParametersString.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
            ct.c_size_t,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetParametersString' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_SetParametersFilename.restype = ct.c_int  # type: ignore
        obj.ADQ_SetParametersFilename.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_SetParametersFilename' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ValidateParameters.restype = ct.c_int  # type: ignore
        obj.ADQ_ValidateParameters.argtypes = [  # type: ignore
            ct.c_void_p,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ValidateParameters' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ValidateParametersString.restype = ct.c_int  # type: ignore
        obj.ADQ_ValidateParametersString.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
            ct.c_size_t,
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ValidateParametersString' in ADQAPI.dll/libadq.so"
        )

    try:
        obj.ADQ_ValidateParametersFilename.restype = ct.c_int  # type: ignore
        obj.ADQ_ValidateParametersFilename.argtypes = [  # type: ignore
            ct.POINTER(ct.c_char),
        ]
    except AttributeError:
        print(
            "WARNING: Could not find 'ADQ_ValidateParametersFilename' in ADQAPI.dll/libadq.so"
        )
