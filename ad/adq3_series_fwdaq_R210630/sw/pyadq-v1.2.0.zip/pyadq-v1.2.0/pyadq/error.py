from typing import Optional


class Error(Exception):
    """ADQ error.

    Raised by `ADQ`
    """

    pass


class ApiError(Error):
    """API error.

    Raised when libadq/ADQAPI calls fail.
    """

    def __init__(self, message: str, error_code: Optional[int] = None):
        super().__init__(message)
        self.error_code = error_code


class Timeout(Error):
    """Timeout.

    Raised when data collection times out.
    """

    pass


class WaitForRecordBufferStatus(Error):
    """Status.

    Raised when data collection
    """

    def __init__(self, status):
        super().__init__(f"Flags: {hex(status.flags)}")
        self.status = status


class RequestError(Exception):
    pass


class DeserializeError(Exception):
    pass


class ServerError(Error):
    pass
