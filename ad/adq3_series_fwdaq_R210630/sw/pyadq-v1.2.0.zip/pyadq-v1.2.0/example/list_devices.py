#!/usr/bin/env python3
# Copyright 2020 Teledyne Signal Processing Devices Sweden AB
"""
    This example will enumerate and initialize all devices and then exit
"""
import pyadq

print("pyadq version:", pyadq.__version__)

acu = pyadq.ADQControlUnit()

acu.ADQControlUnit_EnableErrorTrace(pyadq.LOG_LEVEL_INFO, ".")
device_list = acu.ListDevices()

print(f"Found {len(device_list)} device(s)")
for index in range(len(device_list)):
    with acu.SetupDevice(index) as dev:
        print(dev)
