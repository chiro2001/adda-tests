#!/usr/bin/env python3
# Copyright 2021 Teledyne Signal Processing Devices Sweden AB
"""
 Example illustrating the data collection for an ADQ7/ADQ8/ADQ14 digitizer. The
 first avilable device will be used.
"""
import pyadq
from typing import List

print("pyadq version:", pyadq.__version__)

# Create the control unit
acu: pyadq.ADQControlUnit = pyadq.ADQControlUnit()

# Enable trace logging
acu.ADQControlUnit_EnableErrorTrace(pyadq.LOG_LEVEL_INFO, ".")

# List the available devices
device_list: List[pyadq.ADQInfoListEntry] = acu.ListDevices()

print(f"Found {len(device_list)} device(s)")

# Ensure that at least one device is available
assert device_list, "No devices found"

# Ensure that at least one supported device is found
device_to_open = -1
for idx, info_entry in enumerate(device_list):
    if info_entry.ProductID in [pyadq.PID_ADQ7, pyadq.PID_ADQ8, pyadq.PID_ADQ14]:
        device_to_open = idx

assert device_to_open >= 0, "No ADQ7/ADQ8/ADQ14 found"

# Set up the first available ADQ7/ADQ8/ADQ14
dev: pyadq.ADQ = acu.SetupDevice(device_to_open)

print(f"Setting up data collection for: {dev}")

nof_channels: int = dev.ADQ_GetNofChannels()
acq_parameters: pyadq.ADQDataAcquisitionParameters = dev.InitializeParameters(
    pyadq.ADQ_PARAMETER_ID_DATA_ACQUISITION
)
readout_parameters: pyadq.ADQDataReadoutParameters = dev.InitializeParameters(
    pyadq.ADQ_PARAMETER_ID_DATA_READOUT
)

for ch in range(nof_channels):
    acq_parameters.channel[ch].record_length = 1024
    acq_parameters.channel[ch].nof_records = -1
    acq_parameters.channel[ch].trigger_edge = pyadq.ADQ_EDGE_RISING
    acq_parameters.channel[ch].trigger_source = pyadq.ADQ_EVENT_SOURCE_PERIODIC

    readout_parameters.channel[ch].incomplete_records_enabled = 0
    readout_parameters.channel[ch].nof_record_buffers_max = 20
    readout_parameters.channel[ch].record_buffer_size_max = 2 * 1024

dev.SetParameters(acq_parameters)
dev.SetParameters(readout_parameters)
transfer_params = dev.InitializeParameters(pyadq.ADQ_PARAMETER_ID_DATA_TRANSFER)
dev.SetParameters(transfer_params)

result = dev.ADQ_StartDataAcquisition()
if result != pyadq.ADQ_EOK:
    raise Exception(f"ADQ_StartDataAcquisition failed. Error code {result}")

record_count = 0
records_to_collect = 10

try:
    while record_count < records_to_collect:
        # Wait for a record buffer on any channel with 1000 ms timeout
        record_buffer = dev.WaitForRecordBuffer(pyadq.ADQ_ANY_CHANNEL, 1000)

        # Print some header information
        print(
            f"Channel {record_buffer.header.Channel}, "
            f"record {record_buffer.header.RecordNumber}"
        )
        print(f"\tRecord length: {record_buffer.header.RecordLength}")
        print(f"\tData: {record_buffer.data}")

        record_count += 1

except Exception as e:
    dev.ADQ_StopDataAcquisition()
    raise e

print("All records collected. Stopping data acquisition")
result = dev.ADQ_StopDataAcquisition()
if result not in [pyadq.ADQ_EOK, pyadq.ADQ_EINTERRUPTED]:
    raise Exception(f"ADQ_StopDataAcquisition failed. Error code {result}")
