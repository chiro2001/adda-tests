"""
 Copyright 2020 Teledyne Signal Processing Devices Sweden AB
"""
import setuptools
import distutils.util

main_ns = {}
version_path = distutils.util.convert_path("pyadq/_version.py")
with open(version_path) as version_file:
    exec(version_file.read(), main_ns)

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="pyadq",
    version=main_ns["__version__"],
    author="Teledyne SP Devices",
    url="www.spdevices.com",
    author_email="SPD_Support@teledyne.com",
    packages=setuptools.find_packages(),
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=">=3.6",
    install_requires=["numpy", "wheel"],
    extras_require={"network": ["bson"], "type_checking": ["mypy"]},
)
